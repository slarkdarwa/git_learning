iesp-modules/iems-calc/iems-kpi-server/src/main/java/com/pinnet/kpi/realtimekpi/job/handler/TotalMonthJobHandler.java
iesp-modules/iems-calc/iems-kpi-server/src/main/java/com/pinnet/kpi/realtimekpi/job/handler/YearCapacityHandler.java




实时KPI，凌晨未计入前一天电量
