INSERT INTO  `iesp_schedule_job_config_t` (`module_id`, `job_name`, `job_description`, `job_class_name`, `job_execution_time`, `update_user_id`,`update_user_name`, `update_time`, `execute_time`, `execution_status`, `time_zone_job`)
VALUES (2, 'china_solar_img', '发电预测地图渲染, 每日20点45开始计算!', 'com.pinnet.kpi.forecast.light.job.DrawChinaSolarImgJob', '0 45 20 * * ?', null, null, null, null, 1,0);


iesp-modules/iems-busi/iems-web-server/src/main/java/com/pinnet/web/ecm/powerForecast/PowerForecastController.java
iesp-modules/iems-calc/iems-kpi-server/src/main/java/com/pinnet/kpi/forecast/light/job/ForecastTomorrowJob.java



