ieap-common/src/main/java/com/pinnet/analytics/util/CommonUtil.java
