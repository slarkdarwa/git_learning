/branches/IESP2.0/IESP680/IESP680_IEAP_用能托管_new/iesp-modules/iems-calc/iems-kpi-server/src/main/java/com/pinnet/kpi/realtimekpi/job/handler/CurrentDayOngridAndBuyHandler.java
iesp-modules/iems-busi/iems-basic-config/src/main/java/com/pinnet/basic/ecm/homePage/HomePageInfoServiceImpl.java
iesp-modules/iesp-cache/iesp-redis-client/src/main/java/com/pinnet/redis/service/DevCacheServiceImpl.java




iesp-modules/iems-busi/iems-station-server/src/main/java/com/pinnet/station/service/impl/WeatherServiceImpl.java
iesp-modules/iems-calc/iems-kpi-server/src/main/java/com/pinnet/kpi/kpiCompute/dev/day/KpiEnergyStoreDayComputeImpl.java
iesp-modules/iems-calc/iems-kpi-server/src/main/java/com/pinnet/kpi/realtimekpi/job/handler/CurrentDayChargeAndDischargeCapCapHandler.java





-- 20210323
UPDATE iems_dev_type_info_t SET collumn_count = 200 WHERE id IN (39, 253);
