﻿ALTER TABLE `iesp_company_manage_t`
ADD COLUMN `taxpayer_identification_number` varchar(255) DEFAULT NULL COMMENT '纳税人识别号',
ADD COLUMN `bank_of_deposit` varchar(255) DEFAULT NULL COMMENT '开户行',
ADD COLUMN `account` varchar(255) DEFAULT NULL COMMENT '账号',
ADD COLUMN `contact` varchar(255) DEFAULT NULL COMMENT '联系人',
ADD COLUMN `contact_address` varchar(255) DEFAULT NULL COMMENT '联系地址',
ADD COLUMN `phone` varchar(255) DEFAULT NULL COMMENT '联系方式',
ADD COLUMN `affiliated_unit` bigint(20) DEFAULT NULL COMMENT '所属单位',
ADD COLUMN `create_user` bigint(20) DEFAULT NULL COMMENT '创建人';