App.Module(
	'addStation', '电站信息-一键开站',
	['jquery', 'bootstrap', 'iemsInputTree','UserDialog', 'ecm/partials/main/systemSetting/stationInfo/stationInfo',
		'ecm/partials/main/dm/devUtil', 'ecm/partials/main/systemMessage/system_index', "ecm/babel/utils/treeUtil", 'ecm/babel/partials/efficiencyAnalysis/datas','locationPicker', 'datePicker'],
	function ($, bootStrap, iemsTree, UserDialog,stationinfo, devUtil, systemIndex, treeUtil, double) {
		var pvinfoM = new Map(); // id :{Map{pvindex,PVM }}
		var devinfoM = new Map();// id :{devInfoM}
		var currentDevMap = new Map(); //Map{id, esn}
		var curDev = new Map(); // devTypeId :{[dev]}
		var isHelpPoorLicense = false;
		var pvModuleDevList = new Array();//用于记录配置了PV组串详情的信息的设备列表
		var pvCapMap = new Map();//记录配置了容量的设备信息 Map{devId, {devInfo,pvCapMap:{1:100,2:200}}}
		var curDomain = sessionStorage.getItem('curDomain');


		var S = {
			isHelpPoorLicense: true, //license是否支持扶贫
			nameRepeatFlag: false,//电站名称是否重复 或者用于提前校验
			submitComplete: true,
			loadDevFlag: false,
			bindTGJ: [],
			pvCapacityMap: {},//记录上报的额定容量和组串个数用于分配组串容量 Map{esnCode, pvCapacity:{ratedCapacity:100,capNum:4}}
			isSetPvByDev: true,//是否按照逆变器上报的额定容量及组串个数分配组串容量
			lastInput: [],
			addStationCode:false,// 当前保存成功的电站编号
			addStationId:false,
			hasNewBindDev:false,// 是否存在新接入无设备容量的设备
			clearData:function(){
				pvinfoM = new Map();
				devinfoM = new Map();
				currentDevMap = new Map();
				curDev = new Map();
				pvModuleDevList = new Array();
				pvCapMap = new Map();
			},
			/**
			 * 加载域结构选择公司名称
			 */
			loadDomainTree:function(){
				$('#domain').iemsInputTree({
					url: '/domain/queryUserDomains',
					param: {
						mdfUserId: sessionStorage.getItem('userid')
					},
					treeNodeFormat: function(nodes) {
						if(S.lastInput.length && (!nodes || !nodes.length)) {
							nodes = [{ id: S.lastInput[0], name: S.lastInput[1]}];
						}
						return nodes;
					},
					checkStyle: 'radio',
					clickPIsChecked: true,
					textFiled: "name",
					dataLevel: true,
					click2hidden: true,
					rootCheckable: true,
					treeNodeCreate: function(node) {
						node.name = main.getTopDomianName(node.name);
					}
				});
				$("#domain_searchDiv").hide();

				S.initDomainChangeEvent();
			},
			/**
			 * 初始化时区
			 */
			initTimeZone:function(selectZone){
				$.http.ajax('station/getTimeZones', {}, function (res) {
					if (res && res.data) {
						$('#addStationTimeZone').empty();
						$.each(res.data,function(t,e){
							var option = $('<option value="'+e.timeZoneCode+'" timeZone='+e.timeZone+' ">'+e.showName+'</option>');
							$('#addStationTimeZone').append(option);
						});
						if(selectZone){
							$('#addStationTimeZone').val(selectZone);
						}else{
							var clientTimeZone = Date.getTimezone();
							if(S.isDayLightTime()){
								clientTimeZone = clientTimeZone - 1;
							}
							$('#addStationTimeZone').val($("#addStationTimeZone option[timezone='"+clientTimeZone+"']").val());
						}
					}
				});
			},
			/**
			 * 判断一个时间是在东半球还是西半球
			 * @returns {boolean}
			 */
			isEastEarthTime : function(){
				var now = new Date();
				var timeZone = now.getTimezoneOffset();
				if (timeZone < 0) {
					return true;
				} else {
					return false;
				}
			},
			/**
			 * 判断一个时间是否在夏令时
			 * @returns {boolean}
			 */
			isDayLightTime:function(){
				var now = new Date();
				var start = new Date();     //得到一年的开始时间
				start.setMonth(0);
				start.setDate(1);
				start.setHours(0);
				start.setMinutes(0);
				start.setSeconds(0);
				var middle = new Date(start.getTime());
				middle.setMonth(6);     // 如果年始和年中时差相同，则认为此国家没有夏令时
				if ((middle.getTimezoneOffset() - start.getTimezoneOffset()) == 0) {
					return false;
				}
				var margin = 0;     //判断当前用户在东半球还是西半球
				if (S.isEastEarthTime()) {
					margin = start.getTimezoneOffset();
				} else {
					margin = middle.getTimezoneOffset();
				}
				if (now.getTimezoneOffset() == margin) {
					return true;
				}
				return false;
			},
			/**
			 * 域切换事件
			 */
			initDomainChangeEvent:function(){
				$('#domain').off('change').on('change', function() {
					$(this).css("border-color", "").tooltip("destroy");
					var poorsupport = $(this).attr('poorsupport');
					var domainIsSupportPoor = poorsupport && poorsupport.trim() == 'POOR';
					if(domainIsSupportPoor && S.isHelpPoorLicense && $(':radio[date-type="ICLEAN"]').hasClass('s-selected')) {
						$("#aidTr").show();
					} else {
						$("#aidTr").hide();
						$("#aidType").val(1);
						$("#addStationCombinedType option[value=" + 4 + "]").remove();
					}
					S.priceSetting.initPricePage();
				});
			},
			/**
			 * 厂站类型切换事件
			 */
			initStationTypeEvent:function(){
				$("#addStationType").delegate(':radio', 'click', function(e) {
					var _this = $(e.target);

					$("#addStationType").find(':radio').removeClass('s-selected');
					_this.addClass('s-selected');
					//基本信息切换
					S.basicInfo.changeType(_this.val());
					//电价类型切换
					S.priceSetting.changeType(_this.val());

					//切换完毕之后同意改变角标
					var _spans = $("#priceType").find('span');
					var _first = null;
					var _last = null;
					$.each(_spans, function(i, v) {
						if($(v).is(":visible") || $(v).css('display') == 'block') {
							if(null == _first) {
								_first = $(v);
							}
							_last = $(v);
						}
						$(v).removeClass('left').removeClass('right');
					});
					if(null != _first) {
						_first.addClass('left');
					}
					if(null != _last) {
						_last.addClass('right');
					}
					($('.showDetail i.asc').length > 0) && ($('.showDetail').click());
				});
			},

			/**
			 * 检查是否是数字 并且检查小数位
			 * 空不检查
			 * @param {Object} value
			 * @param {Object} maxDotLenght
			 */
			checkNumValue:function(dom,maxDotLenght){
				var value = dom.val().trim() || dom.val();
				var isTrue = true;
				if(value != ""){
					isTrue = $.isNumeric(value);
					if(isTrue) {
						var dot = value.indexOf(".");
						if(dot != -1) {
							var len = value.substring(dot + 1).length;
							if(len > maxDotLenght) {
								isTrue = false;
							}
						}
					}
					if(!isTrue) {
						dom.css("border-color", "red")
							.tooltip({
								title: Msg.homePage.JK.power.jkTip1 + maxDotLenght + Msg.homePage.JK.power.jkTip2,
								placement: "top"
							});
					} else {
						dom.css("border-color", '').tooltip("destroy");
					}
				}
				return isTrue;
			},
			/**
			 * 事件初始化
			 */
			initEvent:function(callback){
				// 电站名称提示
				$("#addStationCapacity, #addStationName").on("keydown", function() {
					$(this).tooltip("destroy");
				});
				//电站名称空+重复检查
				$("#addStationName").on("blur", function() {
					var dom = $(this);
					var stationName = dom.val().trim() || dom.val();
					if(!stationName || stationName == '') {
						dom.css("border-color", "red")
							.tooltip({
								title: Msg.stationInfo.addStation.stationNameLimit,
								placement: "top"
							});
						return;
					}
					S.basicInfo.stationNameRepeatCheck(null, stationName);
				});
				//隐藏电价下载和导入按钮
				$('.rightC').hide();

				//设计温度数字检查
				$('#designTempreture').off('blur').on('blur',function(){
					S.checkNumValue($(this),5);
				});
				//设计压力数字检查
				$('#designPressure').off('blur').on('blur',function(){
					S.checkNumValue($(this),5);
				});
				// 并网时间时 - 间插件加载
				$("#addStationGridTime").val(new Date().format(Msg.dateFormat.yyyymmdd)).off('click').on('click', function() {
					DatePicker({
						dateFmt: Msg.dateFormat.yyyymmdd,
						isShowClear: true,
						onpicked: function() {
							$(this).css('border-color', '').tooltip('destroy');
						}
					});
				});
				// 安全运行开始时间  时间插件加载
				$("#safe_running_beginDate").val(new Date().format(Msg.dateFormat.yyyymmdd)).off('click').on('click', function() {
					DatePicker({
						dateFmt: Msg.dateFormat.yyyymmdd,
						isShowClear: true,
						onpicked: function() {
							$(this).css('border-color', '').tooltip('destroy');
						}
					});
				});
				// 投运时间  时间插件加载
				$("#addStationDevoteTime").val(new Date().format(Msg.dateFormat.yyyymmdd)).off('click').on('click', function() {
					DatePicker({
						dateFmt: Msg.dateFormat.yyyymmdd,
						isShowClear: true,
						onpicked: function() {
							$(this).css('border-color', '').tooltip('destroy');
						}
					});
				});

				// 标题按钮展开和关闭
				$('button.titleBtn').off('click').on('click', function(e) {
					var _this = $(e.target);
					if(_this.hasClass('open')) {
						_this.removeClass('open').addClass('cover');
						_this.parent().next().hide();
					} else {
						_this.removeClass('cover').addClass('open');
						_this.parent().next().show();
					}
				});

				// 厂站类型切换
				S.initStationTypeEvent();

				$(':radio[date-type="ICLEAN"]').click();

				//电站地址点击事件
				$("button.address-icoin").off('click').on('click', function(e) {
					$('#addStationMapTest')[0] && $('#addStationMapTest').remove();
					var mapDiv = $('<div id="addStationMapTest" class="addStationMap">').css({
							"position": "absolute",
							"width": "400px",
							"height": "400px",
							"display": "none",
							"z-index": "99999"
						}).append($('<div id ="addressMap" style="width: 100%;height: 100%;">')).appendTo('body');
					$('body,.close').off('mousedown.test').on('mousedown.test', function(e) {
						if($(e.target).closest('#addStationMapTest').length == 0) {
							$('#addStationMapTest').hide();
						}
					});
					var lon = $('#addStationAddress').attr("longitude");
					var lat = $('#addStationAddress').attr("latitude");
					// 地图map初始化
					S.basicInfo.initMap(lon, lat);
					var addModal =  $('#addStationDialog-add .modal-dialog')[0] ? $('#addStationDialog-add .modal-dialog') : $('#homePageAddStationDialog-add .modal-dialog'),
						mdfModal = $('#addStationDialog-update .modal-dialog');
					var offSet = addModal.offset() || mdfModal.offset();
					var modalWidth = addModal.outerWidth() || mdfModal.outerWidth();
					var srceeWidh = window.screen.width || 0,
						leftWidth = offSet.left + modalWidth + 3;
					if(leftWidth > srceeWidh - 400) {
						leftWidth = srceeWidh - 400;
					}
					$('#addStationMapTest').css({
						"top": offSet.top + 20,
						"left": leftWidth,
					});
					$('#addStationMapTest').show();
				});

				$("#chargeUserName").off('click').on('click', function (e) {
					App.dialog({
						title: Msg.stationInfo.addStation.chargeUser,
						resizable: false,
						width: 800,
						height: "auto",
						id: 'addCheckMan',
					}).loadPage({
						url: '/nw/accountApply/loadCheckMan.html',
						preload:['nw/babel/accountApply/loadCheckMan'],
					}, {params: {url:'user/queryUsers'}});
				});

				//清芸用户自定义厂站筛选类型
				if(sessionStorage.getItem('customType') == "QINGYUN"){
					$('#mapFilter').show();
				}

				if(!App.isJK){
					$('label[for=stationType_IE]').text(Msg.smsrc.IE);
					$('label[for=stationType_IE]').attr("data-i18n-message-text",Msg.smsrc.IE);
					$('.JK_dateType').hide();
				}
				//电站地址输入变化事件
				//todo
				if(main.Lang === 'zh' || true){
					S.basicInfo.stationAddrSeachChange();
				}else {
					S.basicInfo.initGoogleMapApi();
				}

				//保存按钮事件
				$('#testSaveStation').click(function() {
					$.when(setTimeout(function(){
						$(".price-tabs .errorRed").tooltip("destroy");
					},0));
					S.util.saveStation(!!S.addStationCode, S.addStationId, S.addStationCode, S.systemIds, callback);
				});

				//取消按钮事件
				$("button#cancel").on("click", function() {
					$(".modal").modal("hide");
				});

				// 更多图标收缩
				$('.showDetail').off('click').on('click', function(e) {
					var $this = $('.showDetail').find('.expand');
					if($this.hasClass('desc')) {
						if($("#addStationType").find('.station-type-group :radio[date-type="ICLEAN"]').hasClass("s-selected")) {
							$('.capacitySetting').show();
							S.capacitySetting.getInvs(true);
						}
						$('.priceSetting').show();
						$('.cameraInfo').show();
						$('.otherInfo').show();
						$this.removeClass('desc').addClass('asc');
					} else {
						$('.capacitySetting').hide();
						$('.priceSetting').hide();
						$('.cameraInfo').hide();
						$('.otherInfo').hide();
						$this.removeClass('asc').addClass('desc');
					}
				});
				// 滚动条滚动时隐藏 时间插件
				$($('#addStationDialogN form')[0]).off('scroll').on("scroll",function(){
					try {
						$dp.hide();
					}catch (e) {
						console.error(e);
					}
				});
			},
			basicInfo: {
				loadHtml: function (callback) {
					App.isSK && ($('#psoTransFilePreTr').show());
					S.initTimeZone();
					//域级选择
					S.loadDomainTree();
					//事件监听
					S.initEvent(callback);
					//默认选中电站类型
					S.basicInfo.initStationType(S.systemIds);
					//扶贫信息
					var curDomain = sessionStorage.getItem('curDomain');
					if (curDomain != 1) {
						$.http.ajax('domain/queryDomainById', {domainId: curDomain}, function (res) {
							if (res && res.data) {
								$("#domain").attr("treeselid", curDomain).attr("_name", res.data.domainName);
								$("#domain").val(res.data.domainName);
								$("#domain").attr("poorsupport", res.data.supportPoor || '');
								var poorsupport = res.data.supportPoor;
								if (poorsupport && poorsupport.trim() == 'POOR' && S.isHelpPoorLicense && $(':radio[date-type="ICLEAN"]').hasClass('s-selected')) {
									$("#aidTr").show();
								} else {
									$("#aidTr").hide();
								}
								S.lastInput = [curDomain, res.data.domainName];
							}
						});
					}
					//加载默认电价 供显示
					S.priceSetting.initPricePage();
					//初始化组串容量可选择的设备类型
					S.capacitySetting.initDevTypes($('#sta_add_search_devType'));
				},
				/**
				 * 初始化选中的电站类型
				 * 优先使用filterType(电站当前实际类型)
				 * @param {Object} systemIds 当前用户下所有电站的类型
				 * @param {Object} filterType
				 */
				initStationType: function (systemIds, filterType) {
					if (filterType) {
						systemIds = filterType.split(',').map(  function (x) {
							return x.replace("iesp","").toUpperCase();
						})
					} else {
						systemIds = systemIds.replace('ee', 'ie').replace('EE', 'IE');
						systemIds = systemIds.split(',').map(function (x) {
							return x.replace('iesp_', '').toUpperCase();
						});
						if(systemIds.contains('ALL')){
							systemIds = ['ICLEAN', 'IE'];
						}
					}
					systemIds &&  $("#addStationType").find(':radio[date-type="' + systemIds[0] + '"]').trigger('click');
					$("#addStationType").show();
				},

				/**
				 * 名称重复检查
				 * @param {Object} stationCode
				 * @param {Object} stationName
				 */
				stationNameRepeatCheck: function (stationCode, stationName) {
					$.http.ajax('/station/nameRepeat', {
						stationCode: stationCode,
						stationName: stationName
					}, function (res) {
						if (res && res.success) {
							$("#addStationName").css("border-color", "red")
								.tooltip({
									title: Msg.stationInfo.addStation.stationNameRepeat,
									placement: "top"
								});
							S.nameRepeatFlag = true;
						} else {
							S.nameRepeatFlag = false;
							$("#addStationName").css("border-color", '').tooltip("destroy");
						}
					});
				},

				changeType: function (type, hasClass) {
					var installCapTr = $("#addStationInstallCapity").parent().parent();
					$("#addStationCombinedType").parent().parent().hide(); // 厂站类型
					$("#addStationBuildState").parent().parent().show();//并网状态/电站规划
					$("#addStationBuildState").empty();
					if('ICLEAN' == type){
						$("#addStationBuildState").append([
							$('<option value="3" class="text i18n" >'+Msg.partials.main.home.stationInfo.status[0]+'</option>'),
							$('<option value="2" class="text i18n" >'+Msg.partials.main.home.stationInfo.status[1]+'</option>'),
							$('<option value="1" class="text i18n">'+Msg.partials.main.home.stationInfo.status[2]+'</option>')
						]);
					}else{
						$("#addStationBuildState").append([
							$('<option value="3" class="text i18n" >'+Msg.deviceDialog.hasConnected+'</option>'),
							$('<option value="2" class="text i18n" >'+Msg.homePage.mixPage.planAccess+'</option>'),
						]);
					}
					installCapTr.hide(); //规划容量
					installCapTr.find('label').text(Msg.stationInfo.planCapacity);
					$('#addStationGridTime').parent().parent().hide();//并网时间
					$("#safe_running_beginDate").parent().parent().hide();//安全运行开始时间
					$("#aidType").parent().parent().hide();//扶贫类型
					$("#addStationUserCode").parent().parent().hide();//发电客户编码
					$("#voltageClass").parent().parent().hide();//电压等级
					$('#addStationDevoteTime').parent().parent().hide();//投运时间
					$('.capacitySetting').hide();//组串容量设置
					$("#designPressure").parent().parent().hide();//设计压力
					$("#designTempreture").parent().parent().hide();//设计温度
					if('ICLEAN' == type) {
						$("#addStationCombinedType").parent().parent().show();
//              		$("#addStationBuildState").parent().parent().show();
						installCapTr.show();
						$('#addStationGridTime').parent().parent().show();
						$("#safe_running_beginDate").parent().parent().show();
						var poorsupport = $("#domain").attr('poorsupport');
						if(poorsupport && poorsupport.trim() == 'POOR' && S.isHelpPoorLicense) {
							$("#aidType").parent().parent().show();
						}
						$("#addStationUserCode").parent().parent().show();
					} else if('IE' == type) {
						//电务指标
						$("#voltageClass").parent().parent().show();
						$('#addStationDevoteTime').parent().parent().show();
					} else if('STORE' == type || 'CHARGE' == type || 'COLD' == type) {
						//储能指标，充电桩指标，空调机房
						installCapTr.show(); //规划容量
						$('#addStationGridTime').parent().parent().show();//并网时间
						('COLD' == type) && (installCapTr.find('label').text(Msg.homePage.mixPage.makeCold));
					} else if('HEAT' == type) {
						//供热
						$('#addStationDevoteTime').parent().parent().show();
						$("#designPressure").parent().parent().show();//设计压力
						$("#designTempreture").parent().parent().show();//设计温度
					} else if('LIGHT' == type) {
						//照明
						$('#addStationDevoteTime').parent().parent().show();
					}
				},
				initMap: function (lng, lat) {
					var defaultPoint = {lng: 105.117, lat: 30.892};
					lng = lng ? lng : defaultPoint.lng;
					lat = lat ? lat : defaultPoint.lat
						S.map = MapUtil.Instance('addressMap', {
							center: [lng, lat],
							language: main.Lang,
							zoomLevel: 4,
							maxZoom: 19,
							editable: true,
							mapType: 1,
						}).option.map;
						S.marker && S.map.removeLayer(S.marker);
						S.map.off('mousemove');
						S.map.setView([lat, lng], 4);
						S.marker = MapUtil.createMarker([lat, lng], {
							draggable: true,
						}).on('dragend', function (event) {
							var marker = event.target;
							var position = marker.getLatLng();
							marker.setLatLng(new L.LatLng(position.lat, position.lng), {draggable: 'true'});
							S.map.panTo(new L.LatLng(position.lat, position.lng));
							MapUtil.regeoCodeToAddress([position.lng, position.lat], marker, $('#addStationAddress'));
							$('#addStationAddress').attr("longitude", position.lng).attr("latitude", position.lat);
							$('#longitude').val(position.lng);
							$('#latitude').val(position.lat)
						});
						S.marker.addTo(S.map);
				},
				/**
				 * 电站地址输入变化事件
				 * @param {Object} text
				 */
				stationAddrSeachChange: function (text) {
					$("#addStationAddress").autocomplete({
						source: function (request, response) {
							S.basicInfo.getSearchData(request.term, function (data) {
								response($.map(data, function (item) {
									return {
										label: item.name + '/' + item.district,
										id: item.id,
										value: item.name + '/' + item.district,
									}
								}));
							})
						},
						select: function (event, ui) {
							var val = S.basicInfo.getTipById(ui.item.id);
							if (val && val.location.length > 0) {
								var point = val.location.split(',');
								if (S.map) {
									S.marker && S.map.removeLayer(S.marker);
									S.map.off('mousemove');
									S.map.setView([point[1], point[0]], 18);
									S.marker = MapUtil.createMarker([point[1], point[0]], {
										draggable: true,
									}).on('dragend', function (event) {
										var marker = event.target;
										var position = marker.getLatLng();
										marker.setLatLng(new L.LatLng(position.lat, position.lng), {draggable: 'true'});
										S.map.panTo(new L.LatLng(position.lat, position.lng));
										MapUtil.regeoCodeToAddress([position.lng, position.lat], marker, $('#addStationAddress'));
										$('#addStationAddress').attr("longitude", position.lng).attr("latitude", position.lat);
									});
									S.marker.addTo(S.map);
								}
								$(event.target).val(val.name).tooltip('destroy');
								$(event.target).attr("longitude", point[0]).attr("latitude", point[1]);
								$('#longitude').val(point[0]);
								$('#latitude').val(point[1])
							} else {
								$(event.target).removeAttr("longitude").removeAttr("latitude");
								$(event.target).tooltip({
									title: Msg.homePage.mixPage.detailAddress,
									placement: "top"
								});
							}
							return false;
						}
					});
				},
				/**
				 * 地址模糊查询
				 * @param {Object} text
				 * @param {Object} callback
				 */
				getSearchData: function (text, callback) {
					if(main.Lang == 'zh' && !App.isAbroad){
						// 国际化问题  目前此接口只支持高德 且只返回中文和搜索中国地质
						$.http.ajax("userRadar/getClosestAddressInfo", {content: text}, function (res) {
							if (res && res.data && res.data.data.tips) {
								S.basicInfo.parseSearchData(res.data.data);
								callback && callback(res.data.data.tips);
							}
						});
					}
				},
				initGoogleMapApi : function() {
					var places = new google.maps.places.Autocomplete(document.getElementById('addStationAddress'));
					google.maps.event.addListener(places, 'place_changed', function () {
						var place = places.getPlace();
						var timeZoneValue = Msg.stationInfo.addStation.timeZoneArrValue;
						var timeZoneId = Msg.stationInfo.addStation.timeZoneId;
						var latitude = place.geometry.location.lat();
						var longitude = place.geometry.location.lng();
						var timezone = place.utc_offset/60;
						var id;
						var timeCode;
						for(var i=0;i<timeZoneValue.length;i++){
							if(timeZoneValue[i]==timezone){
								id=timeZoneId[i];
								timeCode=timeZoneValue[i];
								break;
							}
						}

						var selectId = $($('#addStationTimeZone option[timeZone="'+id+'"]')[0]).attr("value");
						$("#addStationTimeZone").val(selectId);
						$("#addStationTimeZone").attr("data-timeCode",timeCode);

						$("#addStationLongtitude").val(//经度
							addStationInfo.latlongFormat(longitude)[0]+
							(addStationInfo.latlongFormat(longitude)[1] == '-'?'W':'E')
						);
						$("#addStationLatitude").val(
							addStationInfo.latlongFormat(latitude)[0]+
							(addStationInfo.latlongFormat(latitude)[1] == '-'?'S':'N')
						);//纬度
					});
				},
				parseSearchData: function (data) {
					S.tips = data.tips;
				},
				getTipById: function (id) {
					var result;
					$.each(S.tips, function (i, e) {
						if (id == e.id) {
							result = e;
							return false;
						}
					})
					return result;
				},
			},
			// 基本信息
			bindDev: {
				//点击立即添加时的页面加载
				initAddDev: function (flag) {
					var esnWith = '40%', colspan = 4;
					if(App.isJK) {
						colspan = 5;
						esnWith = '25%';
					}
					// 去除背景border
					$('.bindDev .content').css("border", "none");
					var $table = $('<table>').attr("border", "1").addClass("excel");
					var $th = $('<tr>').append([
						$('<th width="' + esnWith + '">').text(Msg.DCChild.esnCode),
						$('<th width="20%">').text(Msg.devSupplement.devName),
						$('<th width="20%">').text(Msg.DCChild.modelVersionCode)
					]);
					if(App.isJK) {
						$th.append($('<th width="25%">').text(Msg.homePage.mixPage.itemize));
					}
					$th.append([
						$('<th>').text(Msg.upgrade.devOperate),
						$('<th>').text('pType').hide(),
						$('<th>').text('devId').hide(),
						$('<th>').text('busiCode').hide(),
						$('<th>').text('pvNum').hide()
					]);


					var $addBtn = $('<tr>').append($('<td colspan="'+colspan+'">').append($('<button>').attr("type", "button").addClass("addDevInfo")));
					var btn104 = $('<button id="add104Dev" class="btn i18n text" type="button" style="float: right;right: 3%;margin-bottom: 8px;">' + Msg.stationInfo.addStation.addTubeMachine + '</button>');
					$('.bindDev').find('.content').empty().append(btn104).append($table.append($th).append($addBtn));
					//设备列表，新增操作
					$('.addDevInfo').off('click').on(	'click', function () {
						$('.addDevInfo').parent().parent().before(S.bindDev.addDevEle(false));
						// esn号绑定事件
						$(".addDevTag .devESN").off("change keydown").on("change keydown", function (e) {
							if (e.type == "change") {
								var that = $(this);
								var $devTr = $(this).parent().parent();
								//修改esn号时删除对应子设备
								if ($devTr.attr("esnCode")) {
									var $kids = $devTr.parent().find("tr.kids[parentEsn='" + $devTr.attr("esnCode") + "']");
									if ($kids.length > 0) {
										$kids.remove();
									}
								}
								//展开按钮
								that.siblings("b.dc").removeClass("dcOpen");
								that.siblings(".delDevBtn").show();
								var esnTemp = that.val().trim()
								if (esnTemp) {
									// 判断重复
									var repeatFlag = false;
									var esnInputList = $("input.devESN");
									//todo 判断是否重复
									if (repeatFlag) {
										that.siblings("b.dc").hide();
										return;
									}
									// 后台查询设备并接入，同时填入名称和类型
									$.http.ajax("/station/getDevByEsn", {esn: that.val().trim()}, function (data) {
											//判断是否被绑定
											if (data.data == "has station") {
												that.siblings("b.dc").hide();
												$devTr.css('border','1px solid red');
												that.tooltip({
													title: Msg.stationInfo.addStation.devHasBeenBind,
													placement: "top"
												});
												that.attr("isBind", "yes");
												$(that).tooltip("show");
												return;
											}

											//正常绑定设备
											if (data && data.success && data.data != "404") {
												that.siblings("b.dc").toggleClass("dcOpen");
												var dev = data.data.dev;
												var devCapInfo = data.data.devCapInfo;
												var $tr = that.parent().parent();
												$tr.attr("esnValidate", "esnValidate");
												$tr.attr("esnCode", dev.esnCode);
												$tr.find("input.devType").val(dev.modelVersionCode).attr("title", dev.esnCode);
												$tr.find("input.devName").val(dev.busiName).attr("title", dev.esnCode)
													.unbind("change").on("change", function () {
													var devNameR = $(this).val();
													var reg = /^[^\'\<\>,\/\&\"\“\”\，\‘\’']*$/;
													if (!devNameR || !reg.test(devNameR) || devNameR.indexOf("null") != -1) {
														$(this).attr("title", "");
														$(this).css("border-color", "red").tooltip({
															title: Msg.stationInfo.addStation.devNameCheck,
															placement: "top"
														});
													} else {
														$(this).css("border-color", "").tooltip('destroy');
													}
												});
												$tr.find("input.pType").val(dev.devTypeId);
												$tr.find("input.pvNum").val(dev.pvNum);
												$tr.find("input.devId").val(dev.id);
												$tr.find("input.devCap").val(devCapInfo && devCapInfo[dev.id]);
												$tr.find("input.busiCode").val(dev.busiCode);

												//  that.siblings("input.regCode").val(dev.devRegistCode);
												that.parent().attr("devId", dev.id);

												// license 校验
												if (data.data.errorCode == '-4') {
													that.siblings("b.dc").hide();
													that.parent().parent().css("border-color", "red");
													that.tooltip({
														title: Msg.systemSetting.license.onlyHld,
														placement: "top"
													});
													$(that).tooltip("show");
													return;
												}
												that.attr("isBind", "no");
												var subInverterList = data.data.subDevList;
												// 判断是否是数采且下挂有设备
												if (subInverterList && subInverterList.length > 0) {
													that.siblings("b.dc").show();
													that.siblings("b.dc").css("margin-left", "0");
													var childrenDiv = $("<tr/>").attr("esnValidate", "esnValidate");
													var length = subInverterList.length;
													if (length > 0) {
														//有下挂设备时，添加下挂设备项
														S.bindDev.addChildDeiv(subInverterList, childrenDiv, $tr, false, 1,data.data.devCapInfo);
													}
													$tr.children().find("input.devName").unbind("change").on("change", function () {
														var devNameR = $(this).val();
														var reg = /^[^\'\<\>,\/\&\"\“\”\，\‘\’']*$/;
														if (!devNameR || !reg.test(devNameR) || devNameR.indexOf("null") != -1) {
															$(this).attr("title", "");
															$(this).css("border-color", "red").tooltip({
																title: Msg.stationInfo.addStation.devNameCheck,
																placement: "top"
															});
														} else {
															$(this).css("border-color", "").tooltip('destroy');
														}
													});
													that.siblings("b.dc").off("click").on("click", function () {
														var $tr = $(this).parent().parent();
														var esnCode = $tr.attr('esnCode');
														$tr.siblings('tr[parentesn="' + esnCode + '"]').toggleClass("hideKids");
														$(this).toggleClass("dcOpen");
													});
													$(".kids").find(".delDevBtn").off("click").on("click", function () {
														var tr = $(this).parent().parent();
														var devType = $(tr).find(".pType").val();
														var devId =  $(tr).find(".devId").val();
														try{
															curDev.get(devType).delete(devId);
														}catch(e){
															console.info(e);
														}
														$(tr).remove();
														S.capacitySetting.init();
													});
													if (subInverterList.length > 8) { //如果下联设备数量大于8个则需要将宽度置为99%
//														newDevRecord  && $(newDevRecord).find(".kids").find("p").css('width', "99%");
													}
													childrenDiv = null;
												}
												childrenDiv = null;
												if(dev.devTypeId == 37 || dev.devTypeId == 235 || dev.devTypeId == 13) {
													$tr.find("select.itemize").remove();
												}
												if ($('.station-type-group').find('.s-selected').attr("date-type") == "ICLEAN") {
													//获取上报的额定容量和组串个数用于分配组串容量
//                                                  S.capacitySetting.getCapacityAndNum(data.data.pvCapacity);
													//刷新组串设置页面
													S.capacitySetting.init();
												}

											} else {
												that.siblings("b.dc").hide();
												that.parent().parent().css('border','1px solid red');
												that.tooltip({
													title: Msg.stationInfo.addStation.noDevData,
													placement: "top"
												});
												that.attr("isBind", "yes");
												$(that).tooltip("show");
												return;
											}
										}
									);
								}
							} else if (e.type == "keydown") {
								$(this).parent().parent().css("border-color", "");
								$(this).tooltip("destroy");
							}
						});
					})
					if (!flag) {
						//$('.addDevInfo').trigger('click');
					}
					//接入通管机
					$('#add104Dev').off('click').on('click',function(){
						App.dialog({
								width: 800,
								height: 600,
								title: Msg.stationInfo.addStation.tubeMachineIn,
								id: 'add104DevDialog'
							})
							.loadPage({
								url: "/systemSetting/stationInfo/tubeMachine.html",
								preload: "systemSetting/stationInfo/tubeMachine"
							});
					});
				},
				init: function () {
					//绑定设备，是否新增的操作
					$("#bindDevBtn").off('click').on('click', function () {
						S.bindDev.initAddDev(false);
					})
				},
				/**
				 * flag 判断是新增还是修改dialog true 修改； false 新增
				 * @param flag
				 * @param esnVal
				 * @param nameVal
				 * @param typeVal
				 * @returns {jQuery|HTMLElement}
				 */
				addDevEle: function (flag, esnVal, nameVal, typeVal, pTypeVal, devIdVal, busiCodeVal, regCodeVal, pvNumVal,devCap,businessType,devInfo) {
					var index = $("div.bindDev").find(".content").find('tr').length - 1;
					var esnId = 'addDevESN' + index;
					var nameId = 'addDevName' + index;
					var typeId = 'addDevType' + index;
					var pTypeId = 'addPType' + index;
					var devId = "addDevId" + index;
					var busiCode = "addBusiCode" + index;
					var regCodeId = "addRegCode" + index;
					var itemizeId = "itemize"+index;
					var pvNum = "addpvNum" + index;
					var newDevRecord = $("<tr/>");
					newDevRecord.addClass("addDevTag");
					devCap = devCap  || "";
					var jkTd = $('<td ></td>');
					if(App.isJK){
						var selectEle = $('<select  class="itemize" id = "'+itemizeId+'"/>');
						var obj = {
							1: Msg.homePage.mixPage.jkDetail1,
							2: Msg.homePage.mixPage.jkDetail2,
							3: Msg.homePage.mixPage.jkDetail3,
							4: Msg.homePage.mixPage.jkDetail4
						};
						for(var k in obj){
							selectEle.append($('<option value="'+k+'">'+obj[k]+'</option>'));
						}
						selectEle.val(businessType || "1");
						jkTd.append(selectEle);
					}
					if (flag) {
						var childArr = [];
						childArr.push($('<td><b class="dc" /><input type="text"  class="devESN"' + 'value="' + esnVal + '"' + ' id="' + esnId + '" readonly/></td>'));
						childArr.push($('<td><input type="text" class="devName"' + 'value="' + nameVal + '"' + ' id="' + nameId + '"' + 'title="' + esnVal + '"' + 'readonly/></td>'));
						childArr.push($('<td><input type="text"  class="devType"' + 'value="' + typeVal + '"' + 'id="' + typeId + '" readonly/></td>'));
						if(App.isJK) childArr.push(jkTd);
						childArr.push($('<td><button type="button" class="delDevBtn"></button></td>'));
						childArr.push($('<td><input type="hidden" class="pType"' + 'value="' + pTypeVal + '"' + 'id="' + pTypeId + '" /></td>').hide());
						childArr.push($('<td><input type="hidden" class="devId"' + 'value="' + devIdVal + '"' + 'id="' + devId + '" /></td>').hide());
						childArr.push($('<td><input type="hidden" class="busiCode"' + 'value="' + busiCodeVal + '"' + 'id="' + busiCode + '" /></td>').hide());
						childArr.push($('<td><input type="hidden" class="pvNum"' + 'value="' + pvNumVal + '"' + 'id="' + pvNum + '" /></td>').hide());
						childArr.push($('<td><input type="hidden" class="devCap"' + 'value="' + devCap + '" /></td>').hide());

						newDevRecord.addClass("devTag").append(childArr).attr("add", "add").attr("devId", devIdVal).attr("esncode", esnVal);
						//设备列表，删除操作
						newDevRecord.find(".delDevBtn").off("click").on("click", function () {
							$(".tooltip").remove();
							var $tr = $(this).parent().parent();
							var _this = this;
							var url = '/station/unBindDevs';
							var devId = $(_this).closest('tr').attr("devId");
							var params = {
								devId: devId
							};

							S.bindTGJ.remove($tr.attr("esnCode"));

							App.confirm(Msg.stationInfo.modifyStation.confirmToUnbindCollector, function () {
								$('#addStationDialog-update').toggleLoading({
									msg: Msg.homePage.mixPage.jkDetail5,
									iconUrl: '/images/loading.gif'
								});
								$.http.POST(url, params, function (res) {
									$('#addStationDialog-update').cancleLoading({
										msg: Msg.homePage.mixPage.jkDetail6,
										iconUrl: '/images/loading.gif'
									});
									if (res && res.success) {
										if ($tr.attr("esnCode")) {
											var $kids = $tr.parent().find("tr.kids[parentEsn='" + $tr.attr("esnCode") + "']");
											if ($kids.length > 0) {
												$kids.remove();
											}
										}
										$(_this).parent().parent().remove();
										$('#newDeviceManageList').GridTableRefreshPage();
									} else {
										App.alert(Msg.stationInfo.modifyStation.unbindFailed);
									}
								});
							});
						});
						newDevRecord.find('b.dc').toggleClass("dcOpen");
					} else {
						var childArr = [];
						childArr.push($('<td><b class="dc" /><input type="text"  class="devESN" id="' + esnId + '" /></td>'));
						childArr.push($('<td><input type="text" class="devName" id="' + nameId + '" /></td>'));
						childArr.push($('<td><input type="text"  class="devType" id="' + typeId + '" readonly/></td>'));
						if(App.isJK) childArr.push(jkTd);
						childArr.push($('<td><button type="button" class="delDevBtn"></button></td>'));
						childArr.push($('<td><input type="hidden" class="pType" id="' + pTypeId + '" /></td>').hide());
						childArr.push($('<td><input type="hidden" class="devId" id="' + devId + '" /></td>').hide());
						childArr.push($('<td><input type="hidden" class="busiCode" id="' + busiCode + '" /></td>').hide());
						childArr.push($('<td><input type="hidden" class="pvNum" id="' + pvNum + '" /></td>').hide());
						childArr.push($('<td><input type="hidden" class="devCap"' + 'value="' +devCap + '" /></td>').hide());

						newDevRecord.append(childArr);
						//设备列表，删除操作
						newDevRecord.find(".delDevBtn").off("click").on("click", function () {
							$(".tooltip").remove();
							var $tr = $(this).parent().parent();
							var devType = $tr.find(".pType").val();
							var dId = $tr.find(".devId").val();
							try{
								curDev.get(devType).delete(dId);
							}catch(e){
								console.info(e);
							}
							if ($tr.attr("esnCode")) {
								var $kids = $tr.parent().find("tr.kids[parentEsn='" + $tr.attr("esnCode") + "']");
								if ($kids.length > 0) {
									$.each($kids, function(t,e) {
										var devType = $(e).find(".pType").val();
										var devId =  $(e).find(".devId").val();
										try{
											curDev.get(devType).delete(devId);
										}catch(e){
											console.info(e);
										}
									});
									$kids.remove();
								}
							}
							S.bindTGJ.remove($tr.attr("esnCode"));
							$(this).parent().parent().remove();
							S.capacitySetting.init();
						});
					}
					newDevRecord.find("b.dc").off("click").on("click", function () {
						var $tr = $(this).parent().parent();
						$(this).toggleClass("dcOpen");
						if ('30px' == $(this).parent().css("height")) {
							$(this).parent().css("height", height);
						} else {
							$(this).parent().css("height", "30px");
						}
					});
					return newDevRecord
				},
				addChildDeiv: function (subInverterList, childrenDiv, parentDiv, isBinded, subIndex,devCapInfo) {
					for (var i = 0; i < subInverterList.length; i++) {
						var dev = subInverterList[i].dev ? subInverterList[i].dev : subInverterList[i];
						var subList = subInverterList[i].subDevList;
						var esnValidate = $(parentDiv).attr("esnValidate");
						if ((2 != dev.devTypeId || dev.parentTypeId == 13) && 37 != dev.devTypeId && (isBinded || !dev.stationCode)) {
							var newChild = $(parentDiv).clone(false);
							var parentEsn = newChild.attr("esncode");
							newChild.addClass("kids").attr("parentEsn", parentEsn);
							newChild.attr("esncode", dev.esnCode);
							newChild.find("input").removeAttr("id");  //删除id属性
							newChild.attr("esnValidate", esnValidate);
							newChild.find("input.devName").val(dev.busiName).attr("title", dev.busiName);
							newChild.find("input.devESN").val(dev.esnCode).attr("disabled", "disabled").attr("esnValidate", esnValidate).attr("title", dev.esnCode);
							newChild.find("input.devType").val(dev.modelVersionCode).attr("disabled", "disabled").attr("title", dev.modelVersionCode);
							newChild.find("input.pType").val(dev.devTypeId);
							newChild.find("select.itemize").val(dev.businessType);
							//数采 云节点网关机 通管机 不可设置业态类型
							if(dev.devTypeId == 37 || dev.devTypeId == 235 || dev.devTypeId == 13) {
								newChild.find("select.itemize").remove();
							}
							newChild.find("input.devId").val(dev.id);
							newChild.find("input.busiCode").val(dev.busiCode);
							newChild.find("input.regCode").val(dev.devRegistCode);
							newChild.find("input.pvNum").val(dev.pvNum);
							newChild.find("input.devCap").val(devCapInfo && devCapInfo[dev.id]);

							if (!subList || subList.length <= 0) {
								newChild.find("b.dc").remove();
								newChild.removeClass("devTag");
							}
							if (isBinded) {
								newChild.attr("add", "add");
							}
							if (2 == subIndex) {
								newChild.css("margin-left", "0%").css("width", "97%").attr("devId", dev.id);
							} else {
								newChild.attr("devId", dev.id).css("width", "97%");
							}
							if (subList && subList.length > 0) {
								var div = $("<tr/>");
								var height = (40 * subList.length) + 40 + "px";
								S.bindDev.addChildDeiv(subList, div, newChild, isBinded, 2,devCapInfo);
								$(newChild.find("b.dc")).css("margin-left", "-4%");
								$(newChild.find("b.dc")).off("click").on("click", function () {
									$(this).parent().find(".kids").toggleClass("hideKids");
									$(this).toggleClass("dcOpen");
									if ('30px' == $(this).parent().css("height")) {
										$(this).parent().css("height", height);
									} else {
										$(this).parent().css("height", "30px");
									}
								});
							}
							//设备列表，删除操作
							newChild.find(".delDevBtn").off("click").on("click", function () {
								$(".tooltip").remove();
								var $tr = $(this).parent().parent();
								var _this = this;
								var url = '/station/unBindDevs';
								var devId = $(_this).closest('tr').attr("devId");
								var params = {
									devId: devId
								};
								App.confirm(Msg.stationInfo.modifyStation.confirmToUnbindCollector, function () {
									$('#addStationDialog-update').toggleLoading({
										msg: Msg.homePage.mixPage.jkDetail5,
										iconUrl: '/images/loading.gif'
									});
									$.http.POST(url, params, function (res) {
										$('#addStationDialog-update').cancleLoading({
											msg: Msg.homePage.mixPage.jkDetail6,
											iconUrl: '/images/loading.gif'
										});
										if (res && res.success) {
											if ($tr.attr("esnCode")) {
												var $kids = $tr.parent().find("tr.kids[parentEsn='" + $tr.attr("esnCode") + "']");
												if ($kids.length > 0) {
													$kids.remove();
												}
											}
											$(_this).parent().parent().remove();
											$('#newDeviceManageList').GridTableRefreshPage();
										} else {
											App.alert(Msg.stationInfo.modifyStation.unbindFailed);
										}
									});
								});
							});
							parentDiv.after(newChild);
						}
					}
				},
				/**
				 * 获取上报的额定容量和组串个数用于分配组串容量
				 */
				getCapacityAndNum: function (data) {
					if (data) {
						for (var key in data) {
							S.pvCapacityMap[key] = data[key];
							var ratedCapacity = data[key].ratedCapacity;
							var capNum = data[key].capNum;
							if (!ratedCapacity || !capNum || capNum == 0) {
								S.isSetPvByDev = false;
							}
						}
					} else {
						S.isSetPvByDev = false;
					}
				},
			},

			// 组串容量设置
			capacitySetting: {
				init: function () {

					S.capacitySetting.getInvs(true);
					$('#capacityConfig').off('click').on('click', function () {
						S.capacitySetting.capacitySetting();
					});
					$('#sta_add_search_devType').off('change').on('change', function () {
						S.capacitySetting.getInvs(true);
					});
					$('#sta_add_search_devName').off("keyup").on('keyup', function(e) {
						e.stopPropagation();
						if(event.keyCode == 13 || event.key == "Enter" || event.which == 13 || this.value == '') {
							S.capacitySetting.getInvs(true);
						}
					});
					$('#exportCapacity').unbind('click').on('click',function () {
						S.capacitySetting.exportCapacity();
					});
					$('#importCapacity').unbind('click').on('click',function () {
						if(!S.addStationCode){
							App.alert(Msg.systemSetting.importErrorTip);
							return;
						}
						S.capacitySetting.importCapacity();
					});
				},

				initDevTypes: function (dom) {
					//此处可写死..
					var showCapDevTypeArr = [
						{
							id:"1",
							name: Msg.devTypeLangKey.stringInverter
						},
						{
							id:"15",
							name: Msg.devTypeLangKey.dcBus
						},
						{
							id:"38",
							name: Msg.devTypeLangKey.householdInverter
						},{
							id:"62",
							name: Msg.devTypeLangKey.sanshoInverter
						}
					];
					$.each(showCapDevTypeArr, function(t,e) {
						var opt = $("<option value=" + e.id + ">" + e.name + "</option>");
						dom.append(opt);
					});
				},
				/**
				 * 获取上报的额定容量和组串个数用于分配组串容量
				 */
				getCapacityAndNum: function (data) {
					if (data) {
						for (var key in data) {
							S.pvCapacityMap[key] = data[key];
							var ratedCapacity = data[key].ratedCapacity;
							var capNum = data[key].capNum;
							if (!ratedCapacity || !capNum || capNum == 0) {
								S.isSetPvByDev = false;
							}
						}
					} else {
						S.isSetPvByDev = false;
					}
				},
				/**
				 * 组串容量设置
				 */
				capacitySetting: function () {
					var selects = $('#invInfo').GridTableSelectedRecords();
					if (!selects || selects.length <= 0) {
						App.alert(Msg.stationInfo.atLeastOne);
						return;
					}
					var devIdList = [];
					var devTypeIdList = [];
					var infoarr = new Map();
					$.each(selects, function (t, e) {
						devIdList.push(e.id);
						devTypeIdList.push(e.devTypeId);
						var obj = {};
						obj.id = e.id;
						obj.stationCode = e.stationCode;
						obj.busiCode = e.busiCode;
						obj.devTypeId = e.devTypeId;
						obj.twoLevelDomain = e.twoLevelDomain;
						obj.esnCode = e.esnCode;
						obj.pvNum = e.pvNum;
						infoarr.set(e.id, obj);
					});

					var devCheck = devUtil.checkDevType(devTypeIdList);
					if (!devCheck) {
						App.alert(Msg.partials.main.dm.getSomeTypeDevice);
						return;
					}

					var devTypeId = devTypeIdList[0];

					var parmas = {};
					parmas.devIdList = devIdList;
					parmas.devTypeId = devTypeId;
					parmas.devInfo = infoarr;
					parmas.sureFun = function (parm) {
						S.capacitySetting.savePVCap(parm, $('#invInfo').GridTableSelectedRecords());
					};
					parmas.closeFun = function () {
						$('#capacityConfigDiaglog').modal('hide');
					};

					if (devIdList && devIdList.length == 1) {
						var devId = devIdList[0];
						var pvCapInfo = pvCapMap.get(devId);
						if (pvCapInfo) {
							parmas.pvCapMap = pvCapInfo.pvCapMap;
							S.util.loadCapDialog(parmas);
						} else {
							$.http.ajax('/station/getDevCapById', {devId: devId}, function (res) {
								if (res && res.success) {

									var _data = res.data;
									var pvMap = new Map();
									for (var i = 1; i <= 30; i++) {
										var pvCap = _data["pv" + i];
										if (null != pvCap && undefined != pvCap) {
											pvMap.set(i, pvCap);
										}
									}
									if (pvMap.size > 0) {
										parmas.pvCapMap = pvMap;
									}
									S.util.loadCapDialog(parmas);
								} else {
									S.util.loadCapDialog(parmas);
								}
							});
						}
					} else {
						S.util.loadCapDialog(parmas);
					}
				},
				jumpTopByClass:function(eleClass){
					var top1 = $('#addStationDialogN form').offset().top;
					var top2 = $('#addStationDialogN form '+eleClass).offset().top;
					var stop = $('#addStationDialogN form').scrollTop();
					var scrolTop = (top2 + stop) - top1;
					$('#addStationDialogN form').scrollTop(scrolTop);
				},
				// 获取是否存在未配置组串容量设备
				checkIsExistNotSetCapDev:function(devArr,setPvCap){
					if(!devArr || devArr.length <=0) return false;
					var data =  S.capacitySetting.getDevFromBindTab();
					if (data && data.size > 0 && data.get(0) && data.get(0).size > 0) {
						var capMap = {};
						dataArr = data.get(0).arrValues();
						$.each(dataArr, function(t, e) {
							capMap[e.devId] = e.capacity;
						});
						var isExist = false;
						$.each(devArr,function(t,e){
							var devId = e.split("@@")[0];
							// 本来就没有 和后续未配置
							if(devId && !capMap[devId] && !setPvCap[devId]){
								isExist = true;
								return;
							}
						});
						return isExist;
					}
					return false;
				},
				getDevFromBindTab:function(){
					var devMaps = new Map();
					var devMap = new Map();
					var notset = [],curDevSet = [];
					currentDevMap = new Map();
					$("tr.addDevTag").each(function () {
						var devTypeId = $(this).find("input.pType").val().trim();
						var esnCode = $(this).find("input.devESN").val().trim();
						if (!curDevSet.contains(esnCode) && (devTypeId == '1' || devTypeId == '15' || devTypeId == '38' || devTypeId == '62')) {
							curDevSet.push(esnCode);// 防止设备id获取不到或者获取错误，根据esn判断不重复添加
							var devId = $(this).find("input.devId").val().trim();
							var devCap = $(this).find("input.devCap").val().trim();
							var obj = {
								esnCode: esnCode,
								busiName: $(this).find("input.devName").val().trim(),
								devTypeId: $(this).find("input.pType").val().trim(),
								devId: devId,
								busiCode: $(this).find("input.busiCode").val().trim(),
								pvNum: $(this).find("input.pvNum").val().trim(),
								id: $(this).find("input.devId").val().trim(),
								modelVersionCode: $(this).find("input.devType").val().trim(),
								pvCapacity: S.pvCapacityMap[esnCode],
								capacity: devCap
							};
							var devmap = pvCapMap.get(obj.devId);
							if (devmap && devmap.pvCapMap && devmap.pvCapMap.size > 0) {
								var total = 0;
								$.each(devmap.pvCapMap.arrValues(), function (t, e) {
									total += Number(e);
								});
								total = total / 1000;
								obj.capacity = total;
							} else {
								notset.push(obj.devId);
							}
							devMap.set(obj.devId, obj);
							var arr = curDev.get(devTypeId);
							if ($.isEmptyObject(arr)) {
								arr = new Map();
							}
							arr.set(obj.devId, obj);
							curDev.set(devTypeId, arr);

							currentDevMap.set(obj.devId, obj.esnCode);
						}
					});
					// 防止设备绑定后配置 再去解绑 再保存
					if (devinfoM && devinfoM.size > 0) {
						if (currentDevMap.size > 0) {
							var temp = new Map();
							var tempPv = new Map();
							$.each(currentDevMap.arrKeys(), function (t, e) {
								var obj = devinfoM.get(e);
								if (obj) {
									temp.set(e, obj);
									tempPv.set(e, pvinfoM.get(e));
								}
							});
							devinfoM = temp;
							pvinfoM = tempPv;
						} else {
							devinfoM = new Map();
						}
					}
					devMaps.set(0, devMap);
					devMaps.set(1, notset);
					return devMaps;

				},
				//flag 为true表示新增，false表示修改
				getInvs: function (flag, stationCode, devTypeId) {
					devTypeId = $('#sta_add_search_devType').val();
					var devName = $('#sta_add_search_devName').val();
					var dataArr = [], tabArr = [];
					var data =  S.capacitySetting.getDevFromBindTab();

					if (data && data.size > 0 && data.get(0) && data.get(0).size > 0) {
						dataArr = data.get(0).arrValues();
						var isType = devTypeId && devTypeId != '0';
						var isDevName = devName && true;
						if(isType || isDevName) {
							$.each(dataArr, function(t, e) {
								var isAdd = true;
								if(isType && e.devTypeId != devTypeId){
									isAdd = false;
								}
								if(isDevName && e.busiName.indexOf(devName) <0){
									isAdd = false;
								}
								if(isAdd) tabArr.push(e);
							});
						}else{
							tabArr = dataArr;
						}
					}


					S.capacitySetting.initDevList(tabArr);
					if (flag && false) {
						var dataArr = [];
						var data = S.capacitySetting.getDevFromBindTab();
						if (data && data.size > 0 && data.get(0) && data.get(0).size > 0) {
							dataArr = data.get(0).arrValues();
						}
						S.capacitySetting.initDevList(dataArr);
					}

				},
				initDevList: function (datas) {
					//按设备名称排序
					var tabDevNameArr = datas.map(x=>x.busiName).sort();
					var tempArr=[];
					tabDevNameArr.forEach(v=>{
						tempArr.push(datas.find(y=>y.busiName==v));
					})
					var invTable = $("#invInfo").GridTable({
						url: '',
						title: false,
						max_height: 440,
						rp: 10,
						prototypeData: tempArr,
						clickSelect: true,
						isRecordSelected: true,
						idProperty: 'devId',
						params: {},
						colModel: [
							{
								display: 'id',
								name: 'devId',
								align: 'center',
								hide: true
							},
							{
								display: 'busiCode',
								name: 'busiCode',
								hide: true
							}, {
								display: Msg.partials.main.dm.devName,
								name: 'busiName',
								width: 0.2,
								align: 'center'
							}, {
								display: Msg.partials.main.dm.devType,
								name: 'devTypeId',
								width: 0.2,
								align: 'center',
								order: true,
								fnInit: S.util.initDevType
							}, {
								display: Msg.partials.main.dm.devESN,
								name: 'esnCode',
								width: 0.2,
								align: 'center'
							}, {
								display: Msg.partials.main.dm.devVersion,
								name: 'modelVersionCode',
								width: 0.2,
								order: true,
								align: 'center'
							}, {
								display: Msg.partials.main.dm.StringCapacity,
								name: 'capacity',
								width: 0.2,
								align: 'center'
							}, {
								display: 'pvNum',
								name: 'pvNum',
								align: 'center',
								hide: true
							}
						]
					});
					return invTable;
				},
				exportCapacity:function(){
					var params={};
					var devIds=[];
					var selectArr = $("#invInfo").GridTableSelectedRecords();
					if(selectArr.length==0){
						var data =  S.capacitySetting.getDevFromBindTab();
						if (data && data.size > 0 && data.get(0) && data.get(0).size > 0) {
							selectArr = data.get(0).arrValues();
						}
					}
					if(selectArr.length!=0){
						_.forEach(selectArr,function (v) {
							devIds.push(v.id);
						});
					}
					params.devIds=devIds;
					params.stationCode= null;
					$('#exort_form #param').val(JSON.stringify(params));
					$('#exort_form #_csrf').val(main.getCsrf());
					$("#exort_form").attr("action","station/exportCapacity").submit();
				},
				importCapacity: function () {
					var fileInput = $('<input type="file" name="file"/>').hide();
					fileInput.change(function () {
						if(''==fileInput.val()||fileInput.val()==null)
							return
						$('.body').toggleLoading({
							msg: "导入中，请稍候...",
							iconUrl: '/images/loading.gif'
						});
						main.uploadWithRule($(this), {
							url: "station/importDevCapacity",
							params: {param:JSON.stringify({stationCode:S.addStationCode})},
							allComplete: function () {
								$('body').cancleLoading({
									msg: "导入结束",
									iconUrl: '/images/loading.gif'
								})
								$('.addDevTag').remove();
								S.capacitySetting.loadBindDevs();
							}
						});
						fileInput.val('');
					});
					$("#stationDeviceCap").empty().append(fileInput);
					fileInput.click();
				},
				loadBindDevs: function () {
					var url = '/station/getBindDev';
					var stationCode = S.addStationCode;
					var params = {"stationCode": stationCode};
					$.http.POST(url, params, function (res) {
						if (res && res.success) {
							var data = res.data;
							var collectors = data.collectorList;
							var dcDevs = data.aloneDevs;
							var btn = $("#addDev");
							var collectorsLength = collectors.length;
							var  devCapInfo = data.devCapInfo || {};
							for (var i = 0; i < collectorsLength; i++) {
								var collectorsData = collectors[i];
								var collector = collectorsData.collector;
								var collectorEsn = collector.esnCode;
								var collectorName = collector.busiName;
								var collectorType = collector.modelVersionCode;
								var pTypeVal = collector.devTypeId;
								var devIdVal = collector.id;
								var busiCodeVal = collector.busiCode;
								var regCodeVal = collector.devRegistCode;
								var devCap = devCapInfo[devIdVal];
								var newDevRecord = S.bindDev.addDevEle(true, collectorEsn, collectorName, collectorType, pTypeVal,
									devIdVal, busiCodeVal, regCodeVal,null,devCap,collector.businessType,collector);

								$('.addDevInfo').closest('.content').find('table').append(newDevRecord);
								var subdevs = collectorsData.subDevlist;
								if (subdevs) {
									var subLength = subdevs.length;
									var childrenDiv = $("<tr/>").attr("esnValidate", "esnValidate");
									if (pTypeVal == 13) { //通管机没有esn
										newDevRecord.find("input.devESN").attr("esnValidate", 'notValidate');
										childrenDiv.attr("esnValidate", 'notValidate');
									}
									S.bindDev.addChildDeiv(subdevs, childrenDiv, newDevRecord, true, 1,devCapInfo);
									if (subLength > 8) {
										var scrollWidth = App.getScrollbarWidth();
										var pWidth = '99%';
										if (scrollWidth <= 0) {//linux设备
											pWidth = '97%';
										}
										$(newDevRecord).find(".kids").find("p").css('width', pWidth);
									}
								}
								if(pTypeVal == 37 || pTypeVal == 235 || pTypeVal == 13) {
									newDevRecord.find("select.itemize").remove();
								}
								newDevRecord.find("b.dc:first").css("margin-left", "0px").off("click").on("click", function () {
									var $tr = $(this).parent().parent();
									var esnCode = $tr.attr('esnCode');
									$tr.siblings('tr[parentesn="' + esnCode + '"]').toggleClass("hideKids");
									$(this).toggleClass("dcOpen");
								});
							}
							var dcDevsLength = dcDevs.length;
							for (var k = 0; k < dcDevsLength; k++) {
								var collector = dcDevs[k];
								var collectorEsn = collector.esnCode;
								var collectorName = collector.busiName;
								var collectorType = collector.modelVersionCode;
								var pTypeVal = collector.devTypeId;
								var devIdVal = collector.id;
								var busiCodeVal = collector.busiCode;
								var regCodeVal = collector.devRegistCode;
								var devCap = devCapInfo[devIdVal];
								var newdcDevRecord = S.bindDev.addDevEle(true, collectorEsn, collectorName, collectorType, pTypeVal,
									devIdVal, busiCodeVal, regCodeVal,null,devCap, collector.businessType,collector);
								$('.addDevInfo').closest('.content').find('table').append(newdcDevRecord);
								var sunDevs = dcDevs[k].subDevList;
								if (sunDevs && sunDevs.length > 0) {
									var subLength = sunDevs.length;
									var childrenDiv = $("<tr/>").attr("esnValidate", "esnValidate");
									S.bindDev.addChildDeiv(sunDevs, childrenDiv, newDevRecord, true, 1,devCapInfo);
									if (subLength > 8) {
										var scrollWidth = App.getScrollbarWidth();
										var pWidth = '99%';
										if (scrollWidth <= 0) {//linux设备
											pWidth = '97%';
										}
										$(newdcDevRecord).find(".kids").find("p").css('width', pWidth);
									}
								}
								newdcDevRecord.find("b.dc:first").css("margin-left", "0px").off("click").on("click", function () {
									var $tr = $(this).parent().parent();
									var esnCode = $tr.attr('esnCode');
									$tr.siblings('tr[parentesn="' + esnCode + '"]').toggleClass("hideKids");
									$(this).toggleClass("dcOpen");
								});
							}
						} else {
						}
						S.capacitySetting.getInvs(true);
					});
				},
				/**
				 * 一键开站优化 组串容量设置
				 */
				setPvCapacity: function (dataArr) {
					if (dataArr && dataArr.length > 0) {
						// 未配置组串详情和组串容量
						var hascombiner_dc_t = false;
						$.each(dataArr, function (k, v) {
							if (v.devTypeId == 15) {
								hascombiner_dc_t = true;
							}
						});
						if (!hascombiner_dc_t) {
							if (S.isSetPvByDev) {
								S.capacitySetting.setPvByDev(dataArr);
							} else {
								S.capacitySetting.setPvByCapacity(dataArr);
							}
						}
					}
				},

				/**
				 * 按设备上报的额定容量和组串个数分配组串容量
				 */
				setPvByDev: function (dataArr) {
					function setPv(ratedCapacity, capNum, devArr) {
						ratedCapacity = parseFloat(ratedCapacity) * 1000;
						var pvCapMapVar = new Map();
						var averagePv = Math.round(ratedCapacity / capNum);
						S.capacitySetting.averageSetPv(pvCapMapVar, ratedCapacity, averagePv, capNum);
						parms = {pvCapMap: pvCapMapVar};
						S.capacitySetting.savePVCap(parms, devArr);
					}

					$.each(dataArr, function (i, v) {
						var ratedCapacity = v.pvCapacity.ratedCapacity;
						var capNum = v.pvCapacity.capNum;
						var devArr = [v];
						setPv(ratedCapacity, capNum, devArr);
					});
				},
				/**
				 * 未上报额定容量和组串个数，按装机容量平均分配组串容量
				 */
				setPvByCapacity: function (dataArr) {
					var values = $("#addStationCapacity").val();
					var totalcapacity = 0;
					if (values) {
						totalcapacity = parseFloat(values) * 1000;
					}
					var parm = {};
					var sizeInverte = dataArr.length;
					var averageCapacityInvert = Math.round(totalcapacity / sizeInverte);

					function setPv(Num) {
						var pvCapMapVar = new Map();
						var averagePv = Math.round(averageCapacityInvert / Num);
						S.capacitySetting.averageSetPv(pvCapMapVar, averageCapacityInvert, averagePv, Num);
						if (averageCapacityInvert * sizeInverte != totalcapacity) {
							var lastDevArray = [dataArr[dataArr.length - 1]];
							var devArrays = [];
							for (var i = 0; i < dataArr.length - 1; i++) {
								devArrays.push(dataArr[i]);
							}
							parms = {pvCapMap: pvCapMapVar};
							S.capacitySetting.savePVCap(parms, devArrays);
							var reObj = averageCapacityInvert - (Num - 1) * averagePv + totalcapacity - averageCapacityInvert * sizeInverte;
							pvCapMapVar.set(Num, reObj);
							parms = {pvCapMap: pvCapMapVar};
							S.capacitySetting.savePVCap(parms, lastDevArray);
						} else {
							parms = {pvCapMap: pvCapMapVar};
							S.capacitySetting.savePVCap(parms, dataArr);
						}
					}

					if (averageCapacityInvert <= 10 * 1000) {
						setPv(2);
					} else if (averageCapacityInvert > 10 * 1000 && averageCapacityInvert <= 20 * 1000) {
						setPv(3);
					} else if (averageCapacityInvert > 20 * 1000 && averageCapacityInvert <= 40 * 1000) {
						setPv(8);
					} else if (averageCapacityInvert > 40 * 1000 && averageCapacityInvert <= 60 * 1000) {
						setPv(12);
					}
//                  else {
//                      $.each(dataArr, function (k, v) {
//                          if (v.capacity)
//                              v.capacity = null;
//                      });
//                      S.capacitySetting.initDevList(dataArr);
//                  }
				},
				/**
				 * 平均分配组串容量
				 */
				averageSetPv: function (pvCapMapVar, capacity, averagePv, capNum) {
					for (var i = 1; i <= capNum; i++) {
						if (i == capNum) {
							pvCapMapVar.set(i, (capacity - (capNum - 1) * averagePv));
						} else {
							pvCapMapVar.set(i, averagePv);
						}
					}
				},

				savePVCap: function (parms, devInfo) {
					if (parms) {
						var pvMap = parms.pvCapMap;
						var totalCap = 0;
						if (pvMap) {
							var pv = Object.keys(pvMap);
							$.each(pv, function (i, v) {
								totalCap += Number(pvMap[v]);
							});
						}
						totalCap = totalCap / 1000;
						$.each(devInfo, function (i, e) {
							var obj = {};
							obj.id = e.id;
							//查看是否配置了组件信息
							if (!pvModuleDevList.contains(e.id)) {
								//没配置组件信息，配置容量才生效，否则跳过
								S.capacitySetting.savePVCapInfor(e, totalCap, pvMap);
								curDev.get(e.devTypeId).get(e.id).capacity = totalCap;
							}
						});
						$('#invInfo').GridTableRefreshPage();
					}
				},

				//更新PV信息
				savePVCapInfor: function (dev, totalCap, pvMap) {
					var obj = {};
					obj.id = dev.devId;
					obj.busiCode = dev.busiCode;
					obj.devTypeId = dev.devTypeId;
					obj.esnCode = dev.esnCode;
					var pvcapMap = new Map();
					pvMap && $.each(pvMap,function(t,e){
						pvcapMap.set(parseInt(t),e);
					});
					obj.pvCapMap = pvcapMap;
					pvCapMap.set(dev.devId, obj);
				},


			},

			// 单价设置
			priceSetting: {
	            initToolBar: function() {
	                var dateFmt = Msg.dateFormat.yyyymmdd;
	                var defaultDate = new Date().format(dateFmt, true);
	                // 日期选择面板初始化
	                $('#price_search_time').val(defaultDate).off('click').on('click', function(params) {
	                    DatePicker({
	                        dateFmt : dateFmt,
	                        // isShowClear : true,
							isShowToday: true
	                    });
	                })
	                $('#price_dbtn_search').off('click').on('click', function(e) {
						$(".defaultPrice").find(".dateDim:visible span.selected").click();
	                });
	            },

				init: function () {
					S.priceSetting.initToolBar();
					$('.defaultPrice').find('.dateDim span').off('click').click(function (e) {
						var _this = $(e.target);
						var _dateType = _this.attr("date-type");
						_this.parent().parent().find(".dateDim span").removeClass("selected");
						_this.addClass("selected");
						var $table = _this.parent().parent().parent().parent().find('table');
						var typeNum = $table.attr("price-type");
						$table.find('.priceDataRow').remove();
						if (_dateType == "yes") {
							var domainId = $("#domain").attr("treeselid");
							S.priceSetting.initDefaultPrice(domainId, [$table.attr("price-type")]);
							$table.find('tr:last').hide();
							$table.find('.operate').hide();

						} else {
							$table.find('tr:last').show();
							$table.find('.operate').show();
							$table.find('.addRowBtn').trigger('click');
							$(".beginTime").find('input').removeAttr("disabled");
							$(".endTime").find('input').removeAttr("disabled");
						}
					});
				},
				/**
				 * 事件绑定
				 */
				priceTypeClick: function () {
					$("#priceType").find('.dateDim span').off('click').click(function (e) {
						var _this = $(e.target);
						var _dateType = _this.attr("date-type");
						_this.parent().parent().find(".dateDim span").removeClass("selected");
						_this.addClass("selected");
						S.priceSetting.dateDim = _dateType;
						S.priceSetting.loadPriceTab(_dateType);

						var selectedPtype = $('#priceType').find('.dateDim .selected');
						var isDefault = $('.price-detail[data-type=' + selectedPtype.attr('date-type') + ']').find('.dateDim span[date-type="yes"]').hasClass('selected');
						var _op = $('.price-detail').find('.' + selectedPtype.attr('date-type')).find('.operate');
						if(isDefault){
							_op.hide();
						}else{
							_op.show();
						}
					});
				},
				/**
				 * 光伏		上网电价、售电电价
				 * 储能		充电电价、放电电价
				 * 充电桩	购电电价、充电电价
				 * 配电室	购电电价
				 * 空调机房	购电电价
				 * 换热站	购热单价
				 * 照明	购电电价
				 * @param {Object} type
				 * @param {Object} hasClass
				 */
				changeType: function (type, hasClass) {
					$('#priceType .dateDim span').hide();
					$('.price-tabs .price-detail').hide();

					var firstItemName = "usedPowerPrice";
					if (type == "ICLEAN") {
						//光伏
						firstItemName = "onGridPowerPrice";
						$("#priceType").find('.dateDim span[date-type="onGridPowerPrice"]').show();
						$("#priceType").find('.dateDim span[date-type="usedPowerPrice"]').show();
					}else if(type == "IE" || 'LIGHT' == type || 'COLD' == type ){
						$("#priceType").find('.dateDim span[date-type="usedPowerPrice"]').show();
						if(type == "IE" && !App.isJK){
							$("#priceType").find('.dateDim span[date-type="usedWaterPrice"]').show();
							$("#priceType").find('.dateDim span[date-type="usedGasPrice"]').show();
						}
					}else if('STORE' == type){
						//储能
						firstItemName = "storePrice";
						$("#priceType").find('.dateDim span[date-type="storePrice"]').show();
						$("#priceType").find('.dateDim span[date-type="storeOutPrice"]').show();
					}else if('CHARGE' == type){
						firstItemName = "usedPowerPrice";
						//充电桩
						$("#priceType").find('.dateDim span[date-type="usedPowerPrice"]').show();
						$("#priceType").find('.dateDim span[date-type="chargePrice"]').show();
					}else if('HEAT' == type){
						firstItemName = "heatPrice";
						//换热站
						$("#priceType").find('.dateDim span[date-type="heatPrice"]').show();
					}
					S.priceSetting.priceTypeClick();
					$("#priceType").find('.dateDim span[date-type="'+firstItemName+'"]').click();
				},
				/**
				 * 加载电价tab
				 * @param {Object} dataType
				 */
				loadPriceTab: function (dataType) {
					$('.price-tabs .price-detail').hide();
					var showArr = {
						"usedPowerPrice":["usedPower"],
						"usedWaterPrice":["usedWater"],
						"usedGasPrice":["usedGas"],
						"onGridPowerPrice":["gridPower"],
						"storePrice":["storePriceItem"],
						"storeOutPrice":["storeOut"],
						"heatPrice":["heatPriceItem"],
						"chargePrice":["chargePriceItem"],
					};
					var showArrItem = showArr[dataType];
					$.each(showArrItem, function(t,e) {
						$('.price-tabs .'+e).show();
					});

					$('.addRowBtn').off('click').on('click', function (e) {
						S.priceSetting.addPriceRow(e);
					});
				},
				/**
				 * 添加电价项
				 * @param {Object} e
				 */
				addPriceRow: function (e) {
					var $this = $(e.target);
					var $thisTr = $this.parent().parent();
					var beginDate = new Date(Date.parseTime("01-01","MM-dd")).format(Msg.dateFormat.yyyymmdd);
					var endDate = new Date(Date.parseTime("12-31","MM-dd")).format(Msg.dateFormat.yyyymmdd);
					var beginTime = 0;
					var endTime = 24;
					// 初始化时间范围的开始时间与结束时间
					var $select = $('<select>').addClass('ele_type').append([
						$('<option value="1" >'+Msg.homePage.mixPage.highest+'</option>'),
						$('<option value="2" >'+Msg.homePage.mixPage.high+'</option>'),
						$('<option value="3" >'+Msg.homePage.mixPage.flat+'</option>'),
						$('<option value="4" >'+Msg.homePage.mixPage.minimum+'</option>')
					]);
					var $row = $('<tr>').addClass('priceDataRow').append([
						$('<td>').append($('<input class="Wdate beginDate" readonly value="' + beginDate + '"/><span>-</span><input class="Wdate endDate" readonly value="' + endDate + '"/>')),
						$('<td>').append($select),
						$('<td>').append([
							S.priceSetting.buildTimeSel('beginTime', double.double(beginTime), double.double(0)),
							$('<span>-</span>'),
							S.priceSetting.buildTimeSel('endTime', double.double(endTime), double.double(0))
							]),
						$('<td>').append($('<input class="price"/>')),
						$('<td class="operate">').append($('<button type="button" class="addPriceTimeBtn"></button><button type="button" class="delPriceTimeBtn"></button>'))
					]);
					if (S.priceSetting.dateDim == 'onGridPowerPrice') {
						$row.find('.ele_type').parent().remove();
					}
					if (S.priceSetting.dateDim == 'usedGasPrice' || S.priceSetting.dateDim == 'usedWaterPrice') {
						$row.find('.ele_type').val(3);
						$row.find('.ele_type').parent().hide();
					}
					if ($this.hasClass('addRowBtn')) {
						var $prevTr = $thisTr.prev('.priceDataRow');
						$row.addClass('parentRow');
						// 初始化日期范围的开始时间与结束时间
						if ($prevTr && $prevTr.length > 0) {
							$row.attr("priceDateNum", parseInt($prevTr.attr("priceDateNum")) + 1);
							var prevPricedatenum = $prevTr.attr("pricedatenum");
							beginDate = $prevTr.parent().find('tr.parentRow[pricedatenum="' + prevPricedatenum + '"]').find('.endDate').val();
	                       	beginDate = new Date(Date.parseTime(beginDate.replace("-", "/"), 'yyyy/MM/dd'));
	                        beginDate.setDate(beginDate.getDate()+1);
	                        endDate = new Date(Date.parseTime("12-31","MM-dd"));
	                        endDate.setFullYear(beginDate.getFullYear());
	                        beginDate = beginDate.format(Msg.dateFormat.yyyymmdd);
	                        endDate = endDate.format(Msg.dateFormat.yyyymmdd);
						} else {
							$row.attr("priceDateNum", 1);
						}
	                    $row.find('.beginDate').val(beginDate);
	                    $row.find('.endDate').val(endDate);
						$thisTr.before($row);
					} else {
						$this.hide();
						var priceDateNum = $thisTr.attr("priceDateNum");
						var thisTrVal = $($thisTr.find('.endTime').find('input')[0]).val();
						var thisTrValMin = $($thisTr.find('.endTime').find('input')[1]).val();
						// if((thisTrVal - 0) === 24){
						// 	App.alert(Msg.stationInfo.addStation.priceSettingList.fill24Over);
						// 	$this.show();
						// 	return false;
						// }
						$($row.find('.beginTime').find('input')[0]).val(thisTrVal);
						$($row.find('.beginTime').find('input')[1]).val(thisTrValMin);
						$row.attr("priceDateNum", priceDateNum);
						// 时间范围的设置合并日期设置单元格
						var $parentTr = $thisTr.siblings('tr.parentRow[priceDateNum="' + priceDateNum + '"]');
						$parentTr = $parentTr.length > 0 ? $parentTr : $thisTr;
						var rowspan = $parentTr.find('td:first').attr("rowspan");
						$parentTr.find('td:first').attr("rowspan", rowspan ? parseInt(rowspan) + 1 : 2);
						$row.find('td:first').remove();
						$row.addClass('child');
						$thisTr.after($row);
					}
					S.priceSetting.initPriceItemEvent();
				},
				initPriceItemEvent:function(){
					// 删除按钮
					$('.delPriceTimeBtn').off('click').on('click', function (et) {
						var $tr = $(et.target).parent().parent();
						$(".price-tabs .errorRed").tooltip("destroy");
						var priceDateNum = $tr.attr("priceDateNum");
						var $parentTr = $tr.siblings('tr.parentRow[priceDateNum="' + priceDateNum + '"]');
						var $sibTr = $tr.siblings('tr.child[priceDateNum="' + priceDateNum + '"]');
						if ($parentTr.length <= 0 && $sibTr.length <= 0) {
							//前后都无
							$tr.remove();
						} else if ($parentTr.length > 0 && $sibTr.length <= 0) {
							//前有后无
							var rowspan = $parentTr.find('td:first').attr("rowspan");
							$parentTr.find('td:first').attr("rowspan", rowspan ? parseInt(rowspan) - 1 : 1);
							$parentTr.find('.addPriceTimeBtn').show();
							$tr.remove();
						} else if ($parentTr.length > 0 && $sibTr.length > 0) {
							var rowspan = $parentTr.find('td:first').attr("rowspan");
							$parentTr.find('td:first').attr("rowspan", rowspan ? parseInt(rowspan) - 1 : 1);
							//前有后无
							if ($tr.attr("priceDateNum") != $tr.next().attr("priceDateNum")) {
								$tr.prev().find('td:last').find('.addPriceTimeBtn').show();
							}
							//中间子元素
							$tr.remove();
						} else if ($parentTr.length <= 0 && $sibTr.length > 0) {
							// 无父有子
							var nextBeginTime = $tr.next().find('.beginTime').val();
							var nextEndTime = $tr.next().find('.endTime').val();
							var $timeType = $tr.next().find('.ele_type');
							var price = $tr.next().find('.price').val();
							if ($timeType.length > 0) {
								$tr.find('.ele_type').val($timeType.val());
							}
							var rowspan = $tr.find('td:first').attr("rowspan") - 1;
							$tr.find('.beginTime').val(nextBeginTime);
							$tr.find('.nextEndTime').val(nextEndTime);
							$tr.find('.price').val(price);
							$tr.next().remove();
							$tr.find('td:first').attr("rowspan", rowspan);
							if ($tr.attr("priceDateNum") != $tr.next().attr("priceDateNum")) {
								$tr.find('td:last').find('.addPriceTimeBtn').show();
							}
						}
					});
					// 时间设置新增按钮
					$('.addPriceTimeBtn').off('click').on('click', function (t) {
						S.priceSetting.addPriceRow(t);
					});
	                $('.beginDate, .endDate').off('click').on('click', function (e) {
	                    var startDate = $(e.target).val() || new Date(Date.parseTime("01-01","MM-dd")).format(Msg.dateFormat.yyyymmdd);
	                    DatePicker({
	                        dateFmt: Msg.dateFormat.yyyymmdd,
	                        startDate:startDate,
	                        alwaysUseStartDate:true
	                    });
	                });
				},
				/**
				 * 初始化默认电价
				 */
				initPricePage: function () {
					var domainId = $("#domain").attr("treeselid");
					var defaultPriceType = [];
					var $defaultType = $('.defaultPrice');
					$defaultType.each(function () {
						var priceType = $(this).attr('price-type');
						defaultPriceType.push(priceType);
					});
					S.priceSetting.initDefaultPrice(domainId, defaultPriceType);
				},
				/**
				 * 获取默认电价数据
				 */
				initDefaultPrice:function(domainId,priceType,stationCode,func1, func2, cb){
					domainId = domainId || sessionStorage.getItem('curDomain');
					if(domainId == 1) {
						console.info("不显示托管域默认电价");
						return;
					}
					var param = {};
					param.domainId = domainId;
					param.priceTypes = priceType;
					param.stationCode = stationCode || "system";
					param.queryTime = $("input#price_search_time").val().replace(/-/g, '\/');
                	param.queryTime = Date.parseTime(param.queryTime ,"yyyy/MM/dd",8);
					$.http.ajax('/ongridprice/queryDefaultPrice', param, function(data){
						if(data && data.success) {
							if(!data.data) {
								if(cb && typeof(cb) == "function") {
									cb();
								}
								return;
							}
							var result = data.data;
							S.priceSetting.dealGetPriceData(result, func1, func2, cb);
						} else {
							App.alert(Msg.stationInfo.addStation.loadDefaultPriceError);
							if(cb && typeof(cb) == "function") {
								cb();
							}
							return;
						}
						//设置当前选择项默认电价不可操作
						var selectedPtype = $('#priceType').find('.dateDim .selected');
						var isDefault = $('.price-detail[data-type=' + selectedPtype.attr('date-type') + ']').find('.dateDim span[date-type="yes"]').hasClass('selected');
						var _op = $('.price-detail').find('.' + selectedPtype.attr('date-type')).find('.operate');
						if(isDefault) {
							_op.hide();
						} else {
							_op.show();
						}
					});
				},

				/**
				 * 初始化电价
				 * @param {Object} secondDomain
				 * @param {Object} domainId
				 * @param {Object} stationId
				 * @param {Object} type
				 * @param {Object} flag
				 * @param {Object} tabType
				 * @param {Object} func1
				 * @param {Object} func2
				 * @param {Object} cb
				 */
				initPrice: function (secondDomain, domainId, stationId, type, flag, tabType, func1, func2, cb) {
					var param = {};
					if (secondDomain) {
						param.secondDomain = secondDomain;
					}
					if (domainId) {
						param.domainId = domainId;
					}
					if (stationId) {
						param.stationId = stationId;
					}
					param.priceType = tabType;
					$.http.ajax('/ongridprice/queryGridPrice', param,
						function (data) {
							if (data && data.success) {
								if (!data.data) {
									if (cb && typeof (cb) == "function") {
										cb();
									}
									return;
								}
								var result = data.data;
								S.priceSetting.dealGetPriceData(result, func1, func2, cb);
							} else {
								App.alert(Msg.stationInfo.addStation.loadDefaultPriceError);

								if (cb && typeof (cb) == "function") {
									cb();
								}
								return;
							}
							var selectedPtype = $('#priceType').find('.dateDim .selected');
							var isDefault = $('.price-detail[data-type=' + selectedPtype.attr('date-type') + ']').find('.dateDim span[date-type="yes"]').hasClass('selected');
							var _op = $('.price-detail').find('.' + selectedPtype.attr('date-type')).find('.operate');
							if(isDefault){
								_op.hide();
							}else{
								_op.show();
							}
						}, null, false);
				},
				/**
				 * 处理获取到的电价数据
				 * @param {Object} result
				 * @param {Object} func1
				 * @param {Object} func2
				 * @param {Object} cb
				 */
				dealGetPriceData:function(result, func1, func2, cb){
					if(!result) return;
					var length = result.length;
					var hasClean= {};
					for(var i = 0; i < length; i++) {
						var $dom = [];
						var priceT = result[i];
						var priceH = priceT["price"];
						//是否是默认电价
						var isDefault = priceH.stationCode == "system";
						var priceItem = priceT["priceItem"];
						var disabled = isDefault ? "disabled" : "";
						var priceTagIndex = i + '';
						var priceId = priceH.id;
						var beginDateTime = priceH.beginDate;
						var endDateTime = priceH.endDate;
						var priceType = priceH.priceType;
						if(!hasClean[priceType]){
							//最开始清理一次
							$('.price-tabs').find('table[price-type="' + priceType + '"]').find("tr.priceDataRow").remove();
							hasClean[priceType] = true;
						}
						if(isDefault){
							$('.price-tabs').find('table[price-type="' + priceType + '"]').find("tr:last").hide();
						}else{
							$('.price-tabs').find('table[price-type="' + priceType + '"]').find("tr:last").show();
						}
						var timeZoneId = Date.getTimezone();;
						beginDateTime -= timeZoneId * 3600 * 1000;
						endDateTime -= timeZoneId * 3600 * 1000;
						var beginDate = Date.parse(beginDateTime, timeZoneId).format(Msg.dateFormat.yyyymmdd);
						var endDate = Date.parse(endDateTime, timeZoneId).format(Msg.dateFormat.yyyymmdd);
						var itemsLength = priceItem.length;
						var $rangeDate = $('<td>').attr("rowspan", itemsLength).append($('<input class="beginDate Wdate" readonly '+disabled+' value="' + beginDate + '" /><span>-</span><input class="endDate Wdate" readonly '+disabled+' value="' + endDate + '"/>'));
						for(var j = 0; j < itemsLength; j++) {
							priceTagIndex += j;
							var item = priceItem[j];
							var price = item.price || "";
							var timeType = item.timeType;
							var beginHour = item.beginHour;
							var endHour = item.endHour;
							var itemId = item.id;
							var beginMin = item.beginMin;
							var endMin = item.endMin;
							//
							var $tr = $('<tr>').addClass("priceDataRow").attr("pricedatenum", i);

							var $timeTypeTd = $('<td>').append($('<select '+disabled+' >').addClass('ele_type').append([
								$('<option value="1" class="i18n">'+Msg.homePage.mixPage.highest+'</option>'),
								$('<option value="2" class="i18n">'+Msg.homePage.mixPage.high+'</option>'),
								$('<option value="3" class="i18n">'+Msg.homePage.mixPage.flat+'</option>'),
								$('<option value="4" class="i18n">'+Msg.homePage.mixPage.minimum+'</option>')
							]));
							var $beginTime = S.priceSetting.buildTimeSel('beginTime', double.double(beginHour), double.double(beginMin));
							var $endTime = S.priceSetting.buildTimeSel('endTime', double.double(endHour), double.double(endMin));
							$beginTime.find('option[value="' + beginHour + '"]').attr('selected', "selected");
							$endTime.find('option[value="' + endHour + '"]').attr('selected', "selected");
							if(isDefault){
								$beginTime.find('input').attr("disabled", "disabled");
								$endTime.find('input').attr("disabled", "disabled");
							}
							var $timeDateTd = $('<td>').append([$beginTime, $('<span>-</span>'), $endTime]);

							var $priceTd = $('<td>').append($('<input class="price" '+disabled+' value="' + price + '"/>'));
							var $delTd = $('<td class="operate">').append($('<button type="button" class="addPriceTimeBtn"></button><button type="button" class="delPriceTimeBtn"></button>'));
							if(j == 0) {
								$tr.addClass('parentRow');
								$tr.append($rangeDate);
							}
							//上网电价无 尖 峰平 谷
							if(priceType != 1 && priceType != 3 && priceType != 4) {
								$timeTypeTd.find('option[value="' + timeType + '"]').attr("selected", "selected");
								$tr.append($timeTypeTd);
							}
							$tr.append([$timeDateTd, $priceTd, $delTd]);
							$dom.push($tr);
						}
						$('.price-tabs').find('table[price-type="' + priceType + '"]').find('tr:last').before($dom);
						$('.price-tabs').find('.defaultPrice[price-type="' + priceType + '"]').find('.dateDim span').removeClass("selected");
						if(isDefault){
							//默认电价
							$('.price-tabs').find('table[price-type="' + priceType + '"]').find('.operate').hide();
							$('.price-tabs').find('.defaultPrice[price-type="' + priceType + '"]').find('.dateDim span[date-type="yes"]').addClass('selected');
						}else{
							$('.price-tabs').find('table[price-type="' + priceType + '"]').find('.operate').show();
							$('.price-tabs').find('.defaultPrice[price-type="' + priceType + '"]').find('.dateDim span[date-type="no"]').addClass('selected');
						}

					}

					//如果电站为710同步电站, 则电价设置不可编辑
					if(func1 && typeof(func1) == "function") {
						func1(4);
					}
					if(func2 && typeof(func2) == "function") {
						func2(4);
					}

					if(cb && typeof(cb) == "function") {
						cb();
					}
				},
				buildTimeSel: function (className, valHour, valMin) {
					var inputHour = $('<input type="number" style="width: 35px" max="24" class="timeInput" onkeypress="return(/[\\d]/.test(String.fromCharCode(event.keyCode)))">');
					var mao = $('<span>:</span>');
					var inputMin = $('<input type="number" style="width: 35px" max="59" class="timeInput" onkeypress="return(/[\\d]/.test(String.fromCharCode(event.keyCode)))">');
					inputHour.val(double.double(valHour));
					inputMin.val(valMin ? valMin : double.double(0));
					var $sel = $('<div>')
						.addClass(className)
						.css({
							'width': '100px',
							'margin': 'auto',
							'display': 'inline-block'
						})
						.append(inputHour)
						.append(mao)
						.append(inputMin);
					if(className === 'beginTime') {
						inputHour.val(double.double(valHour)).blur(S.priceSetting.event(23));
						inputMin.blur(S.priceSetting.blurVal(inputHour, inputMin, 30, className));
					}else if (className === 'endTime'){
						inputHour.blur(S.priceSetting.blurVal(inputHour, inputMin, 24, className));
						inputMin.blur(S.priceSetting.blurVal(inputHour, inputMin, 30, className));
					}
					return $sel;
				},
				blurVal: function($hour, $min, val, className){
					return function(){
						var flag = $($min.parent().parent().parent()[0]).attr('class').contains('parentRow');
						if((($hour.val() - 0) === 24) || (($hour.val() - 0) === 0 && className === 'beginTime' && flag )){
							$min.val(double.double(0));
						}else {
							var valB = val === 24 ? $hour.val() : $min.val();
							var $one = val === 24 ? $hour : $min;
							if(valB - 0 > val){
								$one.val(double.double(val));
							}else if((valB - 0) <= 0){
								$one.val(double.double(0));
							}else {
								if (val != 24){
									if ((valB - 0) >= 15 ){
										$one.val(double.double(30));
									}else {
										$one.val(double.double(0));
									}
								}else {
									$one.val(double.double(valB));
								}
							}
						}
					}
				},
				event: function (val) {
					return function (e) {
						if ($(e.target).val() - 0 > val) {
							$(e.target).val(double.double(val));
						}else if ($(e.target).val() - 0 <= 0) {
							$(e.target).val(double.double(0));
						}else{
							$(e.target).val(double.double($(e.target).val()))
						}
					}
				},
				buildPrice: function (data) {
					var result = data;
					var length = result.length;
					var $dom = [];
					for (var i = 0; i < length; i++) {
						var priceT = result[i];
						var priceH = priceT["price"];
						var priceItem = priceT["priceItem"];
						var priceTagIndex = i + '';
						var priceId = priceH.id;
						var beginDateTime = priceH.beginDate;
						var endDateTime = priceH.endDate;
						var priceType = priceH.priceType;
						var timeZoneId = Date.getTimezone();
						beginDateTime -= timeZoneId * 3600 * 1000;
						endDateTime -= timeZoneId * 3600 * 1000;
						var beginDate = Date.parse(beginDateTime, timeZoneId).format(Msg.dateFormat.yyyymmdd);
						var endDate = Date.parse(endDateTime, timeZoneId).format(Msg.dateFormat.yyyymmdd);
						var itemsLength = priceItem.length;
						var $rangeDate = $('<td>').attr("rowspan", itemsLength).append($('<input class="Wdate beginDate"  value="' + beginDate + '" /><span>-</span><input class="Wdate endDate"  value="' + endDate + '"/>'));
						for (var j = 0; j < itemsLength; j++) {
							priceTagIndex += j;
							var item = priceItem[j];
							var price = item.price;
							var timeType = item.timeType;
							var beginHour = item.beginHour;
							var endHour = item.endHour;
							var itemId = item.id;
							//
							var $tr = $('<tr>').addClass("priceDataRow").attr("pricedatenum", i);

							var $timeTypeTd = $('<td>').append($('<select>').addClass('ele_type').append([
								$('<option value="1" class="i18n">'+Msg.homePage.mixPage.highest+'</option>'),
								$('<option value="2" class="i18n">'+Msg.homePage.mixPage.high+'</option>'),
								$('<option value="3" class="i18n">'+Msg.homePage.mixPage.flat+'</option>'),
								$('<option value="4" class="i18n">'+Msg.homePage.mixPage.minimum+'</option>')
							]));
							var $beginTime = S.priceSetting.buildTimeSel('beginTime');
							var $endTime = S.priceSetting.buildTimeSel('endTime');
							$beginTime.find('option[value="' + beginHour + '"]').attr('selected', "selected");
							$endTime.find('option[value="' + endHour + '"]').attr('selected', "selected");
							var $timeDateTd = $('<td>').append([$beginTime, $('<span>-</span>'), $endTime]);
							var $priceTd = $('<td>').append($('<input class="price"  value="' + price + '"/>'));
							var $delTd = $('<td class="operate">').append($('<button type="button" class="addPriceTimeBtn"></button><button type="button" class="delPriceTimeBtn"></button>'));
							if (j == 0) {
								$tr.addClass('parentRow');
								$tr.append($rangeDate);
							}
							if (priceType == 2) {
								$timeTypeTd.find('option[value="' + timeType + '"]').attr("selected", "selected");
								$tr.append($timeTypeTd);
							}
							$tr.append([$timeDateTd, $priceTd, $delTd]);
							$dom.push($tr);
						}

					}
					return $dom;
				}
			},

			// 其他信息
			otherInfo: {
				srcDiv:null,
				tempDiv:null,
				init: function () {
					//上传按钮
					$(".img-wrap.addPic").off("click").on("click", function () {
						$("#uploadDImg").trigger("click");
					});
					//上传按钮
					$("#uploadDImg").off("change").on("change", function () {
						S.otherInfo.uploadImg($(this), 'relatedDImg', 'uploadDImg');
					});
					$('#longitude').keyup(function (e) {
						$('#addStationAddress').attr("longitude", $(e.target).val())
					});
					$('#latitude').keyup(function (e) {
						$('#addStationAddress').attr("latitude", $(e.target).val());
					});
				},
				//上传图片
				uploadImg: function ($dom, relatedImg, uploadImg) {
					var selectedFile = $dom.val();
					var fileType = selectedFile.substring(selectedFile.lastIndexOf('.') + 1, selectedFile.length);
					var imageFormat = ['png','jpg','jpeg','bmp'];
					var dataType = 2;

					if(imageFormat.contains(fileType)){
						dataType = 1;
					}

					var callback = function (res) {
						//上传成功 重载<input type='file'>
						var p = $("#uploadDImg").parent();
						$("#uploadDImg").remove();
						p.append($('<input id="uploadDImg" type="file" class="hide" multiple="" accept="png,jpg,jpeg,bmp,WMV,wmv,Wm,asf,rm,RMVB,rmvb,ra,ram,mpg,mpeg,mpe,vob,dat,mov,3gp,mp4v,m4v,avi,flv,f4v,mp4,mkv">'));
						if (res && res.success) {
							//$("#" + uploadImg).val('');
							S.otherInfo.addImage(relatedImg, res);
						} else {
							App.alert(Msg.upgrade.uploadFailed)
						}
						S.otherInfo.init();
					};
					var error = function () {
						App.alert(Msg.defectManage.uploadError)
					};
					var formData = new FormData();
					formData.append("imgFile", $("#" + uploadImg)[0].files[0]);
					formData.append("fileType", "img,video");
					formData.append("serviceId", "1");
					formData.append("isConf", "true");
					formData.append("formId", "imgFile");
					formData.append("printName", $("#" + uploadImg).val());
					$.http.fileUpload("/fileManager/stationUploadImage", formData, callback, error, false);
				},

				//判断图片张数
				checkPictureNum: function ($dom, clazz) {
					var _div = $dom.find("." + clazz).closest("td").children();
					if (_div.length > 0) {
						return false;
					}
					return true;
				},
				checkFileCanPlay:function (fileId,serviceId,sunfunc){
					$.http.ajax('fileManager/fileIsExistAndFastDFSIsRunning',{fileId:fileId,serviceId:serviceId},function(res){
						if(res && res.success){
							sunfunc && _.isFunction(sunfunc) && sunfunc();
						}else{
							App.alert(Msg.systemSetting.videoInDeal);
						}
					});
				},
				/**
				 * 创建图片
				 * @param src
				 * @param params
				 * @returns {*|jQuery}
				 */
				createImage: function (src, params,stationCode) {
					params = params || {};
					var srcDiv = null;
					var temp = null;
					function del(e){
						var $this = $(e.target);
						S.otherInfo.deletePicture($this, $this.prev().attr("fileid"),stationCode);
					}
					var $wrap = $('<div />').addClass('img-wrap').addClass('img').attr("draggable",true);
					var $img = $('<img />').addClass('img-preview').attr('src', src).attr("fileid", params.filedId);
					if(params.filedId){
						var arr = params.filedId.split("_");
						if(arr[0]==="video"){
							$wrap.append($('<span >'+Msg.pinnetCollege.video +'</span>').addClass('img-type'))
							$img.off('click').on('click',function(e){
								var curFileId = $(e.target).attr("fileid").split("_");
								S.otherInfo.checkFileCanPlay(curFileId[1]+"_video",1,function(){
									var videoSrc = "/fileManager/downloadCompleteInmage?fileId=" + curFileId[1]+"_video" + "&serviceId=1" ;
									main.playVideo(videoSrc,function(url){
										var $videoDiv = $('<video id="stationV">').attr("src",url).attr("controls","controls").css({"width":"98%","height":"80%"});
										$videoDiv.attr("controlslist","nodownload  noremoteplayback");
										$videoDiv.attr("oncontextmenu","return false");
										$videoDiv[0]['disablePictureInPicture'] = true;
										App.dialog({
											title: Msg.systemSetting.videoPreview,
											width: 800,
											height: 463,
											id: "stationVideoOption",
											content: [$videoDiv],
										})
									});
								});
							});
							$wrap.append($img);
						}else{
						//	var $bigImg = $('<img />').addClass('img-preview big').attr('src', src).attr("fileid", params.filedId);
							$wrap.append($('<span>'+Msg.stationReport.image +'</span>').addClass('img-type'))
							$wrap.append($img);
						}
					}
					if (params.del) {
						var $del = $('<span />').addClass('glyphicon glyphicon-remove');
						$del.click(del);
						$wrap.append($del);
					}

					$wrap.off('dragstart').on('dragstart',function (e){
						if($(e.target).hasClass('img-wrap')){
							S.otherInfo.srcDiv = $(e.target);
							S.otherInfo.tempDiv = S.otherInfo.srcDiv.children();
						}else{
							S.otherInfo.srcDiv = $(e.target).parent();
							S.otherInfo.tempDiv = S.otherInfo.srcDiv.children();
						}
					})
					$wrap.off('dragover').on('dragover',function (e){
						e.preventDefault();
					})
					$wrap.off('drop').on('drop',function (e){
						e.preventDefault();
						if ($(e.target).hasClass('img-preview') && S.otherInfo.srcDiv !== $(e.target).parent()) {
							debugger;
							var $curDiv = $(e.target).parent();
							var $curChildren = $curDiv.children();

							S.otherInfo.srcDiv.children().remove();
							S.otherInfo.srcDiv.append($curChildren);
							//清空子元素
							$curDiv.children().remove();
							$curDiv.append(S.otherInfo.tempDiv);

							var $delSpan = $curDiv.find('.glyphicon-remove');
							$delSpan.click(del);
							var $img= $curDiv.find('.img-preview');
							var fileId = $img.attr("fileid");
							var fileIdArr = fileId.split("_");
							if("video" === fileIdArr[0]){
								$img.off('click').on('click',function(e){
									var curFileId = $(e.target).attr("fileid").split("_");
									S.otherInfo.checkFileCanPlay(curFileId[1]+"_video",1,function(){
										var videoSrc = "/fileManager/downloadCompleteInmage?fileId=" + curFileId[1]+"_video" + "&serviceId=1";
										main.playVideo(videoSrc,function(url){
											var $videoDiv = $('<video id="stationV">').attr("src",url).attr("controls","controls").css({"width":"90%","height":"80%"});
											$videoDiv.attr("controlslist","nodownload  noremoteplayback");
											$videoDiv.attr("oncontextmenu","return false");
											$videoDiv[0]['disablePictureInPicture'] = true;
											App.dialog({
												title: Msg.systemSetting.videoPreview,
												width: 800,
												height: 700,
												id: "stationVideoOption",
												content: [$videoDiv],
											})
										});
									});
								});
							}
						}
					})

					return $wrap;
				},
				//添加图片
				addImage: function (relatedImg, res,stationCode) {
					var _div = $("." + relatedImg).closest("div");
					var params = {};
					params.filedId = res.data;
					params.del = true;
					var src = "/fileManager/downloadCompleteInmage?fileId=" + res.data + "&serviceId=1&time=" + new Date().getTime();
					var $wrap = S.otherInfo.createImage(src, params,stationCode);
					_div.parent("td").prepend($wrap);
					var wraps = _div.parent("td").children(".img-wrap.img");
					if (wraps.length >= 3) {
						_div.parent("td").children(".addPic").hide();
					}
				},
				//图片删除  deleteFiles
				deletePicture: function ($dom, fileid,stationCode) {
					$.http.ajax('/fileManager/deleteFiles', {fileIds: fileid, serviceId: 1}, function (data) {
						if (data.success) {
							$("img[fileid='" + fileid + "']").closest("td").find(".addPic").show();
							$("img[fileid='" + fileid + "']").closest("div").remove();
							if (stationCode && data){
								$.http.ajax('/station/updateImage', {stationCode:stationCode,fileIds: fileid}, function (data) {

								});
							}

							$("#uploadDImg").show();
							App.alert(Msg.defectManage.delSuccess);
						} else {
							App.alert(Msg.defectManage.delFail);
						}
					});
				},
			},

			//
			cameraInfo: {
				init: function () {
					$("#cameraConectType").find('.dateDim span').click(function (e) {
						var _this = $(e.target);
						var _dateType = _this.attr("date-type");
						if (!_this.hasClass("selected")) {
							App.confirm(Msg.homePage.mixPage.exchangeTip, function () {
								_this.parent().parent().find(".dateDim span").removeClass("selected");
								_this.addClass("selected");
								S.cameraInfo.cameraConectType = _dateType;
								S.cameraInfo.changeType(_dateType, true);
							});
						}
					});
					//初始化为云接入
					S.cameraInfo.cameraConectType = 'cloud';
					S.cameraInfo.changeType("cloud", true);
				},
				changeType: function (type, flag) {
					var $tableC = $('.cameraInfo .content table');
					$tableC.empty();
					if (type == "classic") {
						$('.cameraInfo .content .isNokey').hide();
						$tableC.append([
							$('<tr>').append([
								$('<th width="25%">').text(Msg.partials.main.configuration.name),
								$('<th width="25%">').text(Msg.paramsSetting.renew.customerMan.table[3]),
								$('<th width="20%">').text(Msg.systemSetting.logManage.userName),
								$('<th width="20%">').text(Msg.userDialog.password),
								$('<th width="10%">').text(Msg.systemSetting.amendment.operation)
							]),
							$('<tr><td colspan="5"><button type="button" class="addTabRow"></button></td></tr>')
						]);
						//新增按钮点击
						$('.cameraInfo .content .addTabRow').off('click').on('click', function (e) {
							var $addTabRow = $(e.target);
							var $newRow = $('<tr>').addClass('cameraDataRow').append([
								$('<td><input class="cameraName" name="cameraName"/></td>'),
								$('<td><input class="ipAddress" name="ipAddress"/></td>'),
								$('<td><input class="userName" name="userName"/></td>'),
								$('<td><input class="password" name="password"/></td>'),
								$('<td><button type="button" class="delBtn"></button></td>')
							]);
							$addTabRow.parent().parent().before($newRow);
							$('.cameraInfo .content .delBtn').click(function (e) {
								$(e.target).parent().parent().remove();
							});
						});
					} else {
						//云接入Appkey点击事件
						$('.cameraInfo .content .isNokey').show();

						//数据列表
						$tableC.append([
							$('<tr>').append([
								$('<th width="25%">').text(Msg.limitManage.devName),
								$('<th width="25%">').text(Msg.partials.main.configuration.seriNum),
								$('<th width="15%">').text('AppKey'),
								$('<th width="15%">').text('Secret'),
								$('<th width="10%">').text(Msg.homePage.mixPage.quality),
								$('<th width="10%">').text(Msg.ivcurve.heads[5])
							]),
							$('<tr><td colspan="6"><button type="button" class="addTabRow"></button></td></tr>')
						]);
						//新增按钮点击
						$('.cameraInfo .content .addTabRow').off('click').on('click', function (e) {
							var $addTabRow = $(e.target);
							var $select = $('<select>').addClass('picQuality').attr("name", 'picQuality').append([
								$('<option value="1">'+Msg.maintenance.osIndex.fluent+'</option>'),
								$('<option value="2">'+Msg.maintenance.osIndex.HD+'</option>')
							]);
							var $newRow = $('<tr>').addClass('cameraDataRow').append([
								$('<td><input class="cameraName" name="cameraName"/></td>'),
								$('<td><input class="esn" name="esn"/></td>'),
								$('<td><input class="appKey" name="appKey"/></td>'),
								$('<td><input class="secret" name="secret"/></td>'),
								$('<td>').append($select),
								$('<td><button type="button" class="delBtn"></button></td>')
							]);
							$addTabRow.parent().parent().before($newRow);
							$('.cameraInfo .content .delBtn').click(function (e) {
								$(e.target).parent().parent().remove();
							});
						});
					}
					if (flag) {
						$('.cameraInfo .content .addTabRow').trigger('click');
					}
				},


			},

			util: {
				convertDate: function (dateStr) {
					return Date.parseTime("2000/" + dateStr.replace(/-/g, '\/'), "yyyy/" + Msg.dateFormat.MMdd, 8);
				},
				getRealLength: function (str) {
					///<summary>获得字符串实际长度，中文2，英文1</summary>
					var realLength = 0, len = str.length, charCode = -1;
					for (var i = 0; i < len; i++) {
						charCode = str.charCodeAt(i);
						if (charCode >= 0 && charCode <= 128) realLength += 1;
						else realLength += 2;
					}
					return realLength;
				},

				copyObject: function (source) {
					var result = {};
					for (var key in source) {
						result[key] = typeof source[key] === 'object' ? S.util().copyObject(source[key]) : source[key];
					}
					return result;
				},
				initDevTypes: function (dom) {
					$.http.ajax('/signalconf/getDevTypeInfo', {}, function (data) {
						if (data && data.success) {
							data.data.list.forEach(function (t, i) {
								// 查询到的每一个设备类型的选项添加
								var devTypeLangKey = t.languageKey;
								if (!!devTypeLangKey) {
									var opt = $("<option value=" + t.id + ">" + eval(devTypeLangKey) + "</option>");
								} else {
									var opt = $("<option value=" + t.id + ">" + t.name + "</option>");
								}
								if (!(t.id == '1' || t.id == '15' || t.id == '38' || t.id == '62')) {//其它类型过滤
									return;
								}
								dom.append(opt);
							})
						} else {
							App.alert(Msg.partials.main.hp.poverty.getFail || "获取数据失败!");
						}
					});
				},
				initDevType: function (dom, value, data) {
					var typeName = '';
					value = value.toString();
					switch (value) {
						case '1':
							typeName = Msg.devTypeLangKey.stringInverter;
							break;
						case '15':
							typeName = Msg.devTypeLangKey.dcBus;
							break;
						case '38':
							typeName = Msg.devTypeLangKey.householdInverter;
							break;
						case '62':
							typeName = Msg.devTypeLangKey.sanshoInverter;
							break;

					}
					dom.html(typeName);
					dom.parent().attr('title', typeName);
				},
				loadCapDialog: function (parmas) {
					var settingDialog = App.dialog({
						id: "capacityConfigDiaglog",
						title: Msg.partials.main.dm.stringCapacitySetting,
						width: 635,
						height: 500
					});
					settingDialog.loadPage({
						url: "/partials/main/systemSetting/stationInfo/capacitySetting.html",
						preload: "ecm/partials/main/systemSetting/stationInfo/capacitySetting"
					}, parmas, function () {
					});
				},

				/**
				 * 表单校验
				 * @param domId
				 * @returns {*|jQuery|*|*|*|*}
				 */
				valid: function (domId) {
					var dom = $("#" + domId);
					var val = dom.val().trim() || dom.val();
					if (!val || val == "-1") {
						dom.css("border-color", "red");
					}
					return val;
				},
				/**
				 * 获取当前时间是
				 * @param {Object} timeStr
				 */
				getDateIndex: function(timeStr){
	                var endTime = Date.parseTime(timeStr.replace(/-/g, '\/'), 'yyyy/MM/dd');
	                var beginTime = Date.parseTime('2000/01/01','yyyy/MM/dd');
	                return (endTime - beginTime)/(24*60*60*1000);
	            },
	            checkExistHourVal:function(arr,beginHour,beginMin,endHour,endMin){
	                if(beginMin != 0) {
	                    var t = beginHour*100+beginMin;
	                    if(!arr[t]){
	                        arr[t] = true;
	                    } else{
	                        return true;
	                    }
	                    beginHour++;
	                }
	                if(endMin != 0) {
	                    var t = endHour*100;
	                    if(!arr[t]){
	                        arr[t] = true;
	                    } else{
	                        return true;
	                    }
	                }

	                for(var i = beginHour; i<endHour;i++){
	                    var t = i*100
	                    if(!arr[t]){
	                        arr[t] = true;
	                    } else{
	                        return true;
	                    }
	                    t+=30;
	                    if(!arr[t]){
	                        arr[t] = true;
	                    } else{
	                        return true;
	                    }
	                }
	                return false;
	            },
				/**
				 * 监测数组在beginIndex 和 endIndex是否有值存在
				 * @param {Object} arr
				 * @param {Object} beginIndex
				 * @param {Object} endIndex
				 */
				checkArrExistVal:function(arr,beginIndex,endIndex){
					for(var i = beginIndex; i<=endIndex;i++){
						if(!arr[i]){
							arr[i] = true;
						}else{
							return true;
						}
					}
					return false;
				},
				/**
				 * 获取给定元素 attr属性值得全集
				 * @param {Object} ele
				 */
				getElePricedatenumArr:function(ele,attr){
					var arr = [];
					if(ele){
						$.each(ele,function(t,e){
							var pricedatenum = $(e).attr(attr);
							if(arr.indexOf(pricedatenum) < 0){
								arr.push(pricedatenum);
							}

						});
					}
					return arr;
				},
				/**
				 * 检测长度和所有值是否都是true
				 * @param {Object} arr
				 * @param {Object} len
				 */
				checkLenthTrue:function(arr,len){
					if(!arr || arr.length<len) return false;
					for(var i = 0;i<len;i++){
						if(!arr[i]) return false;
					}
					return true;
				},
				/**
				 * [-11034,8844.43] 不超过2位小数
				 * 海拔监测
				 */
				checkMeanAltitude: function(meanAltitude) {
					if(!meanAltitude) return false;
					var dot = meanAltitude.indexOf(".");
					if(dot != -1) {
						var len = meanAltitude.substring(dot + 1).length;
						if(len > 2) {
							return false;
						}
					}
					if(!$.isNumeric(meanAltitude)) return false;
					var meanAltitude = Number(meanAltitude);
					if(meanAltitude < -11034 || meanAltitude > 8844.43) {
						return false;
					}
					return true;
				},
				// 必填项校验
				itemValid: function (page, systemIds) {
					var _this = this;
					var totalFlag = true;
					if (page == 1) {  //基本信息校验
						var stationName = S.util.valid("addStationName");                     //电站名称
						var gridTime = $("#addStationGridTime").val();                    //并网时间
						var safeRunTime = $("#safe_running_beginDate").val();                    //安全运行开始时间
						var domain = S.util.valid("domain");
						var contact = $("#addStationLink");                               //联系人
						var phone = $("#addStationPhone");                            //联系电话
						var voltageClass = $("#voltageClass","#addStationDialogN").val();
						var installCapity = $("#addStationInstallCapity").val();
						// 光伏和电务校验
						if (installCapity && isNaN(installCapity)) {
							totalFlag = false;
							App.alert(Msg.homePage.mixPage.addStationErrorTip1);
							return false;
						}
						if (systemIds && systemIds.contains("iesp_ee") || systemIds.contains("iesp_ie")) {
							if (!voltageClass) {
								totalFlag = false;
								App.alert(Msg.homePage.mixPage.addStationErrorTip2);
								return false;
							}
						}
						if (!domain) {
							$("#domain").css("border-color", "red")
								.tooltip({
									title: Msg.stationInfo.addStation.domainRule,
									placement: "top"
								});
							totalFlag = false;
						}
						var reg = /^[^\'\<\>,\/\&\"\“\”\，\‘\’']*$/;
						if (!stationName || S.util.getRealLength(stationName) > 60 || !reg.test(stationName) || stationName.indexOf("null") != -1) {
							$("#addStationName").css("border-color", "red")
								.tooltip({
									title: Msg.stationInfo.addStation.stationNameLimit,
									placement: "top"
								});
							totalFlag = false;
						}

						if (S.nameRepeatFlag) {
							totalFlag = false;
						}
						if (S.util.getRealLength(contact.val()) > 30) {
							contact.css("border-color", "red").tooltip({
								title: Msg.stationInfo.addStation.linkManTip,
								placement: "right"
							});
							totalFlag = false;
						} else {
							contact.tooltip("destroy");
						}


						var addr = $("#addStationAddress").val().trim();                   //电站地址
						var longitude = $("#addStationAddress").attr("longitude");
						var latitude = $("#addStationAddress").attr("latitude");
						if (!addr) {
							$("#addStationAddress").css("border-color", "red").tooltip({
								title: 	Msg.stationInfo.addStation.addrNotEmpty,
								placement: "top"
							});
							totalFlag = false;
						}else if (addr && S.util.getRealLength(addr) > 200) {
							$("#addStationAddress").css("border-color", "red").tooltip({
								title: Msg.stationInfo.addStation.stationAddressTip,
								placement: "top"
							});
							totalFlag = false;
						} else {
							$("#addStationAddress").css("border-color", "").tooltip("destroy");
						}

						var chargeUserId = $("#chargeUserName").attr("userid")
						if(!chargeUserId){
							$("#chargeUserName").css("border-color", "red").tooltip({
								title: 	Msg.stationInfo.addStation.mustStationOwner,
								placement: "top"
							});
							totalFlag = false;
						}else{
							$("#chargeUserName").css("border-color", "").tooltip("destroy");
						}

						if((!longitude) || _.isNaN(longitude - 0)){
							$("#longitude").css("border-color", "red").tooltip({
								title: Msg.stationInfo.addStation.longitudeTip,
								placement: "top"
							});
							totalFlag = false;
						}else{
							$("#longitude").css("border-color", "").tooltip("destroy");
						}

						if ( (!latitude) || _.isNaN(latitude - 0)) {
							$("#latitude").css("border-color", "red").tooltip({
								title: Msg.stationInfo.addStation.latitudeTip,
								placement: "top"
							});
							totalFlag = false;
						}else{
							$("#latitude").css("border-color", "").tooltip("destroy");
						}
					} else if (page == 2) {  //第二页
						var esnFlag = true;
						$("tr.addDevTag").each(function () {
							var tagFlag = true;
							// 新接入设备的校验
							$(this).find("input.devESN[esnValidate!='notValidate']").each(function () {
								var esnT = $(this).val();
								if (!esnT) {
									$(this).css("border-color", "red");
									esnFlag = false;
									return false;
								} else if ($(this).attr("isBind") == "yes") {
									esnFlag = false;
									return false;
								} else {
									$(this).css("border-color", "");
								}
							});
							if($(this).attr("add") != 'add'){
								//已经绑定的不再校验，就不校验不过也不能修改
								$(this).find("input.devName").each(function () {
									var nameT = $(this).val();
									if (!nameT) {
										$(this).css("border-color", "red");
										esnFlag = false;
										tagFlag = false;
										return false;
									} else {
										$(this).css("border-color", "");
									}
									var reg = /^[^\'\<\>,\/\&\"\“\”\，\‘\’']*$/;
									if (!nameT || !reg.test(nameT) || nameT.indexOf("null") != -1) {
										$(this).attr("title", "");
										$(this).css("border-color", "red").tooltip({
											title: Msg.stationInfo.addStation.devNameCheck,
											placement: "top"
										});
										esnFlag = false;
										tagFlag = false;
									} else {
										$(this).css("border-color", "").tooltip('destroy');
									}
								});
							}
							if ($(this).children().length == 2) {
								if (!tagFlag) {
									$(this).attr("title", "");
									$(this).css("border-color", "red").tooltip({
										title: Msg.stationInfo.addStation.childDevNameError,
										placement: "bottom",
										container: $(".addTab2")
									});
								} else {
									$(this).css("border-color", "").tooltip('destroy');
								}
							} else {
								$(this).css("border-color", "").tooltip('destroy');
							}
						});

						if (!esnFlag) {
							return false;
						} else {
							return true;
						}
					} else if (page == 3) {  //第三页电价设置
						//循环当前配置的电价
						var reg = /(^[1-9]\d*(\.\d{1,8})?$)|(^[0]{1}(\.\d{1,8})?$)/;
						var showPriceSpan = $('#priceType .dateDim span:visible');
						$(".price-tabs .errorRed").removeClass("errorRed");
						for(var i = 0; i<showPriceSpan.length;i++){
							var e = showPriceSpan[i];
							var dataType = $(e).attr("date-type");
							//每个电价类型单独出来
							var priceDetail = $('.priceSetting .price-tabs .price-detail[data-type="'+dataType+'"]');
							//是否使用默认电价选择
							var defaultPriceSel = priceDetail.find(".defaultPrice span.selected").attr('date-type');
							if(defaultPriceSel == "no"){//默认电价不校验，就算开始有问题 此处也不能修改默认电价
								//共设置了多少个时间段
								var totalTimeSel = S.util.getElePricedatenumArr(priceDetail.find("."+dataType+" tr.priceDataRow"),"pricedatenum");
								var priceInput = priceDetail.find("."+dataType+" tr.priceDataRow .price");
								//是否有输入框未填单价,或者电价填写错误
								var hasEmptyInput = false,hasErrorPrice = false;
								var error;
								priceInput && $.each(priceInput,function(t,e1){
									var priceT = $(e1).val();
									if(!priceT){
										hasEmptyInput = true;
										error = Msg.stationInfo.addStation.priceSettingList.plsFillinPriceinfo;
									}else{
										//电价校验
										if(reg.test(priceT) != true || priceT > 10000) {
											error = Msg.stationInfo.addStation.priceSettingList.plsFillinPriceCorrectly;
											hasErrorPrice = true;
										}
									}
									if(error){
										$(e1).addClass("errorRed").tooltip({
											title: error,
											placement: "top",
											container: "body"
										});
									}
								});
								//未设置时间段或者存在未添加单价 直接return
								if(!totalTimeSel || totalTimeSel.length<=0 || hasEmptyInput || hasErrorPrice){
									App.alert(error || Msg.stationInfo.addStation.priceSettingList.plsFillinPriceinfo);
									totalFlag = false;
									!priceDetail.is(":visible") && ($(e).click());
									break;
								}
								var dayArr = {};
								for(var j = 0; j<totalTimeSel.length;j++){
									//每一行的tr
									var timeSel = priceDetail.find("."+dataType+" tr.priceDataRow[pricedatenum="+(totalTimeSel[j])+"]");
									var hours={};
									var hourMill = [];
									var beginDate = $(timeSel[0]).find(".beginDate").val();
									var endDate = $(timeSel[0]).find(".endDate").val();
									var beginDateIndex = S.util.getDateIndex(beginDate);
									var endDateIndex = S.util.getDateIndex(endDate);
									var dayError,hourError;//天是否存在错误，错误信息，小时是否存在错误
									if(beginDateIndex > endDateIndex){
										dayError = true;
										error = Msg.stationInfo.addStation.priceSettingList.begineqEnd;
									} else{
										// 天是否交叉
										dayError = S.util.checkArrExistVal(dayArr,beginDateIndex,endDateIndex);
										if(dayError) error = Msg.stationInfo.addStation.priceSettingList.dateRangeCross;
									}
									if(dayError){
										var $td = $($(timeSel[0]).find(".beginDate").parents("td")).addClass("errorRed");
										$td.tooltip({
											title: error,
											placement: "top",
											container: "body"
										});
										App.alert(error);
										return false;
									}
									for(var k = 0; k<timeSel.length;k++){
										var e2 = timeSel[k];
										var beginTime = $($(e2).find(".beginTime").find('input')[0]).val() -1;
										var beginMin = $($(e2).find(".beginTime").find('input')[1]).val() -1;
										var endTime = $($(e2).find(".endTime").find('input')[0]).val() -1;
										var endMin = $($(e2).find(".endTime").find('input')[1]).val() -1;

										var beginMill = beginTime * 100 + beginMin;
										var endMill = endTime * 100 + endMin;
										hourMill.push([beginMill, endMill]);
										if(beginMill >= endMill) {
											hourError = true;
											error = Msg.stationInfo.addStation.priceSettingList.begineqEnd;
											var $td = $(e2).find(".beginTime").parents("td").addClass("errorRed");
											$td.tooltip({
												title: error,
												placement: "top",
												container: "body"
											});
											break;
										}
										// 小时是否有交叉
										hourError = S.util.checkExistHourVal(hours, beginTime, beginMin, endTime, endMin);
										if(hourError) {
											error = Msg.stationInfo.addStation.priceSettingList._24hoursCross;
											var $td = $(e2).find(".beginTime").parents("td").addClass("errorRed");
											$td.tooltip({
												title: error,
												placement: "top",
												container: "body"
											});
											break;
										}
									}

									//大小错误,小时存在交叉
									if(hourError){
										App.alert(error);
										return false;
									}

									// 满足24小时
									var mill24 = 0;
			                        if(hourMill && hourMill.length) {
			                            for(var k=0;k<hourMill.length;k++) {
			                                var oneP = hourMill[k];
			                                mill24+= oneP[1]-oneP[0];
			                            }
			                            if(mill24 != 2400) {
			                                App.alert(Msg.stationInfo.addStation.priceSettingList.fill24notEnough);
			                                return false;
			                            }
			                        }
								}
							}
							if(!totalFlag) {
								!priceDetail.is(":visible") && ($(e).click());
								break;
							}
						}
					}else if(page == 4){
						var stationAltitude = $("#addStationAltitude").val().trim(); //电站海拔
						//海拔校验
						if(stationAltitude && !S.util.checkMeanAltitude(stationAltitude)) {
							$("#addStationAltitude").css("border-color", "red").tooltip({
								title: Msg.stationInfo.addStation.checkmeanAltitude,
								placement: "top"
							});
							totalFlag = false;
						} else {
							$("#addStationAltitude").css("border-color", "").tooltip("destroy");
						}
					}else if (page == 5) {
						var cameraTags = $(".cameraInfo .content tr.cameraDataRow");
						var cameraConectType = $('#cameraConectType').find('span.selected').attr('date-type');
						// 传统接入
						if (cameraConectType == 'classic') {
							var formatFlag = true;
							var repFlag = false;
							var nameFlag = true;
							var repNameFlag = false;
							var userNameValid = true;//用户名是正常
							var pswValid = false;

							cameraTags.each(function () {
								var that = $(this);
								var thatAddr = that.find("input[name=ipAddress]").val();
								var thatName = that.find("input[name=cameraName]").val().trim();
								var thatUserName = that.find("input[name=userName]").val().trim();
								var passDom = that.find("input[name=password]");
								var thatPassword = passDom.val().trim();
								var isinput = passDom.attr('isinput');
								if (!thatAddr && !thatName && !thatUserName && !thatPassword) {
									return;
								} else {
									var ip_port = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?):)(?:[1-9]([0-9]?){4})$/;
									if (!(ip_port.test(thatAddr) && (RegExp.$1 < 256 && RegExp.$2 < 256 && RegExp.$3 < 256 && RegExp.$4 < 256 && RegExp.$5 < 65536))) {
										that.find("input[name=ipAddress]").css("border-color", "red");
										formatFlag = false;
									} else {
										that.find("input[name=ipAddress]").css("border-color", "");
										if (thatName == "" || !$.validator.methods.validateSpecicalChars(thatName) || thatName.length > 50) {
											that.find("input[name=cameraName]").css("border-color", "red");
											nameFlag = false;
										} else {
											that.find("input[name=cameraName]").css("border-color", "");
										}
									}
								}

								//校验格式
								if (!formatFlag || !nameFlag) {
									return false;
								}

								if (thatUserName != undefined && thatUserName != null) {
									thatUserName = thatUserName.trim();
									if ("" == thatUserName) {
										that.find("input[name=userName]").css("border-color", "red");
										userNameValid = false;
									} else if (thatUserName.length > 50) {
										that.find("input[name=userName]").css("border-color", "red");
										userNameValid = false;
									} else {
										userNameValid = true;
										that.find("input[name=userName]").css("border-color", "");
									}
								}

								if (!userNameValid) {
									return false;
								}

								if (thatPassword != undefined && thatPassword != null) {
									thatPassword = thatPassword.trim();
									if ("" == thatPassword) {
										that.find("input[name=password]").css("border-color", "red");
										pswValid = true;
									} else if (thatPassword.length > 20) {
										that.find("input[name=password]").css("border-color", "red");
										pswValid = true;
									} else {
										pswValid = false;
										that.find("input[name=password]").css("border-color", "");
									}
								}
								//校验格式
								if (pswValid) {
									return false;
								}
								//校验重复
								that.siblings(".cameraInfo .content tr.cameraDataRow").each(function () {
									var sibAddr = $(this).find("input[name=address]").val();
									var sibName = $(this).find("input[name=cameraName]").val();
									if (thatAddr == sibAddr) {
										repFlag = true;
										$(this).find("input[name=ipAddress]").css("border-color", "red");
										that.find("input[name=ipAddress]").css("border-color", "red");
										return false;
									} else {
										$(this).find("input[name=ipAddress]").css("border-color", "");
										if (formatFlag) {
											that.find("input[name=ipAddress]").css("border-color", "");
										}
										if (thatName == sibName && thatAddr != "" && sibAddr != "") {
											repNameFlag = true;
											$(this).find("input[name=cameraName]").css("border-color", "red");
											that.find("input[name=name]").css("border-color", "red");
											return false;
										} else {
											$(this).find("input[name=cameraName]").css("border-color", "");
										}
									}
								});
								if (repFlag || repNameFlag) {
									return false;
								}
							});

							if (!formatFlag) {
								App.alert(Msg.stationInfo.addStation.cameraError);
								totalFlag = false;
							} else if (repFlag) {
								App.alert(Msg.stationInfo.addStation.cameraAddressRepeat);
								totalFlag = false;
							} else if (!nameFlag) {
								App.alert(Msg.stationInfo.addStation.cameraNameValidate);
								totalFlag = false;
							} else if (repNameFlag) {
								App.alert(Msg.stationInfo.addStation.cameraNameRepeat);
								totalFlag = false;
							} else if (!userNameValid) {
								App.alert(Msg.stationInfo.addStation.camramUserNameError);
								totalFlag = false;
							} else if (pswValid) {
								App.alert(Msg.stationInfo.addStation.cameraPswError);
								totalFlag = false;
							}
						}
						// 云接入
						else {
							cameraTags.each(function () {
								var that = $(this);
								var thatName = that.find("input[name=cameraName]").val();
								var thatEsn = that.find("input[name=esn]").val();
								var thatAppKey = that.find("input[name=appKey]").val();
								var thatSecret = that.find("input[name=secret]").val();

								thatName = thatName ? thatName.trim() : null;
								thatEsn = thatEsn ? thatEsn.trim() : null;
								thatAppKey = thatAppKey ? thatAppKey.trim() : null;
								thatSecret = thatSecret ? thatSecret.trim() : null;

								if (!thatName && !thatEsn && !thatAppKey && !thatSecret) {
									return;
								}

								if (!thatEsn) {
									App.alert(Msg.homePage.mixPage.addStationErrorTip7);
									totalFlag = false;
									return
								}
								if (!thatName) {
									App.alert(Msg.homePage.mixPage.addStationErrorTip8);
									totalFlag = false;
									return
								}
								if (!thatAppKey) {
									App.alert(Msg.homePage.mixPage.addStationErrorTip9);
									totalFlag = false;
									return
								}
								if (!thatSecret) {
									App.alert(Msg.homePage.mixPage.addStationErrorTip10);
									totalFlag = false;
									return
								}

								//校验重复
								if (totalFlag) {
									that.siblings(".cameraInfo .content tr.cameraDataRow").each(function () {
										var sibEsn = $(this).find("input[name=esn]").val();
										if (thatEsn == sibEsn) {
											totalFlag = true;
											$(this).find("input[name=esn]").css("border-color", "red");
											that.find("input[name=esn]").css("border-color", "red");
											return false;
										} else {
											$(this).find("input[name=esn]").css("border-color", "");
											if (formatFlag) {
												that.find("input[name=esn]").css("border-color", "");
											}
										}
									});
									if (!totalFlag) {
										App.alert(Msg.homePage.mixPage.addStationErrorTip11);
									}
								}
							});
						}
					}
					return totalFlag;
				},
				getPriceData: function (stationCode, domainId) {
					var $priceDetail = $('.price-tabs');
					var pricetotal = {};
					var $priceType = $('#priceType').find('.dateDim span');

					$priceType.each(function () {
						if ($(this).is(':visible')) {
							var type = $(this).attr("date-type");
							var typeNum = $(this).attr("price-type");
							var $table = $priceDetail.find('div[data-type="' + type + '"]');
							var useDefaultPrice = $table.find('.defaultPrice span[date-type="yes"]').hasClass('selected') ? 0 : 1;
							var $parentTr = $table.find('.parentRow');
							var rangeData = [];
							$parentTr.each(function () {
								var items = [];
								var price = {};
								var that = $(this);
								var startL = [];
								var endL = [];
								var priceDateNum = that.attr("priceDateNum");
								var $tr = $table.find('tr[priceDateNum="' + priceDateNum + '"]');
								$tr.each(function () {
									var item = {};
									item.beginHour = $($(this).find('.beginTime').find('input')[0]).val();
									item.beginMin = $($(this).find('.beginTime').find('input')[1]).val();
									item.endHour = $($(this).find('.endTime').find('input')[0]).val();
									item.endMin = $($(this).find('.endTime').find('input')[1]).val();
									item.timeType = $(this).find('.ele_type').length > 0 ? $(this).find('.ele_type').val() : 3;
									item.price = $(this).find('.price').val();
									items.push(item);
								});
			 					var rangeStart = that.find(".beginDate").val().replace(/-/g, '\/');
			                    var rangeEnd = that.find(".endDate").val().replace(/-/g, '\/');
			                    // 电价默认前端以东8区时间传入到后端
			                    price.beginDate = Date.parseTime(rangeStart,"yyyy/MM/dd",8);
			                    price.endDate = Date.parseTime(rangeEnd,"yyyy/MM/dd",8);
								price.domainId = "";
								price.stationCode = "";
								if (stationCode) {
									price.stationCode = stationCode;
								}
								if (domainId) {
									price.domainId = domainId;
								}
								price.priceType = typeNum;
								rangeData.push({
									items: items,
									price: price,
									useDefaultPrice: useDefaultPrice
								})
							});
							pricetotal[typeNum] = rangeData;
						}
					});
					return pricetotal;
				},
				/**
				 * 查询电站，flag为false时查询所有电站
				 * @param flag
				 */
				queryStation: function (flag, domainId) {
					stationinfo.queryStation(flag, domainId);
				},
				getCameraData: function () {
					var cameraInfoList = [];
					var cameraConectType = $('#cameraConectType').find('span.selected').attr('date-type');
					// 获取摄像头信息
					$.each($(".cameraInfo .content tr.cameraDataRow"), function (idx, row) {
						if (cameraConectType == 'cloud') {
							var thatName = $(row).find("input[name=cameraName]").val();
							var thatEsn = $(row).find("input[name=esn]").val();
							var thatAppKey = $(row).find("input[name=appKey]").val();
							var thatSecret = $(row).find("input[name=secret]").val();

							thatName = thatName ? thatName.trim() : null;
							thatEsn = thatEsn ? thatEsn.trim() : null;
							thatAppKey = thatAppKey ? thatAppKey.trim() : null;
							thatSecret = thatSecret ? thatSecret.trim() : null;

							cameraInfoList.push({
								joinType: 1,
								name: thatName,
								esn: thatEsn,
								appKey: thatAppKey,
								secret: thatSecret,
								quality: $(row).find("select[name='picQuality']").val()
							});
						} else {
							cameraInfoList.push({
								joinType: 2,
								name: $(row).find("input[name='cameraName']").val(),
								ip: $(row).find("input[name='ipAddress']").val().split(":")[0],
								port: $(row).find("input[name='ipAddress']").val().split(":")[1],
								username: $(row).find("input[name='userName']").val(),
								password: $(row).find("input[name='password']").val()
							});
						}
					});
					return cameraInfoList;
				},
				getDevData: function (flag) {
					var stationCollectorNo = [];
					$("tr.addDevTag").each(function () {
						if ($(this).attr("add") != 'add') {
							var itemize = $(this).find("select.itemize").val() || "";
							var val = $(this).find("input.devId").val().trim() + "@@" + $(this).find("input.devName").val().trim();
							stationCollectorNo.push(val);
						}
					});
					return {
						flag: flag,
						stationCollectorNo: stationCollectorNo
					};
				},
				/**
				 * 获取业态分类数据
				 */
				getitemizeData:function(){
					var data = {};
					//都可能修改 老数据也需要传递
					$("tr.addDevTag").each(function () {
						var devId = $(this).find("input.devId").val().trim();
						var itemize = $(this).find("select.itemize").val();
						data[devId] = itemize;
					});
					return data;
				},
				//新增电站保存
				saveStation: function (update, stationId, stationCode, systemIds, callback) {
					if (!S.submitComplete) {
						return;
					}
					S.submitComplete = false;
					window.setTimeout(function () {
						S.submitComplete = true;
					}, 3000);
					var domain = $("#domain").attr("treeSelId");//公司
					var stationName = S.util.valid("addStationName");                     //电站名称
					//设计温度 设计压力数字检查
					if(!S.checkNumValue($('#designTempreture'), 5) || !S.checkNumValue($('#designPressure'), 5) ){
						return;
					}
					var stationAddress = $("#addStationAddress").val().trim();           //联系地址
					var longitude = $("#addStationAddress").attr("longitude") ? $("#addStationAddress").attr("longitude") : '';
					var latitude = $("#addStationAddress").attr("latitude") ? $("#addStationAddress").attr("latitude") : '';
					// todo 获取经纬度填写省市县

					var stationContact = $("#addStationLink").val().trim();           //联系人
					var stationContactPhone = $("#addStationPhone").val().trim(); //联系电话
					var stationInstallCapity = $('#addStationInstallCapity').val() ? $('#addStationInstallCapity').val().trim() : "";// 规划容量
					var gridTime = Date.parseTime($("#addStationGridTime").val());       //并网时间
					gridTime = isNaN(gridTime) ? "" : gridTime + "";
					var stationCombinedType = $('#addStationCombinedType').val() ? $('#addStationCombinedType').val().trim() : "";// 并网类型
					var stationBuildState = $('#addStationBuildState').val() ? $('#addStationBuildState').val().trim() : "";// 电站规划
					var stationDevoteTime = $("#addStationDevoteTime").val() ? Date.parseTime($("#addStationDevoteTime").val()) + "" : "";// 投运时间
					var safeRunningDate = $("#safe_running_beginDate").val() ? Date.parseTime($("#safe_running_beginDate").val().replace(/-/g, "\/"), "yyyy-MM-dd") + "" : "";

					var voltageClass = $("#voltageClass","#addStationDialogN").val() ? $("#voltageClass","#addStationDialogN").val().trim() : ''; // 电压等级
					var image = $(".img-preview").length > 0 ? _.toArray($(".img-preview")).map(function (x) {
						return $(x).attr("fileId");
					}).toString() : ''; // 电站图片
					var stationIntro = $("#addStationIntro").val() ? $("#addStationIntro").val().trim() : '';               //电站简介
					var stationAltitude = $("#addStationAltitude").val().trim(); //电站海拔

					var timeZoneCode = $("#addStationTimeZone").val() ? $("#addStationTimeZone").val().trim() : '';//电站时区包括地址

					var stationTimeZone = $("#addStationTimeZone option:selected").attr("timeZone");//电站时区

					var stationUserCode = $("#addStationUserCode").val().trim();//发电客户编码
					var chargeUserName = $("#chargeUserName").val();
					var chargeUserId = $("#chargeUserName").attr("userid")

					var aidType = $("#aidType").val();
					var filterType = _.toArray($('.s-selected')).map(function (x) {
						return $(x).attr('date-type')
					}).toString()
					var flag = true;
					var name = {};
					var esn = {};
					var devData = S.util.getDevData(flag);
					var stationCollectorNo = devData.stationCollectorNo;
					flag = devData.flag;
					if (!flag || S.nameRepeatFlag) {
						S.submitComplete = true;
						$('#addStationDialogN form').scrollTop(0);
						return;
					}
					var eleArr = ['.basicInfo','.bindDev','.priceSetting','otherInfo','.cameraInfo'];
					for(var i = 1; i<=5; i++){
						if(!S.util.itemValid(i, systemIds)){
							var eleClass = eleArr[i-1];
							eleClass && S.capacitySetting.jumpTopByClass(eleClass);
							S.submitComplete = true;
							return;
						}
					}
//					if (!(S.util.itemValid(1, systemIds) && S.util.itemValid(2, systemIds) && S.util.itemValid(3, systemIds)
//						&& S.util.itemValid(4, systemIds) && S.util.itemValid(5, systemIds))) {
//						S.submitComplete = true;
//						return;
//					}

					if(update == true){
						$('#addStationDialog-update').toggleLoading({
							msg: Msg.stationInfo.addStation.mdfPlanting,
							iconUrl: '/images/loading.gif'
						});
					}else{
						$('#addStationDialog-add').toggleLoading({
							msg: Msg.stationInfo.addStation.savePlanting,
							iconUrl: '/images/loading.gif'
						});
					}
					var statGroupKpi = $('#statGroupKpi').val();
					if(statGroupKpi == undefined && statGroupKpi!=1 && statGroupKpi!=0){
						statGroupKpi = 1;
					}
					// 电站基本信息保存
					var station = {
						domainId: domain,
						stationName: stationName,
						stationFullName: $('#stationFullName').val(),
						designTempreture:$('#designTempreture').val().trim(),
						designPressure:$('#designPressure').val().trim(),
						/*provinceId: provinceId,
                        cityId: cityId,
                        countyId: townId,*/
						longitude: longitude,
						latitude: latitude,
						stationAddress: stationAddress,

						contact: stationContact,
						phone: stationContactPhone,
						introduction: stationIntro,
						statGroupKpi:statGroupKpi,
						image: image,
						aidType: aidType,
						filterType: filterType,
						psoTransFilePre:$('#addPsoTransFilePre').val().trim()
					};
					//if (systemIds.contains('iclean')) {
					station.gridTime = gridTime;
					station.combinedType = stationCombinedType;
					station.capacity = stationInstallCapity;
					station.buildState = stationBuildState;
					station.stationAltitude = stationAltitude;
					station.stationTimeZone = stationTimeZone;
					station.timeZoneCode = timeZoneCode;
					station.stationUserCode = stationUserCode;
					//}
					//if (systemIds.contains('iesp_ee') || systemIds.contains('iesp_ie')) {
					station.voltageClass = voltageClass;
					station.devoteTime = stationDevoteTime;
					station.safeRunningDate = safeRunningDate;
					if(chargeUserName !== ""){
						station.chargeUserName = chargeUserName;
						station.chargeUserId = chargeUserId;
					}
					//}
					//添加下层网元地址
					var serviceLocationDom = $('#serviceLocation');
					if(serviceLocationDom.is(":visible")) {
						var val = $.trim(serviceLocationDom.val());
						station.serviceLocation = val;
//						if(val) {

							//目前不做校验  支持ip+域名形式  且https或者http是rest 方式 ip是rmi调用方式
//							var ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
//							if(ipRegex.test(val) && (RegExp.$1 < 256 && RegExp.$2 < 256 && RegExp.$3 < 256 && RegExp.$4 < 256)) { //ip校验
//								serviceLocationDom.tooltip("destroy");
//								otherInfo.serviceLocation = val;
//							} else {
//								serviceLocationDom.css("border-color", "red").tooltip({
//									title: Msg.stationInfo.modifyStation.serviceLocationTip,
//									placement: "right"
//								});
//								return;
//							}
//						}
					}

					if (update) {
						station.id = stationId;
					}
					var cameraInfoList = S.util.getCameraData();
					var params = {
						"station": station,
						"esnlist": stationCollectorNo,
						"cameraInfoList": cameraInfoList,
						"devinfoM": devinfoM,
						"pvCapMap": pvCapMap,
					};
					if(sessionStorage.getItem('customType') == "QINGYUN"){
						params.station.mapFilterType = $('#filterType input:radio:checked').val();
					}
					if (S.loadDevFlag)  //来自新设备管理
						params.from = "newDevManage";
					if(App.isJK){
						params.itemizeData =  S.util.getitemizeData();
					}
					if (update) {
						params.stationCode = stationCode;
						params.pricetotal = S.util.getPriceData(stationCode, domain),
							params.pvCapMap = params.pvCapMap.toObject();
						$.each(params.pvCapMap, function(t, e) {
							e.pvCapMap && (e.pvCapMap instanceof Map) && (e.pvCapMap = e.pvCapMap.toObject());
						});
						$.http.ajax('/station/update', params, function (res) {
							S.hasNewBindDev = S.capacitySetting.checkIsExistNotSetCapDev(params.esnlist,params.pvCapMap);
							$('#addStationDialog-update').cancleLoading({
								msg: Msg.modifySucceed,
								iconUrl: '/images/loading.gif'
							});
							if (res.success) {
								App.alert(
									Msg.modifyStationSuccess,
									function () {
										if(S.hasNewBindDev){
											App.confirm(Msg.systemSetting.isToImportCap,function(){
												$('.bindDev  .addDevTag').remove();
												callback && callback();
												$('.showDetail').find('.expand').hasClass('desc') && ($('.showDetail').find('.expand').click());
												S.capacitySetting.jumpTopByClass(".capacitySetting");
											},function(){
												$(".modal").modal("hide");
											})
										}else{
											$(".modal").modal("hide");
										}
										var ztreeObj = $.fn.zTree.getZTreeObj("_domainsTree");
										var node = ztreeObj.getNodeByParam("id", stationCode, null);
										var newNode = node;
										ztreeObj.removeNode(node);
										newNode.name = stationName;
										newNode.pid = domain;
										var paentNode = ztreeObj.getNodeByParam("id", domain, null);
										$('#_domainsTree').cemstree('cemstreeProtoDataChange', [newNode], 0);
										ztreeObj.addNodes(paentNode, newNode, null);
										$('#stationInfos').GridTableRefreshPage();
									});
								//   modifyStationinfo.canClickSave = true;
							}else if ('-3' === res.data) {
								App.alert(Msg.modifyFailed + ":" + Msg.stationInfo.addStation.devCountOverLimit);
							} else {
								App.alert(Msg.modifyFailed);
								//   modifyStationinfo.canClickSave = true;
							}
						});
					} else {
						params.pricetotal = S.util.getPriceData();
						params.pvCapMap = params.pvCapMap.toObject();
						$.each(params.pvCapMap, function(t, e) {
							e.pvCapMap && (e.pvCapMap instanceof Map) && (e.pvCapMap = e.pvCapMap.toObject());
						});
						$.http.ajax('/station/addStationOfIntelligentPower', params, function (res) {
							$('#addStationDialog-add').cancleLoading({
								msg: Msg.saveSucceed,
								iconUrl: '/images/loading.gif'
							});
							S.addStationCode = res.data.stationCode;
							S.addStationId = res.data.id;
							S.hasNewBindDev = S.capacitySetting.checkIsExistNotSetCapDev(params.esnlist,params.pvCapMap);
							S.submitComplete = true;
							if (res.success) {
								callback && callback();
								var meginfo = Msg.saveSucceed;
								if (res.data && !res.data.checkPrice) {
									meginfo = Msg.saveSucceedButPriceFail;
								}
								App.alert(
									meginfo,
									function () {
										$('#location-picker').remove();
										S.util.queryStation(true, params.station.domainId);
										if(S.hasNewBindDev){
											App.confirm(Msg.systemSetting.isToImportCap,function(){
												// 重新加载防止再次点击保存 保存失败
												$('.addDevTag').remove();
												S.capacitySetting.loadBindDevs();
												$('tr[esnvalidate="esnValidate"].addDevTag').attr("add","add");
												$('.showDetail').find('.expand').hasClass('desc') && ($('.showDetail').find('.expand').click());
												S.capacitySetting.jumpTopByClass(".capacitySetting");
											},function(){
												$(".modal").modal("hide");
											})
										}else{
											$(".modal").modal("hide");
										}
									});
								try {
									var stationCode = res.data && res.data.stationCode;
									var ztreeObj = $.fn.zTree.getZTreeObj("domainsTree");
									var ztreeObj = $.fn.zTree.getZTreeObj("_domainsTree");
									var node = {
										id: stationCode,
										level: null,
										model: "STATION",
										name: stationName,
										pid: domain+'',
										icon: Theme.stationSettingIcon(),
										isParent: false
									}
									var paentNode = ztreeObj.getNodeByParam("id", domain, null);
									$('#_domainsTree').cemstree('cemstreeProtoDataChange', [node], 1);
									ztreeObj.addNodes(paentNode, node, null);
								} catch (e) {

								}
								$('#newDeviceManageList').GridTableReload();  //刷新设备管理二维表格
								if (system && system.systemMessage) {
									systemIndex.refreshUnreadMsgNum();
								}
							} else if ('-2' === res.data) {
								App.alert(Msg.save + Msg.stationInfo.addStation.failed + ":" + Msg.stationInfo.addStation.bindDevError);
							} else if ('-1' === res.data) {
								App.alert(Msg.save + Msg.stationInfo.addStation.failed + ":" + Msg.stationInfo.addStation.DevBinded);
							} else if ('-3' === res.data) {
								App.alert(Msg.save + Msg.stationInfo.addStation.failed + ":" + Msg.stationInfo.addStation.devCountOverLimit);
							} else if ('name Repeat' == res.data) {
								App.alert(Msg.save + Msg.stationInfo.addStation.failed + ":" + Msg.stationInfo.addStation.nameRepeat);
							} else if ('capacity exceed' === res.data) {
								App.alert(Msg.save + Msg.stationInfo.addStation.failed + ":" + Msg.stationInfo.addStation.capacityExceed);
							} else if ('-4' === res.data) {
								App.alert(Msg.save + Msg.stationInfo.addStation.failed + ":" + Msg.systemSetting.license.onlyHld);
							}else if ('-5' === res.data) {
								App.alert(Msg.save + Msg.stationInfo.addStation.failed + ":" +Msg.systemSetting.license.LICENSE_EXPIRED);
							}else if ('-6' === res.data) {
								App.alert(Msg.save + Msg.stationInfo.addStation.failed + ":" +Msg.systemSetting.license.NO_LICENSE);
							}else {
								App.alert(Msg.stationInfo.addStation.saveFailed);
							}
						});
					}

				},
				// 基于浏览器获取经纬度
				browserPosition: function (cb) {
					if ("geolocation" in navigator) {
						navigator.geolocation.getCurrentPosition(function (position) {
							cb(position.coords.longitude, position.coords.latitude);
						}, function (d) {
							console.error("get position fail::" + d);
							cb(116.4, 39.9);
						}, {timeout: 3000});
					} else {
						cb(116.4, 39.9);
					}
				}
			}
		};
		var G = {
			Render: function (params) {
				S.addStationCode = false;
				S.addStationId = false;
				//货币单位
            	$('#addStationDialogN .priceUnit').text(App.getCurrencyUnit(true));
				S.clearData();
				S.bindTGJ = [];
				S.systemIds = sessionStorage.getItem("roleSysIds");
				S.basicInfo.loadHtml(params.callback);
				S.bindDev.init();
				S.capacitySetting.init();
				S.priceSetting.init();
				S.cameraInfo.init();
				S.otherInfo.init();
			},
			addStation: S,
		};
		return G;
	});
