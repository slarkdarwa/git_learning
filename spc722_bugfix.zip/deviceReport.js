App.Module('deviceReport', '用电量报表', ['ecm/partials/main/rm/eeReportManage/tableToolUtil', 'partials/main/rm/reportUtils'],
    function(tUtil, reportUtils) {

    // 全局变量
    var _G = {
        para: {},
        devTypeId: '206',
        defaultNode: null
    };

    var dUtil = null;

    var service = {
        init: function(params) {
            _G.para = params;
            dUtil = params.dUtil;
            util.find = params.find;

            // bugifx 电站树从未勾选过,时间插件未加载,导致查询异常
            service.initTimer();
            // 初始化按钮
            service.initToolBtn();

            // service.initDefautTree();

            service._initDefaultTopTree();

        },


        _initDefaultTopTree: function() {
            var params = {minLevel: env.MODEL_DEVICE, devTypes:_G.devTypeId};
            if(_G.para && _G.para.menuSId) {
                params.sIds = _G.para.menuSId;
            }
            env.bindTopper({
                isRadio: false,
                autoCheck: true,
                params: params,
                fnFilter: [env.MODEL_DEVICE],
                checkIds:$('#usePowerReport').data('sid')?$('#usePowerReport').data('sid'):[],
                nodeAnalyser: {
                    sId: ['stationCode', true],
                    dId: ['id', true],
                    locId: ['domainId', true]
                },
                fnReady: function(checker) {
                    _.isFunction(checker) && checker(env.MODEL_STATION, function(node){
                        return !!node.isPowerPoint;
                    });
                },
                fnChange: function(opts) {
                    _G.para.sId = opts.sId && Array.from(new Set(opts.sId)).join();
                    _G.para.dId = opts.dId && Array.from(new Set(opts.dId)).join();

                    // 展示数据的时间维度为天,且域参数变化时才重新初始化时间
                    var timeType = util.find(":radio[name=dateType]:checked").val();
                    var oldLocId = _G.para.locId;
                    _G.para.locId = opts.locId && opts.locId[0];
                    if(oldLocId != _G.para.locId && timeType == '2') service.initTimer();

                    $('#usePowerReport').data('sid',opts.sId);
                    service.initTab();
                }
            });
        },

        initDefautTree: function() {
            // 获取默认参数后加载内容
            _G.defaultNode = [];
            var sId = util.getStationCode();
            $.http.ajax("/devManager/querySingleStationLocation", {
                minLevel: "DEVICE",
                devTypes: _G.devTypeId,
                sIds: sId
            }, function(data) {
                if(data && data.success) {
                    // 默认选中第一层的设备
                    $.each(data.data, function(n, v) {
                        if(v.pid && (v.pid + '').replace(/\|.?/,'') == sId && v.model == 'DEVICE') {
                            _G.defaultNode.push(v);
                        }
                    });
                }
                // 初始化树
                service.initTree();
                // 初始化表
                service.initTab();

            });
        },

        initToolBtn: function() {
            util.find(".export-button").css({display:"inline-block"});
            // 初始化时间选择
            service.initTimer();

            util.find(".search-button").unbind("click").click(function() {
                // 不同时间维度和时间段表头不一致，重新初始化表格s
                service.initTab();
                $(this).find('button').blur();
            });
            util.find(".export-button").unbind("click").click(function(){
                var params = util.getParam();
                util.find('#param').val(JSON.stringify(params));
                util.find("#_csrf").val(main.getCsrf());
                util.find('#exort_form').attr('action', 'ecmUsageReportManage/exportUsePowerReport').submit();
                $(this).find('button').blur();
            });
        },

        initTimer: function(startDay, endDay) {
            var singleDatePicker = '<div class="dateShow dateShow-d" id="timePicker"> '
                +'    <div class="leftSwitch switch"></div>'
                +'    <!-- 日期类型 1:day 2:month 3:year -->'
                +'    <input type="text" class="Wdate date-input" id="date-container" date-type="1" date-change-type="1" max-date>'
                +'    <div class="rightSwitch switch"></div>'
                +'</div>';
            var doubleDatePicker = '<div class="dateShow dateShow-d"  id="timePicker">'
                +'   <div class="leftSwitch switch"></div>'
                +'   <!-- 日期类型 1:day 2:month 3:year -->'
                +'   <div id="date-container" date-type="1" max-date-interval="30" date-change-type="1">'
                +'       <input type="text" class="Wdate date-input" id="sTime" min-date max-date>'
                +'        - <input type="text" class="Wdate date-input " id="eTime" min-date max-date>'
                +'   </div>'
                +'   <div class="rightSwitch switch"></div>'
                +'</div>';

            var timeSelect = util.find(":radio[name=dateType]:checked").val();
            var withDuration = false;
            switch(timeSelect) {
                case '1':
                    util.find("#timePicker").remove();
                    util.find(".dateContainer").after(singleDatePicker);
                    dUtil.intiSingleDateSelector(service.refreshTab, util.find, function() {
                        util.find('#date-container').attr('max-date', new Date().format("yyyy-MM-dd",true));
                    });
                    break;
                case '2':
                    var eTime;
                    var sTime;
                    var locId = _G.para.locId;
                    // 默认托管域
                    var v = reportUtils.domainDate(locId || parseInt(sessionStorage.getItem('twoLevelDomain')) || 1, startDay, endDay);
                    if(!_.isEmpty(v)) {
                        util.find('#date-container').attr('max-date-interval', v[2]);
                        sTime = v[0];
                        eTime = v[1];
                        withDuration = true;
                    } else {
                        eTime = new Date();
                        sTime = new Date(eTime.getTime());
                        sTime.setDate(1);
                    }
                    var fmt = 'yyyy-MM-dd';
                    eTime = eTime.format(fmt, true);
                    sTime = sTime.format(fmt, true);

                    util.find("#timePicker").remove();
                    util.find(".dateContainer").after(doubleDatePicker);
                    dUtil.intiDoubleDateSelector(service.initTab, util.find, function() {
                        util.find('#eTime').attr('max-date', new Date().format(fmt,true));
                    }, eTime, true, util.find('#timePicker'), null, sTime);
                    break;
                default:
                    util.find("#timePicker").remove();
                    util.find(".dateContainer").after(singleDatePicker);
                    util.find('#date-container').attr('date-type', '2');
                    util.find('#date-container').attr('date-change-type', '2');
                    dUtil.intiSingleDateSelector(service.initTab, util.find, null,new Date().format("yyyy-MM",true));
                    break;
            }

            // 日类型需要按周期切换,重写左右切换按钮事件
            if(timeSelect == '2' && withDuration) {
                util.find(".leftSwitch").unbind("click").click(function (e) {
                    var eTime = new Date($("#sTime").val()) || new Date();
                    service.initTimer(null, eTime);
                    service.initTab();
                });
                util.find(".rightSwitch").unbind("click").click(function (e) {
                    var sTime = new Date($("#eTime").val());
                    service.initTimer(sTime, null);
                    service.initTab();
                });
            }

            util.find(":radio[name=dateType]").unbind('change').change(function() {
                var timeType = $(this).val();
                switch(timeType) {
                    case '1':
                        util.find("#timePicker").remove();
                        util.find(".dateContainer").after(singleDatePicker);
                        dUtil.intiSingleDateSelector(service.refreshTab, util.find, function() {
                            util.find('#date-container').attr('max-date', new Date().format("yyyy-MM-dd",true));
                        });
                        break;
                    case '2':
                        service.initTimer();
                        break;
                    default:
                        util.find("#timePicker").remove();
                        util.find(".dateContainer").after(singleDatePicker);
                        util.find('#date-container').attr('date-type', '2');
                        util.find('#date-container').attr('date-change-type', '2');
                        dUtil.intiSingleDateSelector(service.initTab, util.find, null,new Date().format("yyyy-MM",true ));

                        break;
                }
                service.initTab();
            });
        },

        initTree: function() {
            util.find("#deviceTree").attr('placeholder', Msg.partials.main.rm.dayCapPrpfit.selectObiect);
            var defaultId = [];
            var defaultName = [];
            $.each(_G.defaultNode, function(n, v) {
                if(v.model == "DEVICE") {
                    defaultId.push(v.id);
                    defaultName.push(v.name);
                }
            });
            util.find("#deviceTree").attr('treeSelId', defaultId.join());
            util.find("#deviceTree").val(defaultName.join());

            util.find("#deviceTree").iemsInputTree({
                url: "/devManager/querySingleStationLocation",
                chkboxType: {"Y": "ps", "N": "ps"},
                contentClass: 'layout-tree',
                selectNodes: defaultId,
                param: {
                    minLevel: "DEVICE",
                    devTypes: _G.devTypeId,
                    sIds: util.getStationCode()
                },
                blurAfater: function(tree, selectedId) {
                    // service.refresh();
                }
            });
        },

        initTab: function() {
            var param = util.getParam();
            util.find(".self-title").text(util.getTabTitle(param));
            util.find("#reportTable").GridTable({
                url: 'ecmUsageReportManage/listUsePowerReport',
                max_height:650,
                //freezeCol: 2,
                // preColumnWidth: 100,
                // title: true,
                // titleText: "  ",
                params: param,
                pageBar: true,
                colResize: true,
                resizable: false,
                colModel: util.getColModel(param),
                // loadReady: function(data, btrs, htrs, totalRecords) {
                //     // util.find("#GridTableTitle_reportTable").addClass('grid-table-title').text(util.getTabTitle(param));
                //     // 冻结列title不兼容,自己拼一个
                // }
            });
        },

        refreshTab: function() {
            var params = util.getParam();
            var grid = util.find('#reportTable');
            try {
                params = $.extend(grid.GridTableUrlParams(), params)
            } catch(err) {
                console.warn('gridtable error.', err);
            }
            util.find(".self-title").text(util.getTabTitle(params));
            grid.GridTableReload(params);
        }

    };

    var util = {
        getStationCode: function() {
            return util.find("#stationSelector").val();
        },

        getParam: function() {
            var reportType = util.find(":radio[name=dateType]:checked").val();
            return {
                // theSId: util.getStationCode(),
                // dIds: util.find("#deviceTree").attr('treeSelId'),
                theSId: _G.para.sId,
                dIds: _G.para.dId,
                devTypeId: _G.devTypeId,
                timeType: dUtil.getTimeType(),
                reportType: reportType,
                sTime: reportType == '2' ?$("#sTime").val() : dUtil.getTimeTxt(),
                eTime: dUtil.getEndTimeTxt()
            };
        },

        getTabTitle: function(param) {
            var title = '';
            switch(param.reportType) {
                case '1':
                    if(param.sTime) title = new Date(param.sTime).format('yyyy-MM-dd');
                    title += Msg.partials.main.rm.dayCapPrpfit.data.usePower + Msg.partials.main.rm.dayCapPrpfit.dayReport;
                    break;
                case '2':
                    if(param.sTime && param.eTime) {
                        var sameYear = new Date(param.sTime).getFullYear() ==  new Date(param.eTime).getFullYear();
                        var sameMonth = new Date(param.sTime).getMonth() ==  new Date(param.eTime).getMonth();
                        if(sameYear && sameMonth) {
                            title = new Date(param.sTime).format('yyyy-MM');
                        } else if(sameYear){
                            title = new Date(param.sTime).format('yyyy-MM');
                            title += " ~ " + new Date(param.eTime).format('MM');
                        } else{
                            title = new Date(param.sTime).format('yyyy-MM');
                            title += " ~ " + new Date(param.eTime).format('yyyy-MM');
                        }
                    } else {
                        if(param.sTime) title = new Date(param.sTime).format('yyyy-MM');
                        if(param.eTime) title = new Date(param.eTime).format('yyyy-MM');
                    }
                    title += Msg.partials.main.rm.dayCapPrpfit.data.usePower + Msg.partials.main.rm.dayCapPrpfit.monthReport;
                    break;
                default:
                    if(param.sTime) {
                        var sTime = new Date(param.sTime).offset('month', -12);
                        var eTime = new Date(param.sTime).offset('month', -1);
                        var sameYear = new Date(sTime).getFullYear() ==  new Date(eTime).getFullYear();
                        if(sameYear) {
                            title = new Date(sTime).format('yyyy');
                        } else {
                            title = new Date(sTime).format('yyyy');
                            title +=  " ~ " + new Date(eTime).format('yyyy');
                        }
                    }
                    title += Msg.partials.main.rm.dayCapPrpfit.data.usePower + Msg.partials.main.rm.dayCapPrpfit.yearReport;
                    break;
            }
            return title;
        },

        getColModel: function(param) {
            var model = [
                {display: "dId", name: "dId", hide: true},
                {display: Msg.limitManage.devName, name: "dName"},
                {display: Msg.partials.main.rm.dayCapPrpfit.total+'</br>(kWh)', name: "powerUsage"}
            ];
            switch(param.reportType) {
                case '1':
                    for(var i = 1; i <= 24; i++) {
                        model.push({display: i + ":00", name: "usage"+i});
                    }
                    // model[1].width = '0.08';
                    break;
                case '2':
                    if(param.sTime || param.eTime) {
                        var sDate = Date.parseTime($("#sTime").val());
                        var eDate = Date.parseTime($("#eTime").val());
                        var i = 1;
                        do {
                            model.push({display: new Date(sDate).format(main.Lang=="zh"?"MM-dd":"dd/MM"), name: "usage" + (i++)});
                            sDate = sDate+60*60*24*1000;
                        } while (sDate <= eDate);
                    }
                    // model[1].width = 2/i;
                    break;
                default:
                    for(var i = 12; i > 0; i--) {
                        model.push({display: new Date(param.sTime).offset('month', -i).format(main.Lang=="zh"?"yyyy-MM":"MM/yyyy"), name: "usage" + (12 - i + 1)});
                    }
                    // model[1].width = '0.13';
                    break;
            }

            return model;
        }


    };


    return {
        Render: function (params) {
            service.init(params);
        }
    };

});