App.Module(
    'addStation', '电站信息-一键开站',
    ['jquery', 'ecm/babel/partials/efficiencyAnalysis/datas','bootstrap','iemsInputTree','systemSetting/station/addStationN', 'ecm/partials/main/systemSetting/stationInfo/stationInfo',
        'ecm/partials/main/dm/devUtil', 'ecm/partials/main/systemMessage/system_index', "ecm/babel/utils/treeUtil", 'locationPicker', 'datePicker'],
    function ($, double) {
        var deleteItemId = [];
        var deletePriceId = [];
        var priceDef = {
            /**
             * 事件绑定
             */
            priceTypeClick: function () {
                $("#priceType").find('.dateDim span').off('click').click(function (e) {
                    var $src = $("#addStationDialogN").find(".price-tabs").find('[data-type='+$('#addStationDialogN').find(this).attr("date-type")+']').attr('class').split(' ')[2];
                    if(!Menu.containsSrc($src + '_update')){
                        $('.addDlgBtnDiv').hide();
                    }else{
                        $('.addDlgBtnDiv').show();
                    }
                    if ($("#update").hide()){
                        $("#update").show();
                        $("#testSaveStation").hide();
                    }
                    deleteItemId = [];
                    var _this = $(e.target);
                    var $table = $('div[data-type='+ _this.attr('date-type') +']').find('table')
                    $('.price-tabs').find('.dateDim span')
                    var typeNum = $table.attr("price-type");
                    $(".price-tabs").find(".price-detail").find(".dateDim").find("span:last").hide()
                    var _dateType = _this.attr("date-type");
                    _this.parent().parent().find(".dateDim span").removeClass("selected");
                    _this.addClass("selected");
                    priceDef.dateDim = _dateType;
                    priceDef.loadPriceTab(_dateType);
                    var selectedPtype = $('#priceType').find('.dateDim .selected');
                    var _op = $('.price-detail').find('.' + selectedPtype.attr('date-type')).find('.operate');
                    priceDef.initPrice(typeNum);
                    $table.find('tr:last').hide();
                    $table.find('.operate').hide();
                });
            }
            ,

            /**
             * 加载电价tab
             * @param {Object} dataType
             */
            loadPriceTab: function (dataType) {
                $('.price-tabs .price-detail').hide();
                var showArr = {
                    "usedPowerPrice": ["usedPower"],
                    "usedWaterPrice": ["usedWater"],
                    "usedGasPrice": ["usedGas"],
                    "onGridPowerPrice": ["gridPower"],
                    "storePrice": ["storePriceItem"],
                    "storeOutPrice": ["storeOut"],
                    "heatPrice": ["heatPriceItem"],
                    "chargePrice": ["chargePriceItem"],
                    "irradiatePrice": ["irradiatePriceItem"],
                    "airConditioningPrice": ["airConditioningPriceItem"]
                };
                var showArrItem = showArr[dataType];
                $.each(showArrItem, function (t, e) {
                    $('.price-tabs .' + e).show();
                });

                $('.addRowBtn').off('click').on('click', function (e,dataType) {
                    priceDef.addPriceRow(e,dataType);
                });
            }
            ,
            /**
             * 添加电价项
             * @param {Object} e
             */
            addPriceRow: function (e,dataType) {
                var $this = $(e.target);
                var $thisTr = $this.parent().parent();
                var beginDate = new Date(Date.parseTime("01-01","MM-dd")).format(Msg.dateFormat.yyyymmdd);
                var endDate = new Date(Date.parseTime("12-31","MM-dd")).format(Msg.dateFormat.yyyymmdd);
                var beginTime = 0;
                var endTime = 24;
                // 初始化时间范围的开始时间与结束时间

                var $select = $('<select>').addClass('ele_type').append([
                    $('<option value="1">'+Msg.homePage.mixPage.highest+'</option>'),
                    $('<option value="2">'+Msg.homePage.mixPage.high+'</option>'),
                    $('<option value="3">'+Msg.homePage.mixPage.flat+'</option>'),
                    $('<option value="4">'+Msg.homePage.mixPage.minimum+'</option>')
                ]);

                var $row = $('<tr>').addClass('priceDataRow').append([
                    $('<td>').append($('<input class="Wdate beginDate" readonly value="' + beginDate + '"/><span>-</span><input class="Wdate endDate" readonly value="' + endDate + '"/>')),
                    $('<td>').append($select),
                    $('<td>').append([
                        priceDef.buildTime('beginTime', double.double(beginTime), double.double(0)),
                        $('<span>-</span>'),
                        priceDef.buildTime('endTime', double.double(endTime), double.double(0))
                    ]),
                    $('<td>').append($('<input class="price"/>')),
                    $('<td class="operate">').append($('<button type="button" class="addPriceTimeBtn"></button><button type="button" class="delPriceTimeBtn"></button>'))
                ]);
                if ( priceDef.dateDim == 'onGridPowerPrice' ||priceDef.dateDim == 'heatPrice' || priceDef.dateDim == 'usedWaterPrice' || priceDef.dateDim == 'usedGasPrice') {
                    $row.find('.ele_type').parent().remove();
                }
                if ($this.hasClass('addRowBtn')) {
                    var $prevTr = $thisTr.prev('.priceDataRow');
                    $row.addClass('parentRow');
                    // 初始化日期范围的开始时间与结束时间
                    if ($prevTr && $prevTr.length > 0) {
                        $row.attr("priceDateNum", parseInt($prevTr.attr("priceDateNum")) + 1);
                        var prevPricedatenum = $prevTr.attr("pricedatenum");
                        beginDate = $prevTr.parent().find('tr.parentRow[pricedatenum="' + prevPricedatenum + '"]').find('.endDate').val();
                        beginDate = new Date(Date.parseTime(beginDate.replace("-", "/"), 'yyyy/MM/dd'));
                        beginDate.setDate(beginDate.getDate()+1);
                        endDate = new Date(Date.parseTime("12-31","MM-dd"));
                        endDate.setFullYear(beginDate.getFullYear());
                        beginDate = beginDate.format(Msg.dateFormat.yyyymmdd);
                        endDate = endDate.format(Msg.dateFormat.yyyymmdd);
                    } else {
                        $row.attr("priceDateNum", 1);
                    }
                    $row.find('.beginDate').val(beginDate);
                    $row.find('.endDate').val(endDate);
                    $thisTr.before($row);
                } else {
                    $this.hide();
                    var priceDateNum = $thisTr.attr("priceDateNum");
					var thisTrVal = $($thisTr.find('.endTime').find('input')[0]).val();
					var thisTrValMin = $($thisTr.find('.endTime').find('input')[1]).val();
					// if((thisTrVal - 0) === 24){
					// 	App.alert(Msg.stationInfo.addStation.priceSettingList.fill24Over);
					// 	$this.show();
					// 	return false;
					// }
                    $($row.find('.beginTime').find('input')[0]).val(thisTrVal);
					$($row.find('.beginTime').find('input')[1]).val(thisTrValMin);
                    $row.attr("priceDateNum", priceDateNum);
                    // 时间范围的设置合并日期设置单元格
                    var $parentTr = $thisTr.siblings('tr.parentRow[priceDateNum="' + priceDateNum + '"]');
                    $parentTr = $parentTr.length > 0 ? $parentTr : $thisTr;
                    var rowspan = $parentTr.find('td:first').attr("rowspan");
                    $parentTr.find('td:first').attr("rowspan", rowspan ? parseInt(rowspan) + 1 : 2);
                    $row.find('td:first').remove();
                    $row.addClass('child');
                    $thisTr.after($row);
                }
                priceDef.initPriceItemEvent();
            }
            ,
            initPriceItemEvent:function () {
                // 删除按钮
                $('.delPriceTimeBtn').off('click').on('click', function (et) {
                    if(!isNaN($(et.target).attr("id") - 0)){
                        deleteItemId.push();
                    }
                    var $tr = $(et.target).parent().parent();
                    var priceDateNum = $tr.attr("priceDateNum");
                    var $parentTr = $tr.siblings('tr.parentRow[priceDateNum="' + priceDateNum + '"]');
                    var $sibTr = $tr.siblings('tr.child[priceDateNum="' + priceDateNum + '"]');
                    if ($parentTr.length <= 0 && $sibTr.length <= 0) {
                        //前后都无
                        $tr.remove();
                    } else if ($parentTr.length > 0 && $sibTr.length <= 0) {
                        //前有后无
                        var rowspan = $parentTr.find('td:first').attr("rowspan");
                        $parentTr.find('td:first').attr("rowspan", rowspan ? parseInt(rowspan) - 1 : 1);
                        $tr.prev().find('td:last').find('.addPriceTimeBtn').show();
                        $tr.remove();
                    } else if ($parentTr.length > 0 && $sibTr.length > 0) {
                        var rowspan = $parentTr.find('td:first').attr("rowspan");
                        $parentTr.find('td:first').attr("rowspan", rowspan ? parseInt(rowspan) - 1 : 1);
                        //前有后无
                        if ($tr.attr("priceDateNum") != $tr.next().attr("priceDateNum")) {
                            $tr.prev().find('td:last').find('.addPriceTimeBtn').show();
                        }
                        //中间子元素
                        $tr.remove();
                    } else if ($parentTr.length <= 0 && $sibTr.length > 0) {
                        // 无父有子
                        var nextBeginTime = $tr.next().find('.beginTime').val();
                        var nextEndTime = $tr.next().find('.endTime').val();
                        var $timeType = $tr.next().find('.ele_type');
                        var price = $tr.next().find('.price').val();
                        if ($timeType.length > 0) {
                            $tr.find('.ele_type').val($timeType.val());
                        }
                        var rowspan = $tr.find('td:first').attr("rowspan") - 1;
                        $tr.find('.beginTime').val(nextBeginTime);
                        $tr.find('.nextEndTime').val(nextEndTime);
                        $tr.find('.price').val(price);
                        $tr.next().remove();
                        $tr.find('td:first').attr("rowspan", rowspan);
                        if ($tr.attr("priceDateNum") != $tr.next().attr("priceDateNum")) {
                            $tr.find('td:last').find('.addPriceTimeBtn').show();
                        }
                    }
                });
                // 时间设置新增按钮
                $('.addPriceTimeBtn').off('click').on('click', function (t) {
                    priceDef.addPriceRow(t);
                });

                $('.beginDate, .endDate').off('click').on('click', function (e) {
                    var startDate = $(e.target).val() || new Date(Date.parseTime("01-01","MM-dd")).format(Msg.dateFormat.yyyymmdd);
                    DatePicker({
                        dateFmt: Msg.dateFormat.yyyymmdd,
                        startDate:startDate,
                        alwaysUseStartDate:true
                    });
                });
            }
            ,
            /**
             * 检测长度和所有值是否都是true
             * @param {Object} arr
             * @param {Object} len
             */
            checkLenthTrue:function(arr,len){
                if(!arr || arr.length<len) return false;
                for(var i = 0;i<len;i++){
                    if(!arr[i]) return false;
                }
                return true;
            },
            /**
             * 初始化电价
             * @param {Object} secondDomain
             * @param {Object} domainId
             * @param {Object} stationId
             * @param {Object} type
             * @param {Object} flag
             * @param {Object} tabType
             * @param {Object} func1
             * @param {Object} func2
             * @param {Object} cb
             */
            initPrice: function (secondDomain, domainId, stationId, type, flag, tabType, func1, func2, cb) {
                var param = {};
                param.domainId = -1;
                param.stationId = "system";
                param.priceType = secondDomain;
                param.queryTime = $("input#price_search_time").val().replace(/-/g, '\/');
                param.queryTime = Date.parseTime(param.queryTime ,"yyyy/MM/dd",8);
                $.http.ajax('/ongridprice/queryGridPrice', param,
                    function (data) {
                        if (data && data.success) {
                            if (!data.data) {
                                if (cb && typeof (cb) == "function") {
                                    cb();
                                }
                                return;
                            }
                            var result = data.data;
                            priceDef.dealGetPriceData(result, func1, func2, cb);
                        } else {
                            App.alert(Msg.stationInfo.addStation.loadDefaultPriceError);

                            if (cb && typeof (cb) == "function") {
                                cb();
                            }
                            return;
                        }
                        var selectedPtype = $('#priceType').find('.dateDim .selected');
                        var isDefault = $('.price-detail[data-type=' + selectedPtype.attr('date-type') + ']').find('.dateDim span[date-type="yes"]').hasClass('selected');
                        var _op = $('.price-detail').find('.' + selectedPtype.attr('date-type')).find('.operate');
                        if (isDefault) {
                            _op.hide();
                        } else {
                            _op.show();
                        }
                    }, null, false);
            }
            ,
            /**
             * 处理获取到的电价数据
             * @param {Object} result
             * @param {Object} func1
             * @param {Object} func2
             * @param {Object} cb
             */
            dealGetPriceData:function (result, func1, func2, cb) {
                if (!result) return;
                var length = result.length;
                var hasClean = {};
                for (var i = 0; i < length; i++) {
                    var $dom = [];
                    var priceT = result[i];
                    var priceH = priceT["price"];
                    //是否是默认电价
                    var isDefault = priceH.stationCode == "system";
                    var priceItem = priceT["priceItem"];
                    var disabled = isDefault ? "disabled" : "";
                    var priceTagIndex = i + '';
                    var priceId = priceH.id;
                    var beginDateTime = priceH.beginDate;
                    var endDateTime = priceH.endDate;
                    var priceType = priceH.priceType;
                    if (!hasClean[priceType]) {
                        //最开始清理一次
                        $('.price-tabs').find('table[price-type="' + priceType + '"]').find("tr.priceDataRow").remove();
                        hasClean[priceType] = true;
                    }
                    if (isDefault) {
                        $('.price-tabs').find('table[price-type="' + priceType + '"]').find("tr:last").hide();
                    } else {
                        $('.price-tabs').find('table[price-type="' + priceType + '"]').find("tr:last").show();
                    }
                    var timeZoneId = Date.getTimezone();
                    beginDateTime -= timeZoneId * 3600 * 1000;
                    endDateTime -= timeZoneId * 3600 * 1000;
                    var beginDate = Date.parse(beginDateTime, timeZoneId).format(Msg.dateFormat.yyyymmdd);
                    var endDate = Date.parse(endDateTime, timeZoneId).format(Msg.dateFormat.yyyymmdd);
                    var itemsLength = priceItem.length;
                    var $rangeDate = $('<td>').attr("rowspan", itemsLength).append($('<input id = '+priceId+' class="beginDate Wdate" readonly ' + disabled + ' value="' + beginDate + '" /><span>-</span><input class="endDate Wdate" readonly ' + disabled + ' value="' + endDate + '"/>'));
                    for (var j = 0; j < itemsLength; j++) {
                        priceTagIndex += j;
                        var item = priceItem[j];
                        var price = item.price;
                        var timeType = item.timeType;
                        var beginHour = item.beginHour;
                        var endHour = item.endHour;
                        var beginMin = item.beginMin;
                        var endMin = item.endMin;
                        var itemId = item.id;
                        //
                        var $tr = $('<tr>').addClass("priceDataRow").attr("pricedatenum", i);

                        if (priceType != 9 && priceType != 3 && priceType != 4 && priceType != 1){
                            var $timeTypeTd = $('<td>').append($('<select ' + disabled + ' >').addClass('ele_type').append([
                            	$('<option value="1" >' + Msg.homePage.mixPage.highest + '</option>'),
                        		$('<option value="2" >' + Msg.homePage.mixPage.high + '</option>'),
                        		$('<option value="3" >' + Msg.homePage.mixPage.flat + '</option>'),
                        		$('<option value="4" >' + Msg.homePage.mixPage.minimum + '</option>')
                            ]));
                        }
                        var $beginTime = priceDef.buildTime('beginTime', double.double(beginHour), double.double(beginMin));
                        var $endTime = priceDef.buildTime('endTime', double.double(endHour), double.double(endMin));
                        // $beginTime.find('option[value="' + beginHour + '"]').attr('selected', "selected");
                        // $endTime.find('option[value="' + endHour + '"]').attr('selected', "selected");
                        if (isDefault) {
                            $beginTime.find('input').attr("disabled", "disabled");
                            $endTime.find('input').attr("disabled", "disabled");
                        }
                        var $timeDateTd = $('<td>').append([$beginTime, $('<span>-</span>'), $endTime]);

                        var $priceTd = $('<td>').append($('<input class="price" ' + disabled + ' value="' + price + '"/>'));
                        var $delTd = $('<td class="operate">').append($('<button type="button" class="addPriceTimeBtn"></button><button id='+itemId+' type="button" value='+price+' class="delPriceTimeBtn"></button>'));
                        if (j == 0) {
                            $tr.addClass('parentRow');
                            $tr.append($rangeDate);
                        }
                        //涉及电的才有无 尖 峰平 谷
                        if (priceType != 9 && priceType != 3 && priceType != 4 && priceType != 1) {
                            $timeTypeTd.find('option[value="' + timeType + '"]').attr("selected", "selected");
                            $tr.append($timeTypeTd);
                        }
                        $tr.append([$timeDateTd, $priceTd, $delTd]);
                        $dom.push($tr);
                    }
                    $('.price-tabs').find('table[price-type="' + priceType + '"]').find('tr:last').before($dom);
                    $('.price-tabs').find('.defaultPrice[price-type="' + priceType + '"]').find('.dateDim span').removeClass("selected");
                    if (isDefault) {
                        //默认电价
                        $('.price-tabs').find('table[price-type="' + priceType + '"]').find('.operate').hide();
                        $('.price-tabs').find('.defaultPrice[price-type="' + priceType + '"]').find('.dateDim span[date-type="yes"]').addClass('selected');
                    } else {
                        $('.price-tabs').find('table[price-type="' + priceType + '"]').find('.operate').show();
                        $('.price-tabs').find('.defaultPrice[price-type="' + priceType + '"]').find('.dateDim span[date-type="no"]').addClass('selected');
                    }

                }

                //如果电站为710同步电站, 则电价设置不可编辑
                if (func1 && typeof (func1) == "function") {
                    func1(4);
                }
                if (func2 && typeof (func2) == "function") {
                    func2(4);
                }

                if (cb && typeof (cb) == "function") {
                    cb();
                }
            }
            ,
            buildTime: function (className, valHour, valMin) {
                var inputHour = $('<input type="number" style="width: 35px" max="24" class="timeInput" onkeypress="return(/[\\d]/.test(String.fromCharCode(event.keyCode)))">');
                var mao = $('<span>:</span>');
                var inputMin = $('<input type="number" style="width: 35px" max="59" class="timeInput" onkeypress="return(/[\\d]/.test(String.fromCharCode(event.keyCode)))">');
				inputHour.val(double.double(valHour));
				inputMin.val(valMin ? valMin : double.double(0));
                var $sel = $('<div>')
				.addClass(className)
				.css({
					'width': '100px',
					'margin': 'auto',
                    'display': 'inline-block'
					})
				.append(inputHour)
                .append(mao)
                .append(inputMin);
                if(className === 'beginTime') {
                    inputHour.val(double.double(valHour)).blur(priceDef.event(23));
                    inputMin.blur(priceDef.blurVal(inputHour, inputMin, 30, className));
                }else if (className === 'endTime'){
                    inputHour.blur(priceDef.blurVal(inputHour, inputMin, 24, className));
                    inputMin.blur(priceDef.blurVal(inputHour, inputMin, 30, className));
                }
                return $sel;
            },
			blurVal: function($hour, $min, val, className){
				return function(){
					var flag = $($min.parent().parent().parent()[0]).attr('class').contains('parentRow');
					if((($hour.val() - 0) === 24) || (($hour.val() - 0) === 0 && className === 'beginTime' && flag )){
					      $min.val(double.double(0));
					}else {
						var valB = val === 24 ? $hour.val() : $min.val();
						var $one = val === 24 ? $hour : $min;
						if(valB - 0 > val){
							$one.val(double.double(val));
						}else if((valB - 0) <= 0){
							$one.val(double.double(0));
						}else {
                            if (val != 24){
                                if ((valB - 0) >= 15 ){
                                    $one.val(double.double(30));
                                }else {
                                    $one.val(double.double(0));
                                }
                            }else {
                                $one.val(double.double(valB));
                            }
						}
					}
				}
			},
            event: function (val) {
                return function (e) {
                    if ($(e.target).val() - 0 > val) {
                        $(e.target).val(double.double(val));
                    }else if ($(e.target).val() - 0 <= 0) {
                        $(e.target).val(double.double(0));
                    }else{
                        $(e.target).val(double.double($(e.target).val()))
                    }
                }
            },
            valueFormat:function (time) {
                time -= 0;
                switch (time) {
                    case 0:
                        timec = "00";break;
                    case 1:
                        timec = "01";break;
                    case 2:
                        timec = "02";break;
                    case 3:
                        timec = "03";break;
                    case 4:
                        timec = "04";break;
                    case 5:
                        timec = "05";break;
                    case 6:
                        timec = "06";break;
                    case 7:
                        timec = "07";break;
                    case 8:
                        timec = "08";break;
                    case 9:
                        timec = "09";break;
                    case 10:
                        timec = "10";break;
                    case 11:
                        timec = "11";break;
                    case 12:
                        timec = "12";break;
                    case 13:
                        timec = "13";break;
                    case 14:
                        timec = "14";break;
                    case 15:
                        timec = "15";break;
                    case 16:
                        timec = "16";break;
                    case 17:
                        timec = "17";break;
                    case 18:
                        timec = "18";break;
                    case 19:
                        timec = "19";break;
                    case 20:
                        timec = "20";break;
                    case 21:
                        timec = "21";break;
                    case 22:
                        timec = "22";break;
                    case 23:
                        timec = "23";break;
                    case 24:
                        timec = "24";break;
                    default:
                        break;
                }
                return time;
            },
            deletePrice:function(deleteItemId,priceType){
                var deletePrice = [];
                var idTemp;
                var fkDele = [];
                $(".price-tabs").find("[price-type=" + priceType + "]").find(".parentRow").each(function(k,v){
                    idTemp = $(this).find(".operate").find(".delPriceTimeBtn").attr("id");
                    if (deletePrice && deletePrice[k]==deletePrice[k-1]){
                        return ;
                    }
                    if(!idTemp)
                        deletePrice.push(idTemp);
                });
                if (deleteItemId && deletePrice){
                    for(var i = 0; i < deleteItemId.length; i++){
                        for (var j = 0; j < deletePrice.length; j++){
                            if(!deleteItemId[i] == deletePrice[j]){
                                fkDele.push(deleteItemId[i]);
                            }
                        }
                    }
                }
                if ($(".priceDataRow").is(":visible")){
                    return deleteItemId;
                }else {
                    return fkDele;
                }

            },
            updatePrice:function(stationCode,domainId,priceType){
                var total = [];
                $(".price-tabs").find("[price-type=" + priceType + "]").find(".parentRow").each(function(){
                    //价格修改标志
                    if (!$(this).is(":visible")) {//dom节点不可见则退出(已经删除的dom节点)
                        return;
                    }
                    var modifyflag = false;
                    var priceItems = [];
                    var $pricedatenum = $(".price-tabs").find("[price-type=" + priceType + "]").find($('.priceDataRow[pricedatenum=' + $(this).attr('pricedatenum')+']') );
                    $pricedatenum.each(function(){
                        var itemid = $(this).find(".operate").find(".delPriceTimeBtn").attr("id");
                        var priceId = itemid;
                        var parentId =  $(".price-tabs").find("[price-type=" + priceType + "]").find(".parentRow").find('.beginDate').attr("id");
                        var startTemp = priceDef.valueFormat($($(this).find(".beginTime").find('input')[0]).val());//$(".beginTime").html().split(":")[0];
                        var beginMin = double.double($($(this).find(".beginTime").find('input')[1]).val());
                        var endTemp = priceDef.valueFormat($($(this).find(".endTime").find('input')[0]).val());//$(".endTime").html().split(":")[0];
                        var endMin = double.double($($(this).find(".endTime").find('input')[1]).val());
                        var end = endTemp == 0 ? "24":endTemp;
                        var priceTemp = $(this).find(".price").val();
                        var timeTypeTemp = $(this).find(".ele_type") ? $(this).find(".ele_type").val(): "3";
                        var oldPrice = $(this).find(".operate").find(".delPriceTimeBtn").attr("value") - 0;//.val().trim();
                        if(itemid){
                            modifyflag = true;
                        }
                        var item = {
                            "id":priceId,
                            "beginHour": startTemp,
                            "beginMin": beginMin - 0,
                            "endHour": end,
                            "endMin": endMin - 0,
                            "price": priceTemp,
                            "parentId": parentId,
                            "timeType": timeTypeTemp
                        };
                        if (priceId)priceItems.push(item);
                    });
                    if(modifyflag){
                        var length = priceItems.length;
                        for(var i = 0; i< length; i++){
                            total.push(priceItems[i]);
                        }
                    }
                });
                return total;
            },
            getElePricedatenumArr:function(ele,attr){
                var arr = [];
                if(ele){
                    $.each(ele,function(t,e){
                        var pricedatenum = $(e).attr(attr);
                        if(arr.indexOf(pricedatenum) < 0){
                            arr.push(pricedatenum);
                        }

                    });
                }
                return arr;
            },
            getDateIndex: function(timeStr){
                var endTime = Date.parseTime(timeStr.replace(/-/g, '\/'), 'yyyy/MM/dd');
                var beginTime = Date.parseTime('2000/01/01','yyyy/MM/dd');
                return (endTime - beginTime)/(24*60*60*1000);
            },
            checkExistHourVal:function(arr,beginHour,beginMin,endHour,endMin){
                if(beginMin != 0) {
                    var t = beginHour*100+beginMin;
                    if(!arr[t]){
                        arr[t] = true;
                    } else{
                        return true;
                    }
                    beginHour++;
                }
                if(endMin != 0) {
                    var t = endHour*100;
                    if(!arr[t]){
                        arr[t] = true;
                    } else{
                        return true;
                    }
                }

                for(var i = beginHour; i<endHour;i++){
                    var t = i*100
                    if(!arr[t]){
                        arr[t] = true;
                    } else{
                        return true;
                    }
                    t+=30;
                    if(!arr[t]){
                        arr[t] = true;
                    } else{
                        return true;
                    }
                }
                return false;
            },
            checkArrExistVal:function(arr,beginIndex,endIndex){
                for(var i = beginIndex; i<=endIndex;i++){
                    if(!arr[i]){
                        arr[i] = true;
                    }else{
                        return true;
                    }
                }
                return false;
            },
            validate:function () {
                var reg = /(^[1-9]\d*(\.\d{1,8})?$)|(^[0]{1}(\.\d{1,8})?$)/;
                var showPriceSpan = $('#priceType .dateDim span:visible.selected');
                $(".price-tabs .errorRed").removeClass("errorRed");
                for(var i = 0; i<showPriceSpan.length;i++){
                    var e = showPriceSpan[i];
                    var dataType = $(e).attr("date-type");
                    //每个电价类型单独出来
                    var priceDetail = $('.priceSetting .price-tabs .price-detail[data-type="'+dataType+'"]');
                    //是否使用默认电价选择
                    var defaultPriceSel = priceDetail.find(".defaultPrice span.selected").attr('date-type');
                    // if(defaultPriceSel == "no"){//默认电价不校验，就算开始有问题 此处也不能修改默认电价
                    //共设置了多少个时间段
                    var totalTimeSel = priceDef.getElePricedatenumArr(priceDetail.find("."+dataType+" tr.priceDataRow"),"pricedatenum");
                    var priceInput = priceDetail.find("."+dataType+" tr.priceDataRow .price");
                    //是否有输入框未填单价,或者电价填写错误
                    var error;
                    var hasEmptyInput = false,hasErrorPrice = false;
                    priceInput && $.each(priceInput,function(t,e1){
                        var priceT = $(e1).val();
                        if(!priceT){
                            hasEmptyInput = true;
                            error = Msg.stationInfo.addStation.priceSettingList.plsFillinPriceinfo;
                        }else{
                            //电价校验
                            if(reg.test(priceT) != true || priceT > 10000) {
                                error = Msg.stationInfo.addStation.priceSettingList.plsFillinPriceCorrectly;
                                hasErrorPrice = true;
                            }
                        }
                        if(error){
                            $(e1).addClass("errorRed").tooltip({
                                title: error,
                                placement: "top",
                                container: "body"
                            });
                        }
                    });
                    //未设置时间段或者存在未添加单价 直接return
                    if(!totalTimeSel || totalTimeSel.length<=0 || hasEmptyInput || hasErrorPrice){
                        App.alert(error || Msg.stationInfo.addStation.priceSettingList.plsFillinPriceinfo);
                        !priceDetail.is(":visible") && ($(e).click());
                        return false;
                    }
                    var dayArr = {};
                    for(var j = 0; j<totalTimeSel.length;j++) {
                        //每一行的tr
                        var timeSel = priceDetail.find("."+dataType+" tr.priceDataRow[pricedatenum="+(totalTimeSel[j])+"]");
                        var hours={};
						var hourMill = [];
                        var beginDate = $(timeSel[0]).find(".beginDate").val();
                        var endDate = $(timeSel[0]).find(".endDate").val();
                        var beginDateIndex = priceDef.getDateIndex(beginDate);
                        var endDateIndex = priceDef.getDateIndex(endDate);
                        var dayError,hourError;//天是否存在错误，错误信息，小时是否存在错误
                        if(beginDateIndex > endDateIndex){
                            dayError = true;
                            error = Msg.stationInfo.addStation.priceSettingList.begineqEnd;
                        }else{
                            //天是否交叉
                            dayError = priceDef.checkArrExistVal(dayArr,beginDateIndex,endDateIndex);
                            if(dayError) error = Msg.stationInfo.addStation.priceSettingList.dateRangeCross;
                        }
                        if(dayError){
                            var $td = $($(timeSel[0]).find(".beginDate").parents("td")).addClass("errorRed");
                            $td.tooltip({
                                title: error,
                                placement: "top",
                                container: "body"
                            });
                            App.alert(error);
                            return false;
                        }
                        for(var k = 0; k<timeSel.length;k++){
                            var e2 = timeSel[k];
                            var beginTime = $($(e2).find(".beginTime").find('input')[0]).val() -0;
							var beginMin = $($(e2).find(".beginTime").find('input')[1]).val() -0;
                            var endTime = $($(e2).find(".endTime").find('input')[0]).val() -0;
							var endMin = $($(e2).find(".endTime").find('input')[1]).val() -0;
							//转毫秒数比较
							var beginMill = beginTime * 100 + beginMin;
							var endMill = endTime * 100 + endMin;
							hourMill.push([beginMill, endMill]);
                            if(beginMill >= endMill) {
                                hourError = true;
                                error = Msg.stationInfo.addStation.priceSettingList.begineqEnd;
                                var $td = $(e2).find(".beginTime").parents("td").addClass("errorRed");
                                $td.tooltip({
                                    title: error,
                                    placement: "top",
                                    container: "body"
                                });
                                return false;
                            }
                            //小时是否有交叉
                            hourError = priceDef.checkExistHourVal(hours, beginTime, beginMin, endTime, endMin);
                            if(hourError) {
                                error = Msg.stationInfo.addStation.priceSettingList._24hoursCross;
                                var $td = $(e2).find(".beginTime").parents("td").addClass("errorRed");
                                $td.tooltip({
                                    title: error,
                                    placement: "top",
                                    container: "body"
                                });
								App.alert(error);
                                return false;
                            }
                        }

                        // 满足24小时
						var mill24 = 0;
                        if(hourMill && hourMill.length) {
                            for(var k=0;k<hourMill.length;k++) {
                                var oneP = hourMill[k];
                                mill24+= oneP[1]-oneP[0];
                            }
                            if(mill24 != 2400) {
                                App.alert(Msg.stationInfo.addStation.priceSettingList.fill24notEnough);
                                return false;
                            }
                        }
                    }
                }
                return true;
            },

            priceTotals:function (priceType) {
                var priceTotal = [];
                $(".price-tabs").find("[price-type=" + priceType + "]").find(".parentRow").each(function(k,v){
                    if (!$(this).is(":visible")) {//dom节点不可见则退出(已经删除的dom节点)
                        return;
                    }
                    var rangeStart = $(v).find(".beginDate").val().replace(/-/g, '\/');
                    var rangeEnd = $(v).find(".endDate").val().replace(/-/g, '\/');
                    // 电价默认前端以东8区时间传入到后端
                    var rangeS = Date.parseTime(rangeStart,"yyyy/MM/dd",8);
                    var rangeE = Date.parseTime(rangeEnd,"yyyy/MM/dd",8);
                    // 兼容IE、FireFox
                    if(isNaN(rangeS) || isNaN(rangeE)){
                        rangeS = Date.parseTime(rangeStart);
                        rangeE = Date.parseTime(rangeEnd);
                    }
                    var priceId = $(v).attr("priceId");
                    var price = {
                        "id":priceId,
                        "beginDate":rangeS,
                        "endDate":rangeE,
                        "priceType": priceType,
                        //"currency":unitCode,
                        "domainId":-1,
                        "stationCode":"system"
                    };
                    var priceItems = [];
                    var $pricedatenum = $(".price-tabs").find("[price-type=" + priceType + "]").find($('.priceDataRow[pricedatenum=' + $(v).attr('pricedatenum')+']') )
                    $pricedatenum.each(function(){
                        var itemid = $(this).find(".operate").find(".delPriceTimeBtn").attr("id");
                        var itemid =  itemid ? itemid : null;
                        var startTemp = priceDef.valueFormat($($(this).find(".beginTime").find('input')[0]).val());//$(".beginTime").html().split(":")[0];
                        var beginMin = double.double($($(this).find(".beginTime").find('input')[1]).val());
                        var endTemp = priceDef.valueFormat($($(this).find(".endTime").find('input')[0]).val());//$(".endTime").html().split(":")[0];
                        var endMin = double.double($($(this).find(".endTime").find('input')[1]).val());
                        // var end = endTemp == 0 ? "24":endTemp;
                        var priceTemp = $(this).find(".price").val();
                        var timeTypeTemp = $(this).find(".ele_type")  ? $(this).find(".ele_type").val(): "3";
                        var item = {
                            "id": itemid,
                            "beginHour": startTemp,
                            "beginMin": beginMin - 0,
                            "endHour": endTemp,
                            "endMin": endMin - 0,
                            "price": priceTemp,
                            "timeType": timeTypeTemp
                        };
                        priceItems.push(item);
                    });
                    var tempresult ={
                        "price":price,
                        "items":priceItems
                    };
                    priceTotal.push(tempresult);
                });
                return priceTotal;
            },
            addPrice:function(cb){
                var updateFlag = 0
                var priceType = $("#addStationDialogN").find("span.selected").attr("price-type");
                var deletePrice = priceDef.deletePrice(deleteItemId,priceType);
                var updatePrice = priceDef.updatePrice("system",-1,priceType);
                var priceTotals = priceDef.priceTotals(priceType);
                if ((updatePrice && updatePrice.length > 0) || updateFlag == null){
                    updateFlag = 1;
                }
                if(!priceDef.validate()){
                    return;
                }
                var param={
                    updateFlag:updateFlag,
                    pricetotal: priceTotals,
                    priceType:priceType,
                    deletePrice: deletePrice,
                    updatePrice:updatePrice
                };
                $.http.ajax('/ongridprice/add',
                    param,// 保存内容
                    function(data){
                        var result = data;
                        if(result && result.success){
                            $(".priceSetting").find("span.selected").click();
                            // $("#"+priceSetting.tabId).trigger('click');
                            App.alert(Msg.partials.main.io.dm.promptinfor.saveSuccess);

                            cb() && cb();
                        }else{
                            if(data.data.flag && data.data.message) {
                                App.alert(data.data.message);
                                return;
                            }
                            if(data.data.flag || data.data.flag1) {
                                App.alert(Msg.stationInfo.addStation.priceSettingList.plsFillinPriceCorrectly);
                                return;
                            }
                            App.alert(Msg.partials.main.io.dm.promptinfor.saveFailed);
                        }
                    });
            },
            initToolBar: function() {
                var dateFmt = Msg.dateFormat.yyyymmdd;
                var defaultDate = new Date().format(dateFmt, true);
                // 日期选择面板初始化
                $('#price_search_time').val(defaultDate).off('click').on('click', function(params) {
                    DatePicker({
                        dateFmt : dateFmt,
                        // isShowClear : true,
                        isShowToday: true
                    });
                })
                $('#price_dbtn_search').off('click').on('click', function(e) {
                    var typeNum = $('div.dateDim span.selected').attr('price-type');
                    priceDef.initPrice(typeNum);
                    $("#testSaveStation").hide();
                    $("#update").show();
                    $(".price-tabs").find("table").find('tr:last').hide();
                    $(".price-tabs").find("table").find('.operate').hide();
                });

                $('#templete').off('click').on('click',function (e) {
                    var params = {};
                    params.tableNameArr=["开始日期", "结束日期", "电价类型", "开始时间", "结束时间","电价"];
                    params.fileName = Msg.stationInfo.addStation.priceSettingList.priceImportModel;
                    $.download("/ongridprice/downloadGridPriceModel",JSON.stringify(params),'post');
                })
                $("#importPMFile").bind("change", priceDef.uploadFileChange);
            },
            uploadFileChange: function () {
                main.uploadWithRule($(this), {
                    url: '/ongridprice/importGridPrice',
                    params:{
                        priceType: $('div.dateDim span.selected').attr('price-type')
                    }
                },true);
                $("#importPMFile").val('');
            },
            Render: function(){
                $('#import').wrap('<span class="upload"></span>')
                    .after($('<input type="file" name="importPMFile" id="importPMFile" class="upload-input-file i18n" title="' + Msg.upgrade.selecUploadFile
                        + '" accept="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"/>'));
                priceDef.initToolBar();
            	//货币单位
            	$('#addStationDialogN .priceUnit').text(App.getCurrencyUnit(true));

                if(!$(".selected").length){
                    $($('#priceType .dateDim span')[0]).attr('class','selected');
                }
                priceDef.priceTypeClick();
                $(".priceSetting").find("span.selected").click();
                $("#update").off('click').click(function () {
                    $(".price-tabs").find("table").find('tr:last').show();
                    $(".price-tabs").find("table").find('.operate').show();
                    $("#testSaveStation").show();
                    $("#update").hide();
                    $(".beginDate").removeAttr("disabled");
                    $(".endDate").removeAttr("disabled");
                    $(".ele_type").removeAttr("disabled");
                    $(".beginTime").find('input').removeAttr("disabled");
                    $(".endTime").find('input').removeAttr("disabled");
                    $(".price").removeAttr("disabled");
                    priceDef.initPriceItemEvent();
                });
                $("#testSaveStation").off("click").click(function () {
                    $.when(setTimeout(function(){
                        $(".price-tabs .errorRed").tooltip("destroy");
                    },0));
                    priceDef.addPrice(function(){
                        $("#testSaveStation").hide();
                        $("#update").show();
                        $(".price-tabs").find("table").find('tr:last').hide();
                        $(".price-tabs").find("table").find('.operate').hide();
                    });
                });
                deleteItemId = [];
            }
        };
        return priceDef;
    });