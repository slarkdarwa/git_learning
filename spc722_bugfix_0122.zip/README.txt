iesp-modules/iesp-client/iesp-web-client/webapp/ecm/babel/partials/report/layeringReport.js
iesp-modules/iesp-client/iesp-web-client/webapp/ecm/scripts/partials/main/rm/eeReportManage/dayCapProfit.js
iesp-modules/iesp-client/iesp-web-client/webapp/ecm/scripts/partials/main/rm/eeReportManage/deviceReport.js
iesp-modules/iesp-client/iesp-web-client/webapp/ecm/scripts/partials/main/rm/eeReportManage/readoutReport.js
iesp-modules/iesp-client/iesp-web-client/webapp/ecm/scripts/partials/main/rm/eeReportManage/rmInverterDay.js
