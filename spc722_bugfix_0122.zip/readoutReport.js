App.Module('readoutReport', '示值查询', ['ecm/partials/main/rm/eeReportManage/tableToolUtil','partials/main/rm/reportUtils'],
    function(tUtil, reportUtils) {

    // 全局变量
    var _G = {
        para: {},
        devTypeId: '206',
        defaultNode: null
    };

    var dUtil = null;

    var service = {
        init: function(params) {
            _G.para = params;
            dUtil = params.dUtil;
            util.find = params.find;

            // 初始化按钮
            service.initToolBtn();

            // service.initDefautTree();

            _G.hasInitTime = false;
            service._initDefaultTopTree();
        },


        _initDefaultTopTree: function() {
            var params = {minLevel: env.MODEL_DEVICE, devTypes:_G.devTypeId};
            if(_G.para && _G.para.menuSId) {
              params.sIds = _G.para.menuSId;
            }
            env.bindTopper({
              isRadio: false,
              autoCheck: true,
              params: params,
              fnFilter: [env.MODEL_DEVICE],
              nodeAnalyser: {
                sId: ['stationCode', true],
                dId: ['id', true],
                locId: ['domainId', true]
              },
              fnReady: function(checker) {
                _.isFunction(checker) && checker(env.MODEL_STATION, function(node){
                    return !!node.isPowerPoint;
                });
              },
              fnChange: function(opts) {
                _G.para.sId = opts.sId && Array.from(new Set(opts.sId)).join();
                _G.para.dId = opts.dId && Array.from(new Set(opts.dId)).join();

                // 域参数变化时重新初始化时间
                var oldLocId = _G.para.locId;
                _G.para.locId = opts.locId && opts.locId[0];
                if(oldLocId != _G.para.locId) service.initTimer();
                // bugifx 电站树从未勾选过,时间插件未加载,导致查询异常
                if(!_G.hasInitTime) service.initTimer();

                service.initTab();
              }
            });
        },

        initDefautTree: function() {
            // 获取默认参数后加载内容
            _G.defaultNode = [];
            var sId = util.getStationCode();
            $.http.ajax("/devManager/querySingleStationLocation", {
                minLevel: "DEVICE",
                devTypes: _G.devTypeId,
                sIds: sId
            }, function(data) {
                if(data && data.success) {
                    // 默认选中第一层的设备
                    $.each(data.data, function(n, v) {
                        if(v.pid && (v.pid + '').replace(/\|.?/,'') == sId && v.model == 'DEVICE') {
                            _G.defaultNode.push(v);
                        }
                    });
                }
                // 初始化树
                service.initTree();
                // 初始化表
                service.initTab();

            });
        },

        initTimer: function(startDay, endDay) {
            _G.hasInitTime = true;

            var eTime;
            var sTime;
            var withDuration;
            var locId = _G.para.locId;
            // 默认托管域
            var v = reportUtils.domainDate(locId || parseInt(sessionStorage.getItem('twoLevelDomain')) || 1, startDay, endDay);
            if(!_.isEmpty(v)) {
                util.find('#date-container').attr('max-date-interval', v[2]);
                sTime = v[0];
                eTime = v[1];
                withDuration = true;
            } else {
                eTime = new Date();
                sTime = new Date(eTime.getTime());
                sTime.setDate(1);
            }
            var fmt = dUtil.getDateFormat();
            eTime = eTime.format(fmt, true);
            sTime = sTime.format(fmt, true);

            dUtil.intiDoubleDateSelector(service.initTab, util.find, function() {
                util.find('#eTime').attr('max-date', new Date().format(fmt,true));
            }, eTime, true, util.find('#timePicker'), null, sTime);

            if(withDuration) {
                util.find(".leftSwitch").unbind("click").click(function (e) {
                    var eTime = new Date($("#sTime").val()) || new Date();
                    service.initTimer(null, eTime);
                    service.initTab();
                });
                util.find(".rightSwitch").unbind("click").click(function (e) {
                    var sTime = new Date($("#eTime").val());
                    service.initTimer(sTime, null);
                    service.initTab();
                });
            }
        },

        initToolBtn: function() {
            util.find(".search-button").unbind("click").click(function() {
                service.initTab();
                $(this).find('button').blur();
            });
            util.find(".export-button").unbind("click").click(function(){
                var params = util.getParam();
                util.find('#param').val(JSON.stringify(params));
                util.find("#_csrf").val(main.getCsrf());
                util.find('#exort_form').attr('action', 'ecmUsageReportManage/exportReadoutReport').submit();
                $(this).find('button').blur();
            });
        },

        initTree: function() {
            util.find("#deviceTree").attr('placeholder', Msg.partials.main.rm.dayCapPrpfit.selectObiect);
            var defaultId = [];
            var defaultName = [];
            $.each(_G.defaultNode, function(n, v) {
                if(v.model == "DEVICE") {
                    defaultId.push(v.id);
                    defaultName.push(v.name);
                }
            });
            util.find("#deviceTree").attr('treeSelId', defaultId.join());
            util.find("#deviceTree").val(defaultName.join());

            util.find("#deviceTree").iemsInputTree({
                url: "/devManager/querySingleStationLocation",
                chkboxType: {"Y": "ps", "N": "ps"},
                contentClass: 'layout-tree',
                selectNodes: defaultId,
                param: {
                    minLevel: "DEVICE",
                    devTypes: _G.devTypeId,
                    sIds: util.getStationCode()
                },
                blurAfater: function(tree, selectedId) {
                   // service.initTab();
                }
            });
        },

        initTab: function() {
            util.find("#reportTable").GridTable({
                url: 'ecmUsageReportManage/listReadoutReport',
                max_height: 600,
                params: util.getParam(),
                pageBar: false,
                colResize: true,
                colModel: util.getColModel(),
                onLoadReady: function(data, btrs, htrs, totalRecords) {
                    tUtil.mergedCol([1], btrs);
                }
            });
        }


    };



    var util = {
        getStationCode: function() {
            return util.find("#stationSelector").val();
        },

        getParam: function() {
            return {
                // theSId: util.getStationCode(),
                // dIds: util.find("#deviceTree").attr('treeSelId'),
                theSId: _G.para.sId,
                dIds: _G.para.dId,
                devTypeId: _G.devTypeId,
                timeType: dUtil.getTimeType(),
                sTime: dUtil.getStartTimeTxt(),
                eTime: dUtil.getEndTimeTxt()
            };
        },

        getColModel: function() {
            var model = [
                {display: "dId", name: "dId", hide: true},
                {display: Msg.limitManage.devName, name: "busiName"},
                {display: Msg.companyManage.companyType, name: "type", fnInit: util.formatType},
                {display: Msg.partials.main.rm.dayCapPrpfit.data.startPower+'</br>(kWh)', name: "startPower"},
                {display: Msg.partials.main.rm.dayCapPrpfit.data.endPower+'</br>(kWh)', name: "endPower"},
                {display: Msg.thirdInterface.itemCode.use_power+'</br>(kWh)', name: "usePower"},
                // {display: '电费</br>(元)', name: "cost"},
            ];
            return model;
        },

        formatType: function(dom, value, record) {
            var txt = '';
            switch(value) {
            case 1:
              txt = Msg.stationReport.tip;
              break;
            case 2:
              txt = Msg.stationReport.peak;
              break;
            case 3:
              txt = Msg.stationReport.flat;
              break;
            case 4:
              txt = Msg.stationReport.valley;
              break;
            default:
              txt = Msg.stationReport.total;
              break;
            }

            $(dom).html(txt).attr("title", txt).parent().attr('title', txt);
        }


    };


    return {
        Render: function (params) {
            service.init(params);
        }
    };

});