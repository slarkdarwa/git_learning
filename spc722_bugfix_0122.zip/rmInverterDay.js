/**
 * 逆变器报表管理页面处理
 */
App.Module('rm_inverterDay', '模块功能：逆变器报表', ['partials/main/rm/reportUtils', 'jquery', 'ValidateForm', 'iemsInputTree',
    'GridTable', 'datePicker'], function (reportUtils) {
    var rm = {
        // dev tree devType set const
        devTypeSet: {
            '1': [1, 14, 38],
            '10': [10],
            '17': [9, 17, 40, 41],
            '-100': [1, 15],
        },
        maxPvNum: 30,
        dUtil: false,
        find: false,
        para: {},
        queryParamCache: {},
        oneDayMills: 24*3600*1000,



        //外部调用初始化方法
        Render: function (params) {
            rm.dUtil = params.dUtil;
            rm.find = params.find;
            rm.setParam('sId', params.sId);

            rm.hasInitTime = false;
            rm._initTopTree();
        },


        getParam: function(key) {
            rm.setParam('devType', rm.getPage("#dev_type_id").val());
            rm.setParam('statDim', rm.getPage("#stat_time_dim").val());
            rm.para.statTime = rm.getPage("#sTime").val() || rm.getPage("#date-container").val();
            rm.para.endTime = rm.getPage("#eTime").val();
            rm.setParam('statTime', Date.parseTime(rm.para.statTime, rm.formatDateShow(rm.para.statDim)));
            rm.setParam('endTime', Date.parseTime(rm.para.endTime, rm.formatDateShow(rm.para.statDim)));

            // rm.setParam('timeZone', Date.getTimezone());
            // rm.setParam('userId', sessionStorage.getItem('userid'));
            // rm.setParam('isSeach', rm.isSeletNode());

            rm.para.devTypeIds = rm.devTypeSet[rm.para.devType].join();

            return _.isEmpty(key) ? rm.para : rm.para[key];
        },

        setParam: function(key, val) {
            if(!_.isEmpty(key)) rm.para[key] = val;
        },


        //初始化topTree
        _initTopTree: function() {
            var params = {minLevel: env.MODEL_DEVICE, devTypes:rm.getParam('devTypeIds')};
            var _SId = env.getSingleParams('sId');
            if(_SId){
                params.sIds = _SId;
            }
            env.bindTopper({
                isRadio: false,
                autoCheck: false,
                params: params,
                fnFilter: [env.MODEL_DEVICE, env.MODEL_STATION],
                nodeAnalyser: {
                    sId: ['stationCode', true],
                    dId: ['id', env.MODEL_DEVICE],
                    locId: ['domainId', true]
                },
                fnChange: function(opts) {
                    var _SId = env.getSingleParams('sId');
                    if(_SId){
                        params.sId = _SId;
                    }
                    rm.setParam('sIds', _SId || (opts.sId && opts.sId.join()));
                    var dId = opts.dId && opts.dId.join();
                    rm.setParam('dIds', dId);
                    var locId = opts.locId && opts.locId[0];

                    // 展示数据的时间维度为天,且域参数变化时才重新初始化时间
                    params = rm.getParam();
                    var oldLocId = params.locId;
                    rm.setParam('locId', locId);
                    if(oldLocId != locId && params.statDim == '2') rm.initTimer(params.statDim);
                    // bugifx 电站树从未勾选过,时间插件未加载,导致查询异常
                    if(!rm.hasInitTime) rm.initTimer();

                    rm.initToolBar();
                    rm.initKpiTable();
                }
            });
        },

        /**
         * 获取2个日期框
         * @returns {string}
         */
        initTimer:function(statTimeDim, startDay, endDay){
            rm.hasInitTime = true;
            rm.getPage("#timePicker").remove();
            var doubleDatePicker = '<div class="dateShow dateShow-d"  id="timePicker">'
                +'   <div class="leftSwitch switch"></div>'
                +'   <!-- 日期类型 1:day 2:month 3:year -->'
                +'   <div id="date-container" date-type="1" max-date-interval="30" date-change-type="1">'
                +'       <input type="text" class="Wdate date-input" id="sTime" min-date max-date>'
                +'        - <input type="text" class="Wdate date-input " id="eTime" min-date max-date>'
                +'   </div>'
                +'   <div class="rightSwitch switch"></div>'
                +'</div>';
            rm.getPage("#stat_time_dim").after(doubleDatePicker);

            statTimeDim = statTimeDim || rm.getParam('statDim') || '2';
            var rule = reportUtils.timeRule[statTimeDim];
            rm.getPage('#date-container').attr('date-type', rule['date-type']);
            rm.getPage('#date-container').attr('date-change-type', rule['date-change-type']);
            rm.getPage('#date-container').attr('max-date-interval', rule['max-date-interval']);

            var today = new Date();
            var eTime = today;
            var sTime;
            var withDuration = false;
            switch (statTimeDim) {
                    case "2":
                        var locId = rm.getParam('locId');
                        // 默认托管域
                        var v = reportUtils.domainDate(locId || parseInt(sessionStorage.getItem('twoLevelDomain')) || 1, startDay, endDay);
                        if(!_.isEmpty(v)) {
                            rm.getPage('#date-container').attr('max-date-interval', v[2]);
                            sTime = v[0];
                            eTime = v[1];
                            withDuration = true;
                        } else {
                            sTime = new Date(eTime.getTime());
                            sTime.setDate(1);
                        }
                        break;
                    case "0":
                    case "1":
                        sTime = today;
                        sTime.setHours(0);
                        sTime.setMinutes(0);
                        sTime.setSeconds(0);
                        break;
                    case "3":
                        // ISO-8601 week FirstDayOfWeek is MONDAY
                        eTime = endDay || eTime;
                        sTime = startDay;
                        var day;
                        if(sTime && sTime < eTime) {
                            day = sTime.getDay() || 7;
                            eTime = new Date(sTime.getTime()+(7-day)*rm.oneDayMills);
                            if(eTime > today) eTime = today;
                        } else {
                            day = eTime.getDay() || 7;
                            sTime = new Date(eTime.getTime()-(day-1)*rm.oneDayMills);
                        }
                        break;
                    case "4":
                    case "5":
                        sTime = eTime;
                        break;
                }
            eTime = eTime.format(rule['fmt'], true);
            sTime = sTime.format(rule['fmt'], true);

            rm.dUtil.intiDoubleDateSelector(null, rm.find, function() {
                rm.find('#eTime').attr('max-date', new Date().format(rule['fmt'], true));
            }, eTime, true, rm.getPage('#timePicker'), null, sTime);
            // 日类型需要按周期切换,重写左右切换按钮事件
            if(statTimeDim == '2' && withDuration) {
                rm.getPage(".leftSwitch").unbind("click").click(function (e) {
                    eTime = new Date($("#sTime").val()) || new Date();
                    rm.initTimer(rm.getParam('statDim'), null, eTime);
                });
                rm.getPage(".rightSwitch").unbind("click").click(function (e) {
                    sTime = new Date($("#eTime").val());
                    rm.initTimer(rm.getParam('statDim'), sTime, null);
                });
            } else if (statTimeDim == '3') {
                rm.getPage(".leftSwitch").unbind("click").click(function (e) {
                    eTime = new Date($("#sTime").val()) || new Date();
                    eTime = new Date(eTime.getTime()-7*rm.oneDayMills);
                    var day = eTime.getDay() || 7;
                    eTime = new Date(eTime.getTime()+(7-day)*rm.oneDayMills);
                    if(eTime > today) eTime = today;
                    rm.initTimer(rm.getParam('statDim'), null, eTime);
                });
                rm.getPage(".rightSwitch").unbind("click").click(function (e) {
                    sTime = new Date($("#eTime").val());
                    sTime = new Date(sTime.getTime()+7*rm.oneDayMills);
                    var day = sTime.getDay() || 7;
                    sTime = new Date(sTime.getTime()-(day-1)*rm.oneDayMills);
                    rm.initTimer(rm.getParam('statDim'), sTime, null);
                });
            }
        },



        //初始化toolbar
        initToolBar: function () {
            rm.getPage('#stat_time_dim').unbind('change').change(function(){
                rm.initTimer($(this).val());
            });
            rm.getPage('#dev_type_id').unbind('change').change(function(){
                rm._initTopTree(rm.devTypeSet[$(this).val()].join());
            });
            rm.getPage('#kpi_dbtn_search').unbind("click").click(function() {
                rm.initKpiTable();
            });

            rm.getPage('#kpi_export').unbind("click").on("click", function () {
                rm.laodExportPage();
            });

            /*rm.getPage('#kpi_export').click(function() {
                rm.exportKpiTable();
            });
            $('#rm_inverter_subscribe').click(function() {
                rm.subscribe();
            });
            $('#kpi_inverter_search').ValidateForm("kpi_inverter_search", {
                show: 'horizontal',
                fnSubmit: rm.initKpiTable,
                model: [[
                    {
                    input: 'select',
                    type: 'select',
                    show: Msg.partials.main.rm.dayCapPrpfit.statType,
                    name: 'statType',
                    extend: {
                        id: "stat_inverter_type"
                    },
                    options: [
                        { value: '2', text: Msg.partials.main.rm.dayCapPrpfit.statTimeDimArr[0] },
                        { value: '4', text: Msg.partials.main.rm.dayCapPrpfit.statTimeDimArr[1] },
                        { value: '5', text: Msg.partials.main.rm.dayCapPrpfit.statTimeDimArr[2] }
                    ],
                    fnInit: function (dom) {
                        $(dom).unbind('change').change(function () {
                            rm.getPage("#stat_inverter_time").val("");
                            switch (parseInt(this.value || '2')) {
                                case 2:
                                    rm.getPage("#stat_inverter_time").val(Date.parse(Date.parseTime()).format('yyyy-MM-dd', true));
                                    break;
                                case 4:
                                    rm.getPage("#stat_inverter_time").val(Date.parse(Date.parseTime()).format('yyyy-MM', true));
                                    break;
                                case 5:
                                    rm.getPage("#stat_inverter_time").val(Date.parse(Date.parseTime()).format('yyyy', true));
                                    break;
                            }
                        })
                    }
                }, {
                    input: 'input',
                    type: 'text',
                    show: Msg.partials.main.rm.dayCapPrpfit.statTime,
                    name: 'statDevTime',
                    width: '165',
                    extend: {
                        id: 'stat_inverter_time',
                        readonly: true,
                        class: 'Wdate'
                    },
                    fnClick: function () {
                        DatePicker({dateFmt: rm.formatDateShow(rm.getPage("#stat_inverter_type").val()),});
                    },
                    fnInit: function (dom) {
                        var stationTimeZone = Date.getTimezone();
                        var stationTime = Date.parseTime();
                        if ($.trim(sessionStorage.getItem("sId")) != "") {
                            $.http.POST('/station/info', { "stationCode": sessionStorage.getItem("sId") }, function (res) {
                                if (res.success) {
                                    stationTimeZone = res.data.data.stationTimeZone;
                                    stationTime = res.data.data.stationTime;
                                    stationTime = $.isNumeric(stationTime) ? Number(stationTime) : new Date().getTime();
                                }
                                $(dom).val(Date.parse(stationTime, stationTimeZone).format(rm.formatDateShow(rm.getPage("#stat_inverter_type").val())));
                                rm.initKpiTable();
                            });
                        } else {
                            $(dom).val(new Date(stationTime).format(rm.formatDateShow(rm.getPage("#stat_inverter_type").val())));
                            rm.initKpiTable();
                        }
                    }
                }]],
                extraButtons: [
					{
					    input: 'button',
					    align: 'right',
					    show: Msg.partials.main.rm.dayCapPrpfit.subscribe,// 订阅
					    name: '',
					    fnClick: rm.subscribe,
					    extend: {
					        id: 'rm_inverter_subscribe',
					        class: 'btn blueBtn btnThemeA noIcon',
					        permission: 'rm_inverter_subscribe'
					    }
					},
                    {
                        input: 'button',
                        align: 'right',
                        show: Msg.partials.main.rm.dayCapPrpfit.export,//'导出',
                        name: '',
                        fnClick: rm.exportKpiTable,
                        extend: {
                            id: 'kpi_inverter_export',
                            class: 'btn blueBtn btnThemeA noIcon',
                            permission: "rm_inverter_exportReport"
                        }
                    }
                ]
            });*/
        },

        laodExportPage: function() {
            App.dialog({
                id: 'rmExportDialog',
                title: Msg.export,
                width: 350,
                height: 100,
                contentClass: "panelScaleIn panel-popup-modal ecm-module",
                openEvent: function(){
                    var $c = $('#rmExportDialog .modal-body-content');
                    var $check = $('<div class="exportCheck">'
                            + '<label><sapn class="i18n">' +Msg.companyManage.companyType+'</span><span>:</span></label>'
                            + '<input name="exoprtType"  id="type_Excel" checked type="radio" value="1" class="itemCheck"/>'
                            + '<label for="type_Excel" class="i18n">Excel</label>'
                            + '<input name="exoprtType"  id="type_csv" type="radio" value="2" class="itemCheck"/>'
                            + '<label for="type_csv" class="i18n">CSV</label>'
                        + '</div>');
                    $c.append($check);
                },
                buttons: [{
                        id: 'okId',
                        type: 'submit',
                        text: Msg.sure,
                        click: function(e, dom){
                            rm.exportGridTable($('input:checked', dom).val());
                            dom.modal('hide')
                        }
                    },{
                        id: 'cancelId',
                        type: 'button',
                        text: Msg.close,
                        clickToClose: true
                    }],
            });
        },

        exportGridTable: function (exoprtType) {
            var param = rm.getParam();
            param.exoprtType = exoprtType;

            // 组串不支持选择指标,通过最大组串数量控制导出指标
            if(param.devType == -100) {
                param.maxPvNum = rm.queryParamCache[param.devType+'@'+param.statDim]
            } else {
                var sbColum = rm.getFilterColum(param.devType, param.statDim);
                // 获取对应维度的默认展示列, 首次进入未缓存值则使用系统默认的列 OR 使用用户选择的缓存值
                var sbColum = !sbColum ? reportUtils.showDevDefaultColums(param.devType, param.statDim, null) : sbColum;
                var isHide = !main.IsPowerCode();
                if(isHide){
                    sbColum.remove("stationUserCode");
                    sbColum.remove("userCode");
                }
                param.selectColumn = sbColum;
            }

            rm.getPage('#rm_inv_param').val(JSON.stringify(param));
            rm.getPage('#kpi_inv_exort_form').find("#_csrf").val(main.getCsrf());
            rm.getPage('#kpi_inv_exort_form').submit();
        },

        getPvNum: function(sIds, dIds) {
            var maxPvNum = rm.maxPvNum;
            $.http.ajax('/inverterRm/getMaxValidPvNum', {sIds:sIds, dIds: dIds}, function (data) {
                if(data && data.success && data.data) maxPvNum = data.data;
            }, null, false);
            return maxPvNum;
        },

        initSelectColums: function(devType, statDim) {
            var dom = rm.getPage('#kpi_inv_grid');
            if(dom) rm.queryParamCache[devType + '@' + statDim] = dom.GridTableNowColumn();
        },

        getFilterColum: function(devType, statDim) {
            return rm.queryParamCache[devType + '@' + statDim];
        },

        //初始化表格
        initKpiTable: function () {
            rm.getPage("#kpi_inv_grid_tile").html(Msg.partials.main.rm.inverterReport); //逆变器报表

            var params = rm.getParam();
        	if(main.isSNameSort()){
        		params.orderBy = "sName";
        	}else{
                params.orderBy = "fmtCollectTimeStr"; // 后端使用collectTime排序
        	}
            params.sort = 'asc'


            // 组件多行表头不支持过滤
            if(params.devType == -100) {
                var maxPvNum = rm.getPvNum(params.sIds, params.dIds);
                $('#kpi_inv_grid').GridTable({
                    url: '/inverterRm/listDevKpi',
                    title: false,
                    max_height: 600,
                    rp: 10,
                    freezeCol: 4,
                    resizable: false,
                    params: params,
                    idProperty: 'id',
                    colModels: reportUtils.showDevColums(params.devType, params.statDim, maxPvNum),
                    onLoadReady: function() {
                        // 缓存默认列
                        rm.queryParamCache[params.devType+'@'+params.statDim] = maxPvNum;
                    }
                });
            } else {
                var sbColum = rm.getFilterColum(params.devType, params.statDim);
                // 获取对应维度的展示列
                var cloumnArr = reportUtils.showDevColums(params.devType, params.statDim, null);
                // 系统默认列
                var systemColumDefault =  reportUtils.showDevDefaultColums(params.devType, params.statDim, null);
                // 获取对应维度的默认展示列, 首次进入未缓存值则使用系统默认的列 OR 使用用户选择的缓存值
                var columFilter = !sbColum ? systemColumDefault : sbColum;
                var freezeCol = function (columFilter, cloumnArr) {
                    return reportUtils.freezeCol(reportUtils.baseDevColums, columFilter, cloumnArr)
                };
                //加载表格
                rm.getPage('#kpi_inv_grid').GridTable({
                    url: '/inverterRm/listDevKpi',
                    title: false,
                    resizable: false,
                    max_height: 600,
                    rp: 10,
                    freezeCol: freezeCol,
                    defaultColumnFilter: systemColumDefault, //系统默认列
                    columnFilter: columFilter,  //当前显示的列
                    params: params,
                    idProperty: 'id',
                    colModel: cloumnArr,        //全部的列
                    onLoadReady: function() {
                        // 缓存默认列
                        rm.initSelectColums(params.devType, params.statDim);
                    }
                });
            }
        },


        /**
        * 统计方式为年|月时支持详情查看
        */
        showDetail: function (dom, value, data) {
            var params = {};
            params.dIds = rm.queryParamCache.dIds;
            params.statTime = rm.queryParamCache.statTime;
            params.userId = rm.queryParamCache.userId;
            params.stateType = rm.queryParamCache.stateType;
            params.timeZone = rm.queryParamCache.timeZone;
            if(main.isSNameSort()){
            	 params.orderBy = "sName";
                 params.sort = "asc";
        	}else{
                 params.orderBy = "productPower";
                 params.sort = "desc";
        	}
            params.statType = 1;
            params.dId = data.dId;
            dom.html("");
            var $a = $("<a/>");
            $a.css({
                "text-decoration": "none"
            }).html(value);
            if (Menu.containsSrc("rm_single_inverter_kpi_detail")) {
                $a.on("click", function () {
                    App.dialog({
                        id: 'singleInverterKpiDiv',
                        title: Msg.partials.main.rm.kpiDetail,
                        resizable: false,
                        width: 1430,
                        height: 580
                    }).loadPage({
                        url: '/partials/main/rm/rm_singleInverterDay.html',
                        preload: ['partials/main/rm/rmSingleInverterDay']
                    }, params);
                });
            }
            dom.append($a);
        },

        /**
         * 导出逆变器报表， form提交方式
         */
        exportKpiTable: function () {
            if (!rm.queryParamCache) {
                return App.alert({
                    title: Msg.info,
                    message: Msg.partials.main.rm.dayCapPrpfit.exportExp
                });
            }
            rm.getPage('#rm_inv_param').val(JSON.stringify(rm.queryParamCache));
            rm.getPage('#kpi_inv_exort_form').find("#_csrf").val(main.getCsrf());
            rm.getPage('#kpi_inv_exort_form').submit();

        },

        /**
         * 订阅
         */
        subscribe: function () {
            $.http.ajax('/inverterRm/checkMail', {
            }, function (res) {
                if (res.success) {
                    var settingDialog = App.dialog({
                        id:"inverterSubscribeDialog",
                        title: Msg.partials.main.rm.dayCapPrpfit.inverterSub,
                        width: 1010,
                        height: 800,
                    });
                    settingDialog.loadPage({
                        url: "/partials/main/rm/rm_inverterSubscribe.html",
                        preload: "partials/main/rm/inverterSubscribe"
                    });
                } else {
                    main.comonErrorFun(res.data);
                }
            });
        },

        /**
         * 格式化時間字符串顯示
         */
        formatDateShow: function (statyType) {
            var _formatStrs = {
                "0": "yyyy-MM-dd HH:mm:ss",
                "1": "yyyy-MM-dd HH:mm:ss",
                "2": "yyyy-MM-dd",
                "3": "yyyy-MM-dd",
                "4": "yyyy-MM",
                "5": "yyyy"
            }
            return _formatStrs[statyType] ? _formatStrs[statyType] : _formatStrs[1];
        },

        /**
         * 获取模块的域id dom
         */
        getPage: function (select, pDom) {
            var page = $('#rm_inverterDay', rm.pDom);
            return select ? page.find(select) : page;
        },
        /**
         * 是否有选中节点
         */
        isSeletNode : function(){
        	return env.getTopperOpts().sId ? true : false;
        },

    };

    return rm;
});