--  标串电流有效时段全部修改扩大,避免数据异常,无法计算达标率 wbj
UPDATE iems_params_common_t SET param_value = '12:00~13:00' WHERE param_key LIKE '%branchITime%';



ieap-kpi-statistic/src/main/java/com/pinnet/analytics/kpi/statistic/service/day/InverterKpiDayCalculator.java
ieap-kpi-statistic/src/main/java/com/pinnet/analytics/kpi/statistic/service/day/StdPvKpiDayCalculator.java
ieap-kpi-statistic/src/main/java/com/pinnet/analytics/kpi/statistic/util/InverterKpiStatUtil.java
ieap-kpi-statistic/src/main/java/com/pinnet/analytics/kpi/statistic/util/StationKpiStatUtil.java


iesp-modules/iems-busi/iems-basic-config/src/main/java/com/pinnet/basic/indexInput/IndexInputServiceImpl.java
iesp-modules/iems-busi/iems-web-server/src/main/java/com/pinnet/web/indexInput/controller/IndexInputController.java
iesp-modules/iesp-common/iems-unified-interface/src/main/java/com/pinnet/indexInput/service/IindexInputService.java

