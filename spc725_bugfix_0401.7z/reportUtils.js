/**
 * 报表类 工具类
 */
define([
    'jquery', 'GridTable', 'ValidateForm'
], function ($) {
    var reportUtils = {
        // return Array sDate, eDate, dateInterval
        domainDate: function(domainId, startDay, endDay) {
            var v = [];
            if(!!domainId) {
                $.http.ajax('/domain/queryDomainById', {domainId: domainId}, function(data) {
                    if (data && data.success) {
                        var monthlySettlementSpacing = data.data.monthlySettlementSpacing || 1;
                        var startDate = data.data.startDate;
                        var endDate = data.data.endDate;
                        if(!startDate || !endDate) return;
                        v[2] = ((endDate > startDate) ? (endDate - startDate) : (31-endDate + startDate-0) ) + (monthlySettlementSpacing-1)*31;

                        var today = new Date();
                        if(!endDay) endDay = today;
                        if(startDay) startDay.setDate(startDate);
                        if(startDay && startDay < endDay) {
                            v[0] = startDay;

                            endDay = new Date(startDay.getTime());
                            endDay.setDate(endDate);
                            if(v[0].getDate() >= endDay.getDate() && monthlySettlementSpacing == 0) monthlySettlementSpacing++;
                            if(monthlySettlementSpacing > 0) {
                                var y = parseInt(monthlySettlementSpacing/12);
                                var m = monthlySettlementSpacing%12;
                                if(y > 0) endDay.setFullYear(endDay.getFullYear() + y);
                                if(m > 0) endDay.setMonth(endDay.getMonth() + m);
                            }
                            if(endDay > today) endDay = today;
                            v[1] = endDay;
                        } else {
                            // 当月结束日期最多大到设定日, 历史月结束日期为设定日
                            v[1]  = endDay;
                            var eym = endDay.getFullYear()*100+endDay.getMonth();
                            var tym = today.getFullYear()*100+today.getMonth();
                            if(endDay.getDate() > endDate || eym < tym) {
                                v[1] = new Date(endDay.getTime());
                                v[1].setDate(endDate);
                            }

                            // 起始日期若大于结束日期，至少跨一个月
                            startDay = new Date(endDay.getTime());
                            startDay.setDate(startDate);
                            if(startDay.getDate() >= v[1].getDate() && monthlySettlementSpacing == 0) monthlySettlementSpacing++;
                            if(monthlySettlementSpacing > 0) {
                                var y = parseInt(monthlySettlementSpacing/12);
                                var m = monthlySettlementSpacing%12;
                                if(y > 0) startDay.setFullYear(startDay.getFullYear() - y);
                                if(m > 0) startDay.setMonth(startDay.getMonth() - m);
                            }
                            v[0] = startDay;
                        }
                    }
                }, null, false);
            }
            return v;
        },


        /**
        * 基础列，冻结列
        */
        baseColums: function ($stateType) {
            if ($stateType == "1") {
                return ['fmtCollectTimeStr'];
            } else {
                return ['sName', 'userCode', 'stationAddr', 'stationCobingType'];
            }
        },
        freezeCol: function(baseColums, columFilter, cloumnModel) {
            var colums = [];
            $.each(columFilter, function(idx, c) {
                if(baseColums.contains(c)) {
                   colums.push(c);
                }
            });
            $.each(cloumnModel, function(idx, c) {
                if(colums.contains(c.name) && c.hide) {
                    colums.remove(c.name);
                }
            });
            return colums.length;
        },

        _formatTime: function(dom, value, record) {
            if(dom && record && record.fmtCollectTimePairStr) {
                // dom.html(record.fmtCollectTimeStr);
                dom.attr('title', record.fmtCollectTimePairStr).parent().attr('title', record.fmtCollectTimePairStr);
            }
        },

        /**
         * 选择展示列
         *
         */
        showColums: function ($stateType, $hasmeter, $timeType) {
            if ($stateType == "1") {
                if ($hasmeter) {
                    switch ($timeType) {
                        case "2":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true, fnInit: reportUtils._formatTime },
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true }, // 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }
                            ]
                            break;
                        case "4":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, // 装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, //理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },// 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name: "totalPower", align: 'center', order: true },// 累计发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },// 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true },// 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true },// 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                            ]
                            break;
                        case "5":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true }, // 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                        case "6":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true }, // 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.equalTree, name: "reductionTotalTree", align: 'center', order: true }, // 等效植树量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                    }
                } else {
                    switch ($timeType) {
                        case "2":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true, fnInit: reportUtils._formatTime },
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true }, // 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }
                            ]
                            break;
                        case "4":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, // 装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, //理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },// 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name: "totalPower", align: 'center', order: true },// 累计发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },// 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true },// 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                            ]
                            break;
                        case "5":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                        case "6":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.equalTree, name: "reductionTotalTree", align: 'center', order: true }, // 等效植树量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                    }
                }
            } else {
                if ($hasmeter) {
                    switch ($timeType) {
                        case "2":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationName,isNewline:true, name: "sName", align: 'center', order: true },                        //电站名称
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userCode, isNewline:true,name: "userCode", align: 'center',hide: !main.IsPowerCode() },                        //发电客户编码
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationAddr, isNewline:true,name: "stationAddr", align: 'center' },                               //地址
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.combineType, name: "stationCobingType", align: 'center', fnInit: reportUtils.delCombineType },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, // 装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, //理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },// 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name: "totalPower", align: 'center', order: true },// 累计发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },// 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true },// 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true },// 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                            ]
                            break;
                        case "4":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationName,isNewline:true, name: "sName", align: 'center', order: true },                        //电站名称
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userCode, isNewline:true,name: "userCode", align: 'center',hide: !main.IsPowerCode() },                        //发电客户编码
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationAddr,isNewline:true, name: "stationAddr", align: 'center' },                               //地址
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.combineType, name: "stationCobingType", align: 'center', fnInit: reportUtils.delCombineType },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true }, // 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                        case "5":
                        case "6":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationName, isNewline:true,name: "sName", align: 'center', order: true },                        //电站名称
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userCode, isNewline:true,name: "userCode", align: 'center' ,hide: !main.IsPowerCode()},                        //发电客户编码
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationAddr, isNewline:true,name: "stationAddr", align: 'center' },                               //地址
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.combineType, name: "stationCobingType", align: 'center', fnInit: reportUtils.delCombineType },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true }, // 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.equalTree, name: "reductionTotalTree", align: 'center', order: true }, // 等效植树量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                    }
                } else {
                    switch ($timeType) {
                        case "2":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationName, isNewline:true,name: "sName", align: 'center', order: true },                        //电站名称
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userCode,isNewline:true, name: "userCode", align: 'center' ,hide: !main.IsPowerCode()},                        //发电客户编码
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationAddr, isNewline:true,name: "stationAddr", align: 'center' },                               //地址
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.combineType, name: "stationCobingType", align: 'center', fnInit: reportUtils.delCombineType },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, // 装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, //理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },// 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name: "totalPower", align: 'center', order: true },// 累计发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },// 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true },// 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits+ "(" + App.getCurrencyUnit() + ")" , name: "powerProfit", align: 'center', order: true }, // 发电量收益
                            ]
                            break;
                        case "4":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationName, isNewline:true,name: "sName", align: 'center', order: true },                        //电站名称
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userCode, isNewline:true,name: "userCode", align: 'center',hide: !main.IsPowerCode() },                        //发电客户编码
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationAddr,isNewline:true, name: "stationAddr", align: 'center' },                               //地址
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.combineType, name: "stationCobingType", align: 'center', fnInit: reportUtils.delCombineType },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                        case "5":
                        case "6":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationName, isNewline:true,name: "sName", align: 'center', order: true },                        //电站名称
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userCode, isNewline:true,name: "userCode", align: 'center',hide: !main.IsPowerCode()},                        //发电客户编码
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.stationAddr, isNewline:true,name: "stationAddr", align: 'center' },                               //地址
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.combineType, name: "stationCobingType", align: 'center', fnInit: reportUtils.delCombineType },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.equalTree, name: "reductionTotalTree", align: 'center', order: true }, // 等效植树量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                    }
                }
            }
        },

        /**
         * 添加默认展示列
         * 默认展示：默认指标：总辐照量、发电量、上网电量、等效利用小时数、系统效率（PR）、厂用电量、计划完成率、用电量(户用)、收益；
         */
        defaultColums: function ($stateType, $timeType, $hasmeter) {
            //时间日
            if ($stateType == 1) {
                if ($hasmeter) {
                    switch ($timeType) {
                        case "2":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'powerUseAndProducHouse', 'usePower', 'theoryPower', 'powerProfit'];
                            break;
                        case "4":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory', 'usePower'];
                            break;
                        case "5":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory', 'usePower', 'fulfilmentRatio'];
                            break;
                        case "6":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory', 'usePower', 'fulfilmentRatio'];
                            break;
                    }
                } else {
                    switch ($timeType) {
                        case "2":
                            return ['fmtCollectTimeStr', 'productPower', 'powerProfit'];
                            break;
                        case "4":
                            return ['fmtCollectTimeStr', 'installedCapacity', 'productPower','totalPower',
                                'powerProfit', 'perpowerRatio'];
                            break;
                        case "5":
                            return ['fmtCollectTimeStr', 'installedCapacity','theoryPower', 'productPower',
                                'powerProfit', 'perpowerRatio'];
                            break;
                        case "6":
                            return ['fmtCollectTimeStr', 'installedCapacity','theoryPower', 'productPower',
                                'powerProfit', 'perpowerRatio'];
                            break;
                    }
                }
            } else {
                if ($hasmeter) {
                    switch ($timeType) {
                        case "2":
                            return ['sName', 'userCode','stationAddr', 'stationCobingType', 'radiationIntensity', 'productPower',
                                'onGridPower', 'powerUseAndProducHouse', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory', 'usePower'];
                            break;
                        case "4":
                            return ['sName', 'userCode','stationAddr', 'stationCobingType', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory', 'usePower', 'fulfilmentRatio'];
                            break;
                        case "5":
                        case "6":
                            return ['sName', 'userCode','stationAddr', 'stationCobingType', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory', 'usePower', 'fulfilmentRatio'];
                            break;
                    }
                } else {
                    switch ($timeType) {
                        case "2":
                            return ['sName','userCode', 'stationAddr', 'installedCapacity', 'productPower','totalPower','powerProfit','perpowerRatio'];
                            break;
                        case "4":
                            return ['sName', 'userCode','stationAddr','installedCapacity','theoryPower', 'productPower','powerProfit','perpowerRatio'];
                            break;
                        case "5":
							return ['sName', 'userCode','stationAddr','installedCapacity','theoryPower', 'productPower','powerProfit','perpowerRatio'];
                            break;
                        case "6":
                            return ['sName', 'userCode','stationAddr','installedCapacity','theoryPower', 'productPower','powerProfit','perpowerRatio'];
                            break;
                    }
                }
            }
        },

        /**
         * 单电站的展示列 getSingnelStationDefaultColum
         */
        getSingnelStationDefaultColum: function ($stationCobineType, $timeType, $hasmeter) {
            if ($stationCobineType == "3") {
                if ($hasmeter) {
                    switch ($timeType) {
                        case "2":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'usePower', 'theoryPower', 'powerProfit'];
                            break;
                        case "4":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'usePower'];
                            break;
                        case "5":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'usePower', 'fulfilmentRatio'];
                            break;
                        case "6":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'usePower', 'fulfilmentRatio'];
                            break;
                    }
                } else {
                    switch ($timeType) {
                        case "2":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'usePower', 'theoryPower', 'powerProfit'];
                            break;
                        case "4":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio'];
                            break;
                        case "5":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'fulfilmentRatio'];
                            break;
                        case "6":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'fulfilmentRatio'];
                            break;
                    }
                }
            } else {
                if ($hasmeter) {
                    switch ($timeType) {
                        case "2":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'usePower', 'theoryPower', 'powerProfit'];
                            break;
                        case "4":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory',];
                            break;
                        case "5":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory', 'fulfilmentRatio'];
                            break;
                        case "6":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'powerUseAndProducFactory', 'fulfilmentRatio'];
                            break;
                    }
                } else {
                    switch ($timeType) {
                        case "2":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'usePower',  'theoryPower', 'powerProfit'];
                            break;
                        case "4":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio'];
                            break;
                        case "5":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'fulfilmentRatio'];
                            break;
                        case "6":
                            return ['fmtCollectTimeStr', 'radiationIntensity', 'productPower',
                                'onGridPower', 'perpowerRatio', 'powerProfit', 'performanceRatio', 'fulfilmentRatio'];
                            break;
                    }
                }
            }
        },

        /**
         * 单电站的选择展示列
         */
        getSingnelStationColum: function ($stationCobineType, $timeType, $hasmeter) {
            if ($stationCobineType == "3") {
                if ($hasmeter) {
                    switch ($timeType) {
                        case "2":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }
                            ]
                            break;
                        case "4":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, // 装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, //理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },// 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name: "totalPower", align: 'center', order: true },// 累计发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },// 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true },// 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true },// 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                            ]
                            break;
                        case "5":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true }, // 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                        case "6":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true }, // 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.userdPower, name: "usePower", align: 'center', order: true }, // 用电量（户用）
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserd, name: "powerUseAndProducHouse", align: 'center', order: true },// 自发自用量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.ownProOwnuserdRate, name: "selfUsePowerRatio", align: 'center', order: true },// 自发自用率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.equalTree, name: "reductionTotalTree", align: 'center', order: true }, // 等效植树量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                    }
                } else {
                    switch ($timeType) {
                        case "2":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }
                            ]
                            break;
                        case "4":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, // 装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, //理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },// 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name: "totalPower", align: 'center', order: true },// 累计发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },// 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true },// 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits+ "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                            ]
                            break;
                        case "5":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits+ "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                        case "6":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.equalTree, name: "reductionTotalTree", align: 'center', order: true }, // 等效植树量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits+ "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                    }
                }
            } else {
                if ($hasmeter) {
                    switch ($timeType) {
                        case "2":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }
                            ]
                            break;
                        case "4":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, // 装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, //理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },// 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name: "totalPower", align: 'center', order: true },// 累计发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },// 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true },// 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true },// 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                            ]
                            break;
                        case "5":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true }, // 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                        case "6":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.netReturnPower, name: "buyPower", align: 'center', order: true }, // 网馈电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.factoryUsed, name: "powerUseAndProducFactory", align: 'center', order: true }, //厂用电量
                                // { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedPower, name: "syFactoryUserd", align: 'center', order: true }, //综合厂用电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sysFactoryUsedRation, name: "synStatUsePowerRatio", align: 'center', order: true },// 综合厂用电率 synStatUsePowerRatio
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.equalTree, name: "reductionTotalTree", align: 'center', order: true }, // 等效植树量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                    }
                } else {
                    switch ($timeType) {
                        case "2":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }
                            ]
                            break;
                        case "4":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, // 装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, //理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true },// 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name: "totalPower", align: 'center', order: true },// 累计发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true },// 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true },// 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                            ]
                            break;
                        case "5":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                        case "6":
                            return [
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", align: 'center', order: true },
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name: "installedCapacity", align: 'center', order: true }, //装机容量
                                { display: Msg.systemSetting.amendment.radiationIntensity, name: "radiationIntensity", align: 'center', order: true },// 总辐照量
                                { display: Msg.systemSetting.amendment.horizontalRadiation, name: "horizontalRadiation", align: 'center', order: true }, // 水平面总辐照量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.sunshineLong, name: "sunshineHours", align: 'center', order: true }, // 日照时长
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.averageTemperature, name: "temperature", align: 'center', order: true }, // 平均温度
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name: "theoryPower", align: 'center', order: true }, // 理论发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name: "productPower", align: 'center', order: true }, // 发电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planPower, name: "planPower", align: 'center', order: true }, //計劃發電量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.onGridPowerUnit, name: "onGridPower", align: 'center', order: true }, // 上网电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name: "perpowerRatio", align: 'center', order: true }, // 等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.groupPerpowerRatio, name: "groupPerpowerRatio", align: 'center', order: true },// 集团等效利用小时数
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name: "powerCuts", align: 'center', order: true },// 限电损失电量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.peakPower, name: "acPeakPower", align: 'center', order: true }, //峰值功率-即峰值交流功率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.systemEfficience, name: "performanceRatio", align: 'center', order: true }, //系统效率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.loadRate, name: "loadFacto", align: 'center', order: true }, // 负荷率
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.carbonDioxideRreduction, name: "reductionTotalCO2", align: 'center', order: true }, // 二氧化碳减排量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.saveStandardCoal, name: "reductionTotalCoal", align: 'center', order: true }, // 标准节约煤量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.equalTree, name: "reductionTotalTree", align: 'center', order: true }, // 等效植树量
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.profits+ "(" + App.getCurrencyUnit() + ")", name: "powerProfit", align: 'center', order: true }, // 发电量收益
                                { display: Msg.partials.main.rm.dayCapPrpfit.data.planComplateRate, name: "fulfilmentRatio", align: 'center', order: true }, // 计划完成率
                            ]
                            break;
                    }
                }
            }
        },
        /**
            * 转义电站类型
            */
        delCombineType: function (dom, value, data) {
        	var typeObj = {
            		"1":Msg.stationInfo.addStation.plantCategory.groundStation,
            		"2":Msg.stationInfo.addStation.plantCategory.combinedTypeDistribute,
            		"3":Msg.stationInfo.addStation.plantCategory.household,
            		"4":Msg.stationInfo.addStation.plantCategory.povertyRelief,
            		"5":Msg.stationInfo.addStation.plantCategory.otherPlant,
            		"6":Msg.stationInfo.addStation.plantCategory.commercialRoof
            }
            $(dom).html(typeObj[value]);
        	$(dom).parent().attr("title", typeObj[value]);
        },








        _formatDevType: function(dom, value, record) {
            if(dom && _.isEmpty(record.devVersionID)) {
                var typeName = '';
                switch (record.devTypeId+'') {
                    case "1":
                        typeName = Msg.devTypeLangKey.stringInverter;
                        break;
                    case "14":
                        typeName = Msg.devTypeLangKey.collectInverter;
                        break;
                    case "38":
                        typeName = Msg.devTypeLangKey.householdInverter;
                        break;
                    case "15":
                        typeName = Msg.devTypeLangKey.dcBus;
                        break;
                    case "9":
                        typeName = Msg.devTypeLangKey.boxTransformer_Ammeter;
                        break;
                    case "17":
                        typeName = Msg.devTypeLangKey.gatewayMeter;
                        break;
                    case "40":
                        typeName = Msg.devTypeLangKey.collectingLineMeter;
                        break;
                    case "41":
                        typeName = Msg.devTypeLangKey.onLineElectricityMeter;
                        break;
                }

                dom.html(typeName).attr('title', typeName).parent().attr('title', typeName);
            }
        },







        timeRule: {
            '0': {'date-type': '-1', 'date-change-type':'1', 'max-date-interval':'7', 'fmt': 'yyyy-MM-dd HH:mm:ss'},
            '1': {'date-type': '-1', 'date-change-type':'1', 'max-date-interval':'7', 'fmt': 'yyyy-MM-dd HH:mm:ss'},
            '2': {'date-type': '1', 'date-change-type':'1', 'max-date-interval':'30', 'fmt': 'yyyy-MM-dd'},
            '3': {'date-type': '1', 'date-change-type':'1', 'max-date-interval':'90', 'fmt': 'yyyy-MM-dd'},
            '4': {'date-type': '2', 'date-change-type':'2', 'max-date-interval':'11', 'fmt': 'yyyy-MM'},
            '5': {'date-type': '3', 'date-change-type':'3', 'max-date-interval':'24', 'fmt': 'yyyy'},
            '6': {'date-type': '3', 'date-change-type':'3', 'max-date-interval':'24', 'fmt': 'yyyy'},
        },





        // dev start
        baseDevColums: ['fmtCollectTimeStr', 'userCode', 'sName', 'dName', 'devVersionID'],
        /**
        * devType   1 inverter, 10 emi, 17 meter, pv -100
        * timeType  0 halfhour, 1 hour, 2 day, 3 week, 4 month, 5 year
        * maxPvNum
        */
        showDevDefaultColums: function (devType, timeType, maxPvNum) {
            if(!devType || !timeType) return [];

            switch(devType + "@" + timeType) {
                case '1@0':
                case '1@1':
                    return ['fmtCollectTimeStr', 'sName', 'dName', 'productPower', 'totalPower'];
                case '1@2':
                case '1@3':
                case '1@4':
                case '1@5':
                    return ['fmtCollectTimeStr', 'sName', 'dName', 'productPower', 'inverterEfficiency'];
                case '10@0':
                case '10@1':
                case '10@2':
                case '10@3':
                case '10@4':
                case '10@5':
                    return ['fmtCollectTimeStr', 'sName', 'dName', 'radiantTotal'];
                case '17@0':
                case '17@1':
                case '17@2':
                case '17@3':
                case '17@4':
                case '17@5':
                    return ['fmtCollectTimeStr', 'sName', 'dName', 'onGridPower', 'totalGridPower'];
                case '-100@0':
                case '-100@1':
                case '-100@2':
                case '-100@3':
                case '-100@4':
                case '-100@5':
                    // 组件多行表头不支持过滤
                default:
                    return [];
            }
        },

        /**
        * devType   1 inverter, 10 emi, 17 meter, pv -100
        * timeType  0 halfhour, 1 hour, 2 day, 3 week, 4 month, 5 year
        * maxPvNum
        */
        showDevColums: function (devType, timeType, maxPvNum) {
            switch(devType + "@" + timeType) {
                case '1@0':
                case '1@1':
                    return [
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", order: true, fnInit: reportUtils._formatTime },
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.stationName, name:"sName", order:true, isNewline:true}, //电站名称
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.userCode, name:"userCode", isNewline:true, hide:!main.IsPowerCode()}, //发电客户编码
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dName, name:"dName", isNewline:true}, //设备名称
                        {display:Msg.partials.main.dm.devType, name:"devVersionID", order:true, fnInit: reportUtils._formatDevType }, //设备类型
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name:"installedCapacity", order:true}, //装机容量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name:"productPower", order:true}, //发电量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name:"totalPower", order:true}, //累计发电量
                    ];
                case '1@2':
                    return [
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", order: true, fnInit: reportUtils._formatTime },
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.stationName, name:"sName", order:true, isNewline:true}, //电站名称
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.userCode, name:"userCode", isNewline:true, hide:!main.IsPowerCode()}, //发电客户编码
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dName, name:"dName", isNewline:true}, //设备名称
                        {display:Msg.partials.main.dm.devType, name:"devVersionID", order:true, fnInit: reportUtils._formatDevType }, //设备类型
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name:"installedCapacity", order:true}, //装机容量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name:"theoryPower", order:true}, //理论发电量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name:"productPower", order:true}, //发电量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name:"totalPower", order:true}, //累计发电量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.invertTransEfficiency, name:"inverterEfficiency", order:true}, //逆变器转换效率
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name:"perpowerRatio", order:true}, //等效利用小时数
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.alternating, name:"acPeakPower", order:true}, //峰值直流功率
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.limitLoss, name:"powerCuts", order:true}, //限电损失电量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.yieldDeviationWithUnit, name:"yieldDeviation", order:true}, //生产偏差
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.onLineTimeLong, name:"startupTime", order:true}, //并网时长
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.totalAopWithUnit, name:"totalAop", order:true}, //生产可靠性
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.aocRatioWithUnit, name:"aocRatio", order:true}//通讯可靠性
                    ];
                case '1@3':
                case '1@4':
                case '1@5':
                    return [
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", order: true, fnInit: reportUtils._formatTime },
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.stationName, name:"sName", order:true, isNewline:true}, //电站名称
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.userCode, name:"userCode", isNewline:true, hide:!main.IsPowerCode()}, //发电客户编码
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dName, name:"dName", isNewline:true}, //设备名称
                        {display:Msg.partials.main.dm.devType, name:"devVersionID", order:true, fnInit: reportUtils._formatDevType }, //设备类型
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.installedCapacity, name:"installedCapacity", order:true}, //装机容量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.theoryPowerWithUnit, name:"theoryPower", order:true, }, //理论发电量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name:"productPower", order:true}, //发电量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.invertTransEfficiency, name:"inverterEfficiency", order:true}, //逆变器转换效率
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.perpowerRatio, name:"perpowerRatio", order:true}, //等效利用小时数
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.alternating, name:"acPeakPower", order:true}, //峰值直流功率
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.onLineTimeLong, name:"startupTime", order:true} //并网时长
                    ];
                case '10@0':
                case '10@1':
                case '10@2':
                case '10@3':
                case '10@4':
                case '10@5':
                    return [
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", order: true, fnInit: reportUtils._formatTime },
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.stationName, name:"sName", order:true, isNewline:true}, //电站名称
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dName, name:"dName", isNewline:true}, //设备名称
                        {display:Msg.thirdInterface.itemCode.radiation_intensity + '('+ Msg.solarEnergy.radiationUnit +')', name:"radiantTotal", order:true}, //辐照量
                    ];
                case '17@0':
                case '17@1':
                case '17@2':
                case '17@3':
                case '17@4':
                case '17@5':
                    return [
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", order: true, fnInit: reportUtils._formatTime },
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.stationName, name:"sName", order:true, isNewline:true}, //电站名称
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dName, name:"dName", isNewline:true}, //设备名称
                        {display:Msg.partials.main.dm.devType, name:"devVersionID", order:true, fnInit: reportUtils._formatDevType }, //设备类型
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name:"onGridPower", order:true}, //发电量
                        {display:Msg.partials.main.rm.dayCapPrpfit.data.totalPower, name:"totalGridPower", order:true}, //累计发电量
                    ];
                case '-100@0':
                case '-100@1':
                case '-100@2':
                case '-100@3':
                case '-100@4':
                case '-100@5':
                    var baseColums = [[
                            {display:Msg.partials.main.rm.dayCapPrpfit.data.collectTime, name: "fmtCollectTimeStr", rowspan: '2', order: true, fnInit: reportUtils._formatTime },
                            {display:Msg.partials.main.rm.dayCapPrpfit.data.stationName, name:"sName", rowspan: '2',  order:true, isNewline:true}, //电站名称
                            {display:Msg.partials.main.rm.dayCapPrpfit.data.dName, name:"dName", rowspan: '2', isNewline:true}, //设备名称
                            {display:Msg.partials.main.dm.devType, name:"devVersionID", rowspan: '2', order:true, fnInit: reportUtils._formatDevType }, //设备类型
                            {display: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit, name:'pp', colspan: maxPvNum },
                        ]];
                    var pvCloumns = [];
                    for(var i=1; i<=maxPvNum;i++) {
                        pvCloumns.push({display:Msg.devTypeLangKey.string+i, name:"pv"+i, order:true});
                    }
                    baseColums.push(pvCloumns);
                    return baseColums;
                default:
                    return [];
            }
        },








    }

    return reportUtils;
})