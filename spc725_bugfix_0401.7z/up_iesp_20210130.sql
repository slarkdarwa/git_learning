
USE iems_shard_kpi_device_01;

-- 非南网项目升级,辐照量单位转换为MJ
DROP PROCEDURE IF EXISTS updateFieldProcedure;
    DELIMITER //
    CREATE PROCEDURE updateFieldProcedure(tableNameOriginal VARCHAR(128), assignmentList VARCHAR(12800))
      BEGIN
        DECLARE tName varchar(256);
        DECLARE tName_over INT DEFAULT FALSE;
        DECLARE tName_cursor CURSOR FOR (SELECT DISTINCT TABLE_NAME FROM information_schema.`TABLES` WHERE TABLE_NAME like concat(tableNameOriginal, "%") AND TABLE_SCHEMA = (SELECT DATABASE()));
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET tName_over = true;
        OPEN tName_cursor;
        tName_loop:LOOP
          FETCH tName_cursor INTO tName;
          IF tName_over THEN LEAVE tName_loop;
          END IF;

          SET @tname_sql = concat('UPDATE ', tName, ' SET ', assignmentList);
          PREPARE updateColumn FROM @tname_sql;
					EXECUTE updateColumn ;
					DEALLOCATE PREPARE updateColumn;

        END LOOP tName_loop;
        CLOSE tName_cursor;
      END//
    DELIMITER ;



CALL updateFieldProcedure('iems_kpi_environment_day_t',' radiant_total=radiant_total*3.6,radiant_total_direct=radiant_total_direct*3.6,horiz_radiant_total=horiz_radiant_total*3.6,horiz_radiant_total_direct=horiz_radiant_total_direct*3.6 ');
CALL updateFieldProcedure('iems_kpi_environment_month_t',' radiant_total=radiant_total*3.6,radiant_total_direct=radiant_total_direct*3.6,horiz_radiant_total=horiz_radiant_total*3.6,horiz_radiant_total_direct=horiz_radiant_total_direct*3.6 ');
CALL updateFieldProcedure('iems_kpi_environment_year_t',' radiant_total=radiant_total*3.6,radiant_total_direct=radiant_total_direct*3.6,horiz_radiant_total=horiz_radiant_total*3.6,horiz_radiant_total_direct=horiz_radiant_total_direct*3.6 ');


DROP PROCEDURE IF EXISTS updateFieldProcedure;















USE iems_shard_kpi_station_01;

-- 非南网项目升级,辐照量单位转换为MJ
DROP PROCEDURE IF EXISTS updateFieldProcedure;
    DELIMITER //
    CREATE PROCEDURE updateFieldProcedure(tableNameOriginal VARCHAR(128), assignmentList VARCHAR(12800))
      BEGIN
        DECLARE tName varchar(256);
        DECLARE tName_over INT DEFAULT FALSE;
        DECLARE tName_cursor CURSOR FOR (SELECT DISTINCT TABLE_NAME FROM information_schema.`TABLES` WHERE TABLE_NAME like concat(tableNameOriginal, "%") AND TABLE_SCHEMA = (SELECT DATABASE()));
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET tName_over = true;
        OPEN tName_cursor;
        tName_loop:LOOP
          FETCH tName_cursor INTO tName;
          IF tName_over THEN LEAVE tName_loop;
          END IF;

          SET @tname_sql = concat('UPDATE ', tName, ' SET ', assignmentList);
          PREPARE updateColumn FROM @tname_sql;
					EXECUTE updateColumn ;
					DEALLOCATE PREPARE updateColumn;

        END LOOP tName_loop;
        CLOSE tName_cursor;
      END//
    DELIMITER ;



CALL updateFieldProcedure('iems_kpi_station_hour_t',' radiation_intensity=radiation_intensity*3.6,horizontal_radiation=horizontal_radiation*3.6 ');
CALL updateFieldProcedure('iems_kpi_station_day_t',' radiation_intensity=radiation_intensity*3.6,horizontal_radiation=horizontal_radiation*3.6 ');
CALL updateFieldProcedure('iems_kpi_station_month_t',' radiation_intensity=radiation_intensity*3.6,horizontal_radiation=horizontal_radiation*3.6 ');
CALL updateFieldProcedure('iems_kpi_station_year_t',' radiation_intensity=radiation_intensity*3.6,horizontal_radiation=horizontal_radiation*3.6 ');

DROP PROCEDURE IF EXISTS updateFieldProcedure;









-- jk
ALTER TABLE iems_station_station_info_t
ADD COLUMN station_sort int(32) DEFAULT NULL COMMENT '电站排序';