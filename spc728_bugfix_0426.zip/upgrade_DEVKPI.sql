﻿SET FOREIGN_KEY_CHECKS=0;

-- 存储过程修改表字段
DROP PROCEDURE IF EXISTS alterFieldProcedure;
    DELIMITER //
    CREATE PROCEDURE alterFieldProcedure(tableNameOriginal VARCHAR(128), alterType VARCHAR(16),field VARCHAR(32), fieldDefine VARCHAR(12800))
      BEGIN
        DECLARE tName varchar(256);
        DECLARE tName_over INT DEFAULT FALSE;
        DECLARE tName_cursor CURSOR FOR (SELECT DISTINCT TABLE_NAME FROM information_schema.`TABLES` WHERE TABLE_NAME like concat(tableNameOriginal, "%") AND TABLE_SCHEMA = (SELECT DATABASE()));
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET tName_over = true;
        OPEN tName_cursor;
        tName_loop:LOOP
          FETCH tName_cursor INTO tName;
          IF tName_over THEN LEAVE tName_loop;
          END IF;

          SET @tname_sql = concat('ALTER TABLE ', tName, ' ',alterType ,' COLUMN  ',field,' ', fieldDefine);
          PREPARE addColumn FROM @tname_sql;

          IF alterType = 'ADD' && NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = tName AND column_name = field)
          THEN
                EXECUTE addColumn ;
                DEALLOCATE PREPARE addColumn;
          ELSEIF alterType = 'MODIFY'
          THEN
                EXECUTE addColumn ;
                DEALLOCATE PREPARE addColumn;
          ELSEIF alterType = 'DROP' && EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = tName AND column_name = field)
          THEN
                EXECUTE addColumn ;
                DEALLOCATE PREPARE addColumn;
          END IF;
        END LOOP tName_loop;
        CLOSE tName_cursor;
      END//
    DELIMITER ;

-- 修改字段begin

CALL alterFieldProcedure('iems_kpi_inverter_string_day_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");
CALL alterFieldProcedure('iems_kpi_inverter_string_month_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");
CALL alterFieldProcedure('iems_kpi_inverter_string_year_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");

CALL alterFieldProcedure('iems_kpi_inverter_center_day_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");
CALL alterFieldProcedure('iems_kpi_inverter_center_month_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");
CALL alterFieldProcedure('iems_kpi_inverter_center_year_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");

CALL alterFieldProcedure('iems_kpi_inverter_sansho_day_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");
CALL alterFieldProcedure('iems_kpi_inverter_sansho_month_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");
CALL alterFieldProcedure('iems_kpi_inverter_sansho_year_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");

CALL alterFieldProcedure('iems_kpi_inverter_hoursehold_day_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");
CALL alterFieldProcedure('iems_kpi_inverter_hoursehold_month_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");
CALL alterFieldProcedure('iems_kpi_inverter_hoursehold_year_t','ADD','daily_standard_power'," decimal(12,3) COMMENT '日标准发电量(kWh)',ADD COLUMN defect_lose_ratio numeric(6,3) COMMENT '发电量损失率(%)' ");

-- 存储过程删除
DROP PROCEDURE IF EXISTS alterFieldProcedure;


DROP PROCEDURE IF EXISTS updateFieldProcedure;
DELIMITER //
CREATE PROCEDURE updateFieldProcedure(tableNameOriginal VARCHAR(128), assignmentList VARCHAR(12800))
BEGIN
    DECLARE tName varchar(256);
    DECLARE tName_over INT DEFAULT FALSE;
    DECLARE tName_cursor CURSOR FOR (SELECT DISTINCT TABLE_NAME FROM information_schema.`TABLES` WHERE TABLE_NAME like concat(tableNameOriginal, "%") AND TABLE_SCHEMA = (SELECT DATABASE()));
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET tName_over = true;
    OPEN tName_cursor;
    tName_loop:LOOP
        FETCH tName_cursor INTO tName;
        IF tName_over THEN LEAVE tName_loop;
        END IF;

        SET @tname_sql = concat('UPDATE ', tName, ' SET ', assignmentList);
        PREPARE updateColumn FROM @tname_sql;
        EXECUTE updateColumn ;
        DEALLOCATE PREPARE updateColumn;

    END LOOP tName_loop;
    CLOSE tName_cursor;
END//
DELIMITER ;

-- MJ -> kWh
CALL updateFieldProcedure('iems_kpi_environment_day_t',' radiant_total=radiant_total/3.6,radiant_total_direct=radiant_total_direct/3.6,horiz_radiant_total=horiz_radiant_total/3.6,horiz_radiant_total_direct=horiz_radiant_total_direct/3.6 ');
CALL updateFieldProcedure('iems_kpi_environment_month_t',' radiant_total=radiant_total/3.6,radiant_total_direct=radiant_total_direct/3.6,horiz_radiant_total=horiz_radiant_total/3.6,horiz_radiant_total_direct=horiz_radiant_total_direct/3.6 ');
CALL updateFieldProcedure('iems_kpi_environment_year_t',' radiant_total=radiant_total/3.6,radiant_total_direct=radiant_total_direct/3.6,horiz_radiant_total=horiz_radiant_total/3.6,horiz_radiant_total_direct=horiz_radiant_total_direct/3.6 ');


DROP PROCEDURE IF EXISTS updateFieldProcedure;

SET FOREIGN_KEY_CHECKS=1;

















