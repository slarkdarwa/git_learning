﻿
-- 存储过程修改表字段
DROP PROCEDURE IF EXISTS alterFieldProcedure;
    DELIMITER //
    CREATE PROCEDURE alterFieldProcedure(tableNameOriginal VARCHAR(128), alterType VARCHAR(16),field VARCHAR(32), fieldDefine VARCHAR(12800))
      BEGIN
        DECLARE tName varchar(256);
        DECLARE tName_over INT DEFAULT FALSE;
        DECLARE tName_cursor CURSOR FOR (SELECT DISTINCT TABLE_NAME FROM information_schema.`TABLES` WHERE TABLE_NAME like concat(tableNameOriginal, "%") AND TABLE_SCHEMA = (SELECT DATABASE()));
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET tName_over = true;
        OPEN tName_cursor;
        tName_loop:LOOP
          FETCH tName_cursor INTO tName;
          IF tName_over THEN LEAVE tName_loop;
          END IF;

          SET @tname_sql = concat('ALTER TABLE ', tName, ' ',alterType ,' COLUMN  ',field,' ', fieldDefine);
          PREPARE addColumn FROM @tname_sql;

          IF alterType = 'ADD' && NOT EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = tName AND column_name = field)
          THEN
                EXECUTE addColumn ;
                DEALLOCATE PREPARE addColumn;
          ELSEIF alterType = 'MODIFY'
          THEN
                EXECUTE addColumn ;
                DEALLOCATE PREPARE addColumn;
          ELSEIF alterType = 'DROP' && EXISTS (SELECT * FROM information_schema.columns WHERE table_schema = DATABASE()  AND table_name = tName AND column_name = field)
          THEN
                EXECUTE addColumn ;
                DEALLOCATE PREPARE addColumn;
          END IF;
        END LOOP tName_loop;
        CLOSE tName_cursor;
      END//
    DELIMITER ;

-- 修改字段begin
CALL alterFieldProcedure('iesp_ledger_station_feasibility_overview_t','ADD','recalculate'," tinyint(1) COMMENT '是否需要重新计算', MODIFY COLUMN `january` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `february` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `march` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `april` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `may` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `june` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `july` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `august` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `september` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `october` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `november` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `december` decimal(8,3) DEFAULT NULL, MODIFY COLUMN `annual_accumulation` decimal(12,3) DEFAULT NULL COMMENT '可研年度累计' ");

-- 存储过程删除
DROP PROCEDURE IF EXISTS alterFieldProcedure;

