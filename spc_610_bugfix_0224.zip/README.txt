
iesp-modules/iesp-client/iesp-web-client/webapp/jk/babel/capacityForecast/stationForecast.js

iesp-modules/iesp-client/iesp-web-client/webapp/ecm/scripts/partials/main/demand/demandForecast.js
iesp-modules/iesp-client/iesp-web-client/webapp/ecm/scripts/partials/main/forecast/powerForecast/noStationRight.js
iesp-modules/iesp-client/iesp-web-client/webapp/ecm/scripts/partials/main/forecast/powerForecast/regionForecast.js
iesp-modules/iesp-client/iesp-web-client/webapp/scripts/language/en_UK.js
iesp-modules/iesp-client/iesp-web-client/webapp/scripts/language/zh_CN.js


"forecastTimePoint": "预测时刻点",
                "paramNote": "注：参数(除装机容量)修改后次日预测生效",