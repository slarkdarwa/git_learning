iesp-modules/iesp-client/iesp-web-client/webapp/modules/menu/menu-jk.js


    //备品备件
    spareParts: {
        id: 'spareparts_store',
        title: 'Msg.menus.spareparts_store',
        load: EcmPage.sparePartStore
    },
	
	
	
	
pkill geckodriver
pkill firefox
pkill selenium