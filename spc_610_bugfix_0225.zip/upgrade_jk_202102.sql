INSERT INTO `iems_sm_src_t` (`srcid`, `srcname`, `code_`, `model_`, `level_`, `status_`, `pid`, `sysid`, `create_time`, `sort_`) VALUES
	    ('spareparts_store', '备品备件', '备品备件', 'menu', '3', 'false', 'configManagement', 'iesp_all', NULL, 'ae2'),
		('spareparts_store_add', '新增', '新增', 'menu', '4', 'false', 'spareparts_store', 'iesp_all', NULL, 'ae21'),
		('spareparts_store_modify', '修改', '修改', 'menu', '4', 'false', 'spareparts_store', 'iesp_all', NULL, 'ae22'),
		('spareparts_store_delete', '删除', '删除', 'menu', '4', 'false', 'spareparts_store', 'iesp_all', NULL, 'a623');
--		('spareparts_store_downloadModel', '下载模板', '下载模板', 'menu', '4', 'false', 'spareparts_store', 'iesp_all', NULL, 'ae24'),
--		('spareparts_store_import', '导入', '导入', 'menu', '4', 'false', 'spareparts_store', 'iesp_all', NULL, 'ae25'),
--		('spareparts_store_export', '导出', '导出', 'menu', '4', 'false', 'spareparts_store', 'iesp_all', NULL, 'ae26'),

DELETE FROM `iems_sm_role_src_t` WHERE role_id = (SELECT id FROM iems_sm_role_t WHERE role_code = "10004");
INSERT INTO iems_sm_role_src_t (role_id,src_id)
SELECT r.id, s.srcid FROM iems_sm_role_t r, iems_sm_src_t s
WHERE r.role_code = "10004";


INSERT INTO `iems_sm_resource_t` (`srcid`, `urlregular`, `methodetype`, `urltype`) VALUES	
	('spareparts_store', 'materialManagement/querySparepartsStore', 'post', 'rest'),
	('spareparts_store', 'materialManagement/querySparepartsStoreByName', 'post', 'rest'),
	('spareparts_store', 'materialManagement/addSparepartsStore', 'post', 'rest'),
	('spareparts_store', 'materialManagement/modifySparepartsStore', 'post', 'rest'),
	('spareparts_store', 'materialManagement/deleteSparepartsStore', 'post', 'rest'),
	('spareparts_store', 'materialManagement/downSparepartsStoreModel', 'post', 'rest'),
	('spareparts_store', 'materialManagement/importSparepartsStore', 'post', 'rest'),
	('spareparts_store', 'materialManagement/exportSparepartsStore', 'post', 'rest'),
	('spareparts_store', 'companyManage/queryCompanyManageByUser', 'post', 'rest');






drop table if exists `iesp_spare_parts_detail_t`;
CREATE TABLE `iesp_spare_parts_detail_t` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `dev_ownership` varchar(128) DEFAULT NULL COMMENT '设备归属',
  `inventory_quantity` bigint(19) DEFAULT '0' COMMENT '库存数量',
  `outbound_date` bigint(19) DEFAULT NULL COMMENT '出库时间',
  `stock_in_date` bigint(19) DEFAULT NULL COMMENT '入库时间',
  `create_user` varchar(32) DEFAULT NULL COMMENT '创建人',
  `remarks` varchar(200) DEFAULT NULL COMMENT '备注',
  `spareparts_id` bigint(20) DEFAULT NULL,
  `domain_type` bigint(10) DEFAULT NULL,
  `domain_id` bigint(19) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='备件库详细信息';


drop table if exists `iesp_spare_parts_t`;
CREATE TABLE `iesp_spare_parts_t` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `dev_name` varchar(128) NOT NULL COMMENT '设备名称',
  `dev_type` varchar(32) NOT NULL COMMENT '设备类型',
  `dev_model` varchar(64) NOT NULL DEFAULT '0' COMMENT '设备型号',
  `dev_manufacturer` varchar(20) NOT NULL COMMENT '设备制造厂商',
  `metering_unit` varchar(10) DEFAULT NULL COMMENT '计量单位',
  `create_user` varchar(32) DEFAULT NULL COMMENT '创建人',
  `remarks` varchar(200) DEFAULT NULL COMMENT '备注',
  `effective` int(1) DEFAULT NULL COMMENT '0无效1有效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='备件库品类信息';

drop table if exists `iesp_spare_parts_record_t`;
CREATE TABLE `iesp_spare_parts_record_t` (
  `id` bigint(19) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `spare_parts_id` bigint(19) DEFAULT NULL COMMENT '备件信息主键ID',
  `out_in_quantity` bigint(19) DEFAULT '0' COMMENT '入库、出库数量',
  `current_quantity` bigint(19) DEFAULT '0' COMMENT '当前剩余库存数量',
  `out_in_date` bigint(19) DEFAULT NULL COMMENT '入库、出库时间',
  `acceptance_pickup_user` bigint(20) DEFAULT NULL COMMENT '入库验收人，出库领用人',
  `operate_user` bigint(20) DEFAULT NULL COMMENT '出库入库操作员',
  `confirm_user` bigint(20) DEFAULT NULL COMMENT '出库入库确认人',
  `record_type` int(1) DEFAULT NULL COMMENT '记录类型,0入库，1出库',
  `confirm_opinion` varchar(200) DEFAULT NULL COMMENT '出入库确认意见',
  `confirm_status` int(1) DEFAULT NULL COMMENT '出入库确认状态，0待确认，1通过，2不通过',
  `checkout_purpose` varchar(200) DEFAULT NULL COMMENT '出库申请用途',
  `remarks` varchar(200) DEFAULT NULL COMMENT '出入库备注信息',
  `dev_ownership` varchar(255) DEFAULT NULL,
  `domain_type` int(10) DEFAULT NULL,
  `domain_id` bigint(19) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='备件出入库信息';










DELETE FROM iems_sm_src_t WHERE srcid IN (
'spareParts',
'spare_part',
'input_record',
'output_record',
'spare_parts_type',
'spareParts_applyIn',
'spareParts_applyOut',
'spareParts_export',
'input_record_inConfirm',
'input_record_export',
'output_record_inConfirm',
'output_record_export',
'spare_parts_type_add',
'spare_parts_type_update',
'spare_parts_type_delete',
'spare_parts_type_import',
'spare_parts_type_export',
'spare_parts_type_downloadTemp'
);










--  delete

INSERT INTO `iems_sm_src_t` (`srcid`, `srcname`, `code_`, `model_`, `level_`, `status_`, `pid`, `sysid`, `create_time`, `sort_`) VALUES
	('spareParts', '',  '备品备件', NULL, '2', 'false', 'configManagement', 'iesp_all', NULL,'3'),
	('spare_part', '',  'Msg.menus.spareparts_store', NULL, '3', 'false', 'spareParts', 'iesp_all', NULL,'a623'),
	('input_record', '',  'Msg.iespMenuSrc.app.inputRecord', NULL, '3', 'false', 'spareParts', 'iesp_all', NULL,'a623'),
	('output_record', '',  'Msg.iespMenuSrc.app.outPutRecord', NULL, '3', 'false', 'spareParts', 'iesp_all', NULL,'a623'),
	('spare_parts_type', '',  'Msg.iespMenuSrc.app.spareTypes', NULL, '3', 'false', 'spareParts', 'iesp_all', NULL,'a623'),
	('spareParts_applyIn', '',  'Msg.iespMenuSrc.app.applyIn', NULL, '4', 'false', 'spare_part', 'iesp_all', NULL,'a623'),
	('spareParts_applyOut', '',  'Msg.iespMenuSrc.app.applyOut', NULL, '4', 'false', 'spare_part', 'iesp_all', NULL,'a623'),
	('spareParts_export', '',  'Msg.export', NULL, '4', 'false', 'spare_part', 'iesp_all', NULL,'a623'),
	('input_record_inConfirm', '',  'Msg.iespMenuSrc.app.inConfirm', NULL, '4', 'false', 'input_record', 'iesp_all', NULL,'a623'),
	('input_record_export', '',  'Msg.cloudPlatform.search.export', NULL, '4', 'false', 'input_record', 'iesp_all', NULL,'a623'),
	('output_record_inConfirm', '',  'Msg.iespMenuSrc.app.outConfirm', NULL, '4', 'false', 'output_record', 'iesp_all', NULL,'a623'),
	('output_record_export', '',  'Msg.smsrc.hp_export', NULL, '4', 'false', 'output_record', 'iesp_all', NULL,'a623'),
	('spare_parts_type_add', '',  'Msg.partials.main.systemMessage.add', NULL, '4', 'false', 'spare_parts_type', 'iesp_all', NULL,'a623'),
	('spare_parts_type_update', '',  'Msg.stationInfo.update', NULL, '4', 'false', 'spare_parts_type', 'iesp_all', NULL,'a623'),
	('spare_parts_type_delete', '',  'Msg.stationInfo.delete', NULL, '4', 'false', 'spare_parts_type', 'iesp_all', NULL,'a623'),
	('spare_parts_type_import', '',  'Msg.smsrc.hp_import', NULL, '4', 'false', 'spare_parts_type', 'iesp_all', NULL,'a623'),
	('spare_parts_type_export', '',  'Msg.smsrc.hp_export', NULL, '4', 'false', 'spare_parts_type', 'iesp_all', NULL,'a623'),
	('spare_parts_type_downloadTemp', '',  'Msg.smsrc.omis_dbtn_downloadTemp', NULL, '4', 'false', 'spare_parts_type', 'iesp_all', NULL,'a623');

DELETE FROM `iems_sm_role_src_t` WHERE role_id = (SELECT id FROM iems_sm_role_t WHERE role_code = "10004");
INSERT INTO iems_sm_role_src_t (role_id,src_id)
SELECT r.id, s.srcid FROM iems_sm_role_t r, iems_sm_src_t s
WHERE r.role_code = "10004";
	
	
	
INSERT INTO `iems_sm_resource_t` (`srcid`, `urlregular`, `methodetype`, `urltype`) VALUES	
	('spare_part', 'spareparts/querySarepartsInfo', 'post', 'rest'),
	('input_record', 'spareparts/querySarepartsRecordInfo', 'post', 'rest'),
	('output_record', 'spareparts/querySarepartsRecordInfo', 'post', 'rest'),
	('spare_parts_type', 'spareparts/querySarepartsInfo', 'post', 'rest'),
	('spareParts_applyIn', 'spareparts/putInSarepartsInfo', 'post', 'rest'),
	('spareParts_applyOut', 'spareparts/checkOutSareparts', 'post', 'rest'),
	('spareParts_import', 'spareparts/exportSarepartsInfo', 'post', 'rest'),
	('spareParts_export', 'spareparts/exportSarepartsInfo', 'post', 'rest'),
	('spareParts_downloadStandard', 'spareparts/exportSarepartsInfo', 'post', 'rest'),
	('input_record_inConfirm', 'spareparts/confirmSarepartsRecord', 'post', 'rest'),
	('input_record_export', 'spareparts/exportSarepartsInfo', 'post', 'rest'),
	('output_record_inConfirm', 'spareparts/confirmSarepartsRecord', 'post', 'rest'),
	('output_record_export', 'spareparts/exportSarepartsInfo', 'post', 'rest'),
	('spare_parts_type_add', 'spareparts/saveOrUpdateSarepartsInfo', 'post', 'rest'),
	('spare_parts_type_update', 'spareparts/saveOrUpdateSarepartsInfo', 'post', 'rest'),
	('spare_parts_type_delete', 'spareparts/deleteSarepartsInfo', 'post', 'rest'),
	('spare_parts_type_import', 'spareparts/uploadSparePartsModel', 'post', 'rest'),
	('spare_parts_type_export', 'spareparts/exportSarepartsInfo', 'post', 'rest'),
	('spare_parts_type_downloadTemp', 'spareparts/exportSarepartsInfo', 'post', 'rest'),
	('spareParts', 'spareparts/querySarepartsDetail', 'post', 'rest'),
	('spareParts', 'spareparts/getAllSarepartsDevInfo', 'post', 'rest');