iesp-modules/iesp-client/iesp-web-client/webapp/ecm/scripts/partials/main/demand/declarationTrend.js

	
	
pkill geckodriver
pkill firefox
pkill selenium