/**
 * 报表管理页面处理
 */
App.Module('rm_dayCapProfit', '模块功能：发电量收益报表', ['partials/main/rm/reportUtils', 'jquery', 'ValidateForm', 'ECharts', 'iemsInputTree',
    'GridTable', 'datePicker'], function (reportUtils) {
        var rm = {
            // 缓存
            echarInstance: null,
            dUtil:null,
            defaultColumCache:{
                time2:null,
                time4:null,
                time5:null,
                time6:null,
                station2:null,
                station4:null,
                station5:null,
                station6:null
            },
            // 参数缓存
            para:{},
            oneDayMills: 24*3600*1000,


            getParam: function(key) {
                rm.setParam('statType', rm.getPage("#stat_type").val());
                rm.setParam('statDim', rm.getPage("#stat_time_dim").val());
                rm.setParam('isSeach', rm.isSeletNode());
                rm.setParam('userId', sessionStorage.getItem('userid'));
                rm.setParam('timeZone', Date.getTimezone());

                rm.para.statTime = rm.getPage("#sTime").val();
                rm.para.endTime = rm.getPage("#eTime").val();
                var fmt = rm.formatTimeByDime(rm.para.statDim, rm.para.statType);
                rm.setParam('statTime', Date.parseTime(rm.para.statTime, fmt));
                rm.setParam('endTime', Date.parseTime(rm.para.endTime, fmt));

                return _.isEmpty(key) ? rm.para : rm.para[key];
            },

            setParam: function(key, val) {
                if(!_.isEmpty(key)) rm.para[key] = val;
            },

            _initTopTree: function() {
                var params = {minLevel: "station"};
                var _SId = env.getSingleParams('sId');
                if(_SId){
                    params.sIds = _SId;
                }
                env.bindTopper({
                    isRadio: false,
                    autoCheck: false,
                    params: params,
                    fnFilter: [env.MODEL_STATION],
                    nodeAnalyser: {
                        sId: ['stationCode', env.MODEL_STATION],
                        locId: ['domainId', env.MODEL_STATION]
                    },
                    fnChange: function(opts) {
                        var _SId = env.getSingleParams('sId');
                        if(_SId){
                            params.sId = _SId;
                        }
                        rm.setParam('sIds', _SId || (opts.sId && opts.sId.join()));
                        var locId = opts.locId && opts.locId[0];

                        // 展示数据的时间维度为天,且域参数变化时才重新初始化时间
                        params = rm.getParam();
                        var oldLocId = params.locId;
                        rm.setParam('locId', locId);
                        var byStationDay = params.statType == '2' && params.statDim == '2';
                        var byTimeDay = params.statType == '1' && params.statDim == '4';
                        if(oldLocId != locId && (byStationDay || byTimeDay)) rm.initTimer(params.statDim);
                        // bugifx 电站树从未勾选过,时间插件未加载,导致查询异常
                        if(!rm.hasInitTime) rm.initTimer();

                        rm.submitQuery();
                    }
                });
            },

            //外部调用初始化方法
            Render: function (params) {
                rm.hasInitTime = false;
                rm.dUtil = params.dUtil;
                rm.find = params.find;
            	var loadP = {title:Msg.partials.main.rm.dayCapPrpfit.stationSelect};
                var sId = $.trim(sessionStorage.getItem("sId"));
                if (sId != "") {
                    $.http.POST('/station/info', { "stationCode": sId }, function (res) {
                    	$('#rm_dayCapProfit #reportTree').remove();
                    	$('#rm_dayCapProfit .col-md-10').removeClass("col-md-10");
                        window.sessionStorage.setItem("stationTimeZone", Date.getTimezone())
                        window.sessionStorage.setItem("stationTime", new Date().getTime());
                        if (res.success) {
                            window.sessionStorage.setItem("stationTimeZone", res.data.data.stationTimeZone);//添加电站时区
                            window.sessionStorage.setItem("stationTime", res.data.data.stationTime);//添加电站时间
                            // 单电站去除
                            if (res.data.data.combineType)
                                window.sessionStorage.setItem("combineType", res.data.data.combineType);// 单电站添加电站的并网类型
                        }
                        //rm.initSinglePlantToolBar();
                        $("#stat_type").val(1);
                        rm.initToolBar();
                        rm.initTimer(rm.getParam('statDim'));
                        //初始化
                        rm.submitQuery();
                    });
                } else {
                	//main.loadStationSearch( $('#reportTree'),loadP);
                    rm._initTopTree();
                    this.initToolBar();
                    //初始化
                   // rm.submitQuery();
                }
            },


            // @unused
            initSinglePlantToolBar: function () {
                $("#dateBox").attr("init", true);
                $("#rm_dayCapProfit .toolbar").removeClass("toolbar");
                $("#kpi_search_singlePlant").show();
                $('#selectShowPS li').off('click').on('click', function () {
                    $("#dateBox").attr("init", true);
                    $('#selectShowPS li').removeClass('curOn');
                    $(this).addClass('curOn');
                    rm.columnFilter=null;
                    var _fmt = $(this);
                    $("#dateBox").val("");
                    $("#dateBox").unbind("click").bind("click", function () {
                        $("#dateBox").attr("init", false);
                        DatePicker({
                            dateFmt: rm.formatTimeByDime(_fmt.val()),
                            //isShowClear: true,
                            onpicked: function () {
                                rm.dataPick();
                            }
                            // maxDate: new Date()
                        }
                        );
                    }
                    );
                    rm.submitQuery();
                });
                $("#dateBox").unbind("click").bind("click", function () {
                    $("#dateBox").attr("init", false);
                    DatePicker({
                        dateFmt: rm.formatTimeByDime(2),
                        onpicked: function () {
                            rm.dataPick()
                        }
                    }
                    );
                }
                );
                rm.getPage("#rm_exportReport_singlePlant").off('click').on('click', function () {
                    rm.exportKpiTable();
                });

                $("#rm_station_sub").off("click").on("click", function () {
                    rm.subscribe();
                });
            },
            /**
             * @unused
             * 时间点击
             */
            dataPick: function () {
                var val = $(".curOn").val();
                var fmt = rm.formatTimeByDime(val);
                if (2 == val) {
                    fmt = 'yyyy-MM-dd'
                }
                rm.submitQuery();
            },

            /**
             * 获取2个日期框
             * @returns {string}
             */
            initTimer: function(statTimeDim, startDay, endDay){
                rm.hasInitTime = true;

                rm.getPage("#timePicker").remove();
                var doubleDatePicker = '<div class="dateShow dateShow-d"  id="timePicker">'
                    +'   <div class="leftSwitch switch"></div>'
                    +'   <!-- 日期类型 1:day 2:month 3:year -->'
                    +'   <div id="date-container" date-type="1" max-date-interval="30" date-change-type="1">'
                    +'       <input type="text" class="Wdate date-input" id="sTime" min-date max-date>'
                    +'        - <input type="text" class="Wdate date-input " id="eTime" min-date max-date>'
                    +'   </div>'
                    +'   <div class="rightSwitch switch"></div>'
                    +'</div>';
                rm.getPage("#stat_time_dim").after(doubleDatePicker);

                statTimeDim = statTimeDim || rm.getParam('statDim') || '2';
                var timeDim = statTimeDim;
                var statType = rm.getParam('statType');
                if(statType && statType == '1') {
                    if(statTimeDim == '4') timeDim = '2';
                    if(statTimeDim == '5') timeDim = '4';
                }

                var rule = reportUtils.timeRule[timeDim];
                rm.getPage('#date-container').attr('date-type', rule['date-type']);
                rm.getPage('#date-container').attr('date-change-type', rule['date-change-type']);
                rm.getPage('#date-container').attr('max-date-interval', rule['max-date-interval']);

                var eTime = startDay || new Date();;
                var sTime = endDay || eTime;
                var withDuration = false;
                if(timeDim == '2') {
                    if((statType && statType == '2') || statTimeDim == '4') {
                        var locId = rm.getParam('locId');
                        // 默认托管域
                        var v = reportUtils.domainDate(locId || parseInt(sessionStorage.getItem('twoLevelDomain')) || 1, startDay, endDay);
                        if(!_.isEmpty(v)) {
                            rm.getPage('#date-container').attr('max-date-interval', v[2]);
                            sTime = v[0];
                            eTime = v[1];
                            withDuration = true;
                        } else {
                            sTime = new Date(eTime.getTime());
                            sTime.setDate(1);
                        }
                    } else {
                        sTime = new Date(eTime.getTime()-7*rm.oneDayMills);
                        rm.getPage('#date-container').attr('max-date-interval', 7);
                    }
                }
                eTime = eTime.format(rule['fmt'], true);
                sTime = sTime.format(rule['fmt'], true);

                rm.dUtil.intiDoubleDateSelector(null, rm.find, function() {
                    rm.find('#eTime').attr('max-date', new Date().format(rule['fmt'], true));
                }, eTime, true, rm.getPage('#timePicker'), null, sTime);
                // 日类型需要按周期切换,重写左右切换按钮事件
                if(withDuration && timeDim == '2' && ((statType && statType == '2') || statTimeDim == '4')) {
                    rm.getPage(".leftSwitch").unbind("click").click(function (e) {
                        eTime = new Date($("#sTime").val()) || new Date();
                        rm.initTimer(statTimeDim, null, eTime);
                    });
                    rm.getPage(".rightSwitch").unbind("click").click(function (e) {
                        sTime = new Date($("#eTime").val());
                        rm.initTimer(statTimeDim, sTime, null);
                    });
                }
            },

            //初始化toolbar
            initToolBar: function () {
            	 rm.getPage("#stat_type").unbind('change').change(function(){
                     rm.columnFilter=null;
                     var statType = $(this).val();
                     var statTimeDim = rm.getParam('statDim');
                     if(statType == 1 ) {
                        rm.getPage('#stat_time_dim').find('option[value="6"]').attr('hidden', false);
                     } else {
                        rm.getPage('#stat_time_dim').find('option[value="6"]').attr('hidden', true);
                        if(statTimeDim == 6) rm.getPage('#stat_time_dim').val(2);
                     }
                     rm.initTimer(statTimeDim);
                 });
                rm.getPage('#stat_time_dim').unbind('change').change(function(){
                    rm.columnFilter=null;
                    var statType = rm.getParam('statType');
                    var statTimeDim = $(this).val();
                    rm.initTimer(statTimeDim);
                });
                rm.getPage('#kpi_dbtn_search').unbind("click").on("click",function () {
                    rm.submitQuery();
                });
                rm.getPage('#table_export').unbind("click").on("click", function () {
                    rm.laodExportPage();
                });
                /* $('#kpi_export').unbind("click").on("click",function () {
                    rm.exportKpiTable();
                }); */
            },

            laodExportPage: function() {
                App.dialog({
                    id: 'rmExportDialog',
                    title: Msg.export,
                    width: 350,
                    height: 100,
                    contentClass: "panelScaleIn panel-popup-modal ecm-module",
                    openEvent: function() {
                        var $c = $('#rmExportDialog .modal-body-content');
                        var $check = $('<div class="exportCheck">'
                                + '<label><sapn class="i18n">' +Msg.companyManage.companyType+'</span><span>:</span></label>'
                                + '<input name="exoprtType"  id="type_Excel" checked type="radio" value="1" class="itemCheck"/>'
                                + '<label for="type_Excel" class="i18n">Excel</label>'
                                + '<input name="exoprtType"  id="type_csv" type="radio" value="2" class="itemCheck"/>'
                                + '<label for="type_csv" class="i18n">CSV</label>'
                            + '</div>');
                        $c.append($check);
                    },
                    buttons: [{
                            id: 'okId',
                            type: 'submit',
                            text: Msg.sure,
                            click: function(e, dom) {
                                rm.exportGridTable($('input:checked', dom).val());
                                dom.modal('hide')
                            }
                        },{
                            id: 'cancelId',
                            type: 'button',
                            text: Msg.close,
                            clickToClose: true
                        }],
                });
            },

            exportGridTable: function (exoprtType) {
                var param = rm.getParam();
                param.exoprtType = exoprtType;

                var sbColum = rm.getFilterColum(param.statType, param.statDim);
                // 系统默认列
                var systemColumDefault =  reportUtils.defaultColums(param.statType, param.statDim, param.hasMeter);
                // 获取对应维度的默认展示列, 首次进入未缓存值则使用系统默认的列 OR 使用用户选择的缓存值
                var sbColum = !sbColum ? systemColumDefault : sbColum;
                var isHide = !main.IsPowerCode();
                if(isHide){
                    sbColum.remove("stationUserCode");
                    sbColum.remove("userCode");
                }
                param.selectColumn = sbColum;
                param.currencyUnit = App.getCurrencyUnit();

                rm.getPage('#param').val(JSON.stringify(param));
                rm.getPage('#kpi_exort_form').find("#_csrf").val(main.getCsrf());
                rm.getPage('#kpi_exort_form').submit();
            },

            //初始化柱状图
            initKpiBar: function () {
                var param = rm.getParam();
                param.querySource = 1;
                $.http.ajax('/rm/listKpiChart', param, function (data) {
                    if (data.success) {
                        var ro = data.data.data;
                        var hasMeter = data.data.hasMeter;
                        var yAxis = ro.yAxis || [];
                        //数据
                        var seriesData = [{
                            name: Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit,//'发电量',
                            type: 'bar',
                            yAxisIndex: 0,
                            barMaxWidth: '17',
                            itemStyle: {
                                normal: {
                                    barBorderRadius: 5,
                                    color: '#00ca7b',
                                    z: 0
                                }
                            },
                            data: ro.yAxis[0]
                        }, {
                            name: Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")",//'收益',
                            type: 'line',
                            yAxisIndex: 1,
                            itemStyle: {
                                normal: {
                                    color: '#3ececf',
                                    z: 1
                                }
                            },
                            data: ro.y2Axis || []
                        }];

                        var option = {
                            noDataLoadingOption: {
                                text: Msg.noData,
                                effect: 'bubble',
                                effectOption: {
                                    effect: {
                                        n: 0 //气泡个数为0
                                    }
                                }
                            },
                            tooltip: {
                                trigger: 'axis',
                                axisPointer: {
                                    lineStyle: {
                                        color: '#70dcb6'
                                    }
                                },
                                textStyle: {
                                    fontSize: 14
                                }
                            },
                            toolbox: {
                                show: false,
                                orient: 'vertical',
                                x: 'right',
                                y: 'center'
                            },
                            legend: {
                                data: [Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit,
                                    Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")"]
                            },
                            grid: {
                                left: '5%',
                                right: '5%',
                                containLabel: true
                            },
                            xAxis: [{
                                type: 'category',
                                axisTick: {
                                    alignWithLabel: true
                                },
                                axisLine: {
                                    lineStyle: {
                                        color: '#3dd59c',
                                        width: 2
                                    }
                                },
                                axisLabel: {
                                    textStyle: {
                                        fontSize: 14,
                                        color: '#333'
                                    }
                                },
                                splitLine: {
                                    show: false,
                                    lineStyle: {
                                        color: '#eeeeee',
                                        type: 'dashed'
                                    }
                                },
                                data: ro.xAxis || []
                            }],
                            yAxis: [{
                                type: 'value',
                                name: Msg.unit.kWhUnit,
                                axisLine: {
                                    lineStyle: {
                                        color: '#3dd59c',
                                        width: 2
                                    }
                                },
                                axisLabel: {
                                    formatter: '{value}',
                                    textStyle: {
                                        fontSize: 14,
                                        color: '#333'
                                    }
                                },
                                splitNumber: 5,
                                splitLine: {
                                    show: false,
                                    lineStyle: {
                                        color: '#eee'
                                    }
                                },
                                nameTextStyle: {
                                    fontFamily: "Microsoft Yahei",
                                    fontSize: 14,
                                    color: '#333'
                                }
                            }, {
                                type: 'value',
                                name: App.getCurrencyUnit(),
                                axisLine: {
                                    lineStyle: {
                                        color: '#3dd59c',
                                        width: 2
                                    }
                                },
                                splitLine: {
                                    show: false
                                },
                                axisLabel: {
                                    formatter: '{value}',
                                    textStyle: {
                                        fontSize: 14,
                                        color: '#333'
                                    }
                                },
                                splitNumber: 5,
                                nameTextStyle: {
                                    fontFamily: "Microsoft Yahei",
                                    fontSize: 14,
                                    color: '#333'
                                }
                            }],
                            series: seriesData
                        };

                        //如果有电表
                        if (hasMeter) {
                            // if (param.statType == 1 && param.statDim == 2) {
                            //     option.legend.data = [Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit,
                            //         Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")"]; //[发电量, 收益]
                            // } else {
                                option.legend.data = [Msg.partials.main.rm.dayCapPrpfit.data.dayCapWithUnit,
                                    Msg.partials.main.rm.dayCapPrpfit.data.usePowerWithUnit,
                                    Msg.partials.main.rm.dayCapPrpfit.data.profits + "(" + App.getCurrencyUnit() + ")"]; //[发电量, 用电量, 收益]
                                option.series.push({
                                    name: Msg.partials.main.rm.dayCapPrpfit.data.usePowerWithUnit,
                                    type: 'bar',
                                    yAxisIndex: 0,
                                    barMaxWidth: '17',
                                    itemStyle: {
                                        normal: {
                                            barBorderRadius: 5,
                                            color: '#D886EA',
                                            z: 0
                                        }
                                    },
                                    data: ro.yAxis[1]
                                });
                            // }
                        }
                        //加载导出图形// 非導出德 圖片不需要添加其他樣式
                        if (param.statType == 2) {
                            option.xAxis[0].axisLabel = {
                                textStyle: {
                                    fontSize: 8,
                                    color: '#333'
                                },
                                interval: 0,
                                rotate: 40,
                                formatter:function(value,index)
                                {
                                  var resultValue ="";
                                  while( value.length > 8){
                                	  resultValue=value.substring(0,8)+'\n';
                                	  value = value.substring(8,value.length);
                                  }
                                  resultValue += value;
                                  return resultValue;
                                 }
                            }

                        }
                        rm.echarInstance = ECharts.Render('kpi_bar_export', option, true);

                        //如果是按照电站统计的话， 加上横向滚动
                        if (param.statType == 2) {
                            option.dataZoom = {
                                show: true,
                                realtime: true,
                                start: 0,
                                end: 60
                            };
                        }
                        // 非導出德 圖片不需要添加其他樣式
                        option.xAxis[0].axisLabel = {
                            textStyle: {
                                fontSize: 14,
                                color: '#333'
                            }
                        }

                        //加载显示图形
                        ECharts.Render('kpi_bar', option, true);
                    }
                });
            },

            // 初始化表格
            initKpiTable: function (hasMeter) {
                //获取查询参数
                var $statType = rm.getParam('statType');
                var $timeType = rm.getParam('statDim');
                var combineType = $.trim(sessionStorage.getItem("combineType"));

                // 先从缓存中获取上次保存的值
                var sbColum = rm.getFilterColum($statType, $timeType);
                // 获取对应维度的展示列
                var cloumnArr = reportUtils.showColums($statType, hasMeter, $timeType);
                // 系统默认列
                var systemColumDefault =  reportUtils.defaultColums($statType, $timeType, hasMeter);
                // 获取对应维度的默认展示列, 首次进入未缓存值则使用系统默认的列 OR 使用用户选择的缓存值
                var columFilter = !sbColum ? systemColumDefault : sbColum;

                if ($statType == 1) {
                    rm.setParam('orderBy', "fmtCollectTimeStr");   // 后端使用collectTime排序
                } else {
                	if(main.isSNameSort()){
                        rm.setParam('orderBy', "sName");
    	        	}else{
                        rm.setParam('orderBy', "installedCapacity");
    	        	}
                }
                rm.setParam('sort', "asc");
                // rm.setParam('currencyUnit', App.getCurrencyUnit());
                rm.setParam('station', "0");

                var sId = $.trim(sessionStorage.getItem("sId"));
                if (sId != "") {
                    if (combineType) {
                        cloumnArr = reportUtils.getSingnelStationColum(combineType, $timeType, hasMeter);
                    }
                    rm.setParam('station', "1");
                }
                var freezeCol = function (columFilter, cloumnArr) {
                    return reportUtils.freezeCol(reportUtils.baseColums($statType), columFilter, cloumnArr)
                };
                // bugfix girdtable分页刷新时,参数与页面元素绑定?切换类型后分页刷新获取不到时间参数(元素重新构造了)?定义一个上下文变量缓存参数
                var p = rm.getParam();
                var params = {
                    sIds: p.sIds,
                    statType: p.statType,
                    statDim: p.statDim,
                    statTime: p.statTime,
                    endTime: p.endTime,
                    userId: p.userId,
                    querySource: p.querySource,
                    isSeach: p.isSeach,
                    orderBy: p.orderBy,
                    sort: p.sort
                };
                //加载表格
                rm.getPage('#kpi_grid').GridTable({
                    url: '/rm/listKpiListSys',
                    title: false,
                    resizable: false,
                    max_height: 600,
                    rp: 10,
                    freezeCol: freezeCol,
                    defaultColumnFilter: systemColumDefault, //系统默认列
                    columnFilter: columFilter,  //当前显示的列
                    params: params,
                    idProperty: 'id',
                    filterColum: '-387px',
                    colModel: cloumnArr, 	    //全部的列
                    onLoadReady: function() {
                        // 缓存默认列
                        rm.initSelectColums(params.statType, params.statDim);
                    }
                });
            },

            //导出报表
            exportKpiTable: function () {
                if (!rm.getParam()) {
                    return App.alert({
                        title: Msg.info,
                        message: Msg.partials.main.rm.dayCapPrpfit.exportExp
                    });
                }

                //延迟2s中让数据尽快加载出来
                setTimeout(function () {
                	var isHide = !main.IsPowerCode();
                	var arr = rm.getPage('#kpi_grid').GridTableSelectedRecords();
                	if(isHide){
                		arr.remove("stationUserCode");
                		arr.remove("userCode");
                	}
                    var barImg = rm.echarInstance ? rm.echarInstance.getDataURL("png") : '';   //饼图img
                    var param = $.extend(rm.getParam(), {
                        barImg: barImg,
                        //用于支持选择某列 则导出这些列
                        selectColumn:arr
                    });
                    rm.getPage('#param').val(JSON.stringify(param));
                    rm.getPage('#kpi_exort_form').find("#_csrf").val(main.getCsrf());
                    rm.getPage('#kpi_exort_form').submit();
                }, 2000);
            },

            //订阅
            subscribe: function () {
                $.http.ajax('/rm/checkMail', {
                    "userid": Cookies.get("userid")
                }, function (res) {
                    if (res.success) {
                        var settingDialog = App.dialog({
                            id:"stationSubscribeDialog",
                            title: Msg.partials.main.rm.dayCapPrpfit.stationSub,
                            width: 1010,
                            height: 800,
                        });
                        settingDialog.loadPage({
                            url: "/partials/main/rm/rm_stationSubscribe.html",
                            preload: "partials/main/rm/stationSubscribe"
                        });
                    } else {
                        main.comonErrorFun(res.data);
                    }
                });
            },

            //格式化时间
            formatTimeByDime: function (dim, statType) {
                var robj = {
                    "2": 'yyyy-MM-dd',
                    "4": 'yyyy-MM',
                    "5": 'yyyy',
                    "6": 'yyyy'
                }
                if(statType && statType == '1') {
                    if(dim == '4') return robj[2];
                    if(dim == '5') return robj[4];
                }
                return robj[dim] || 'yyyy-MM-dd';
            },

            //提交查询查询
            submitQuery: function () {
                rm.getPage("#kpi_grid_tile").html(Msg.partials.main.rm.capReport); // 发电报表

                var param =rm.getParam();
                var statType = param.statType;
                var statTimeDim = param.statDim;
                var statTime = param.statTime;
                var endTime = param.endTime;

                /* var differ = endTime - statTime + 1;
                if((parseInt(statType) == 1 && parseInt(statTimeDim) == 4) || (parseInt(statType) == 2 && parseInt(statTimeDim) == 2)){
                	if(differ > 31*24*60*60*1000){
                		App.alert({
	                        title: Msg.info,
	                        message: Msg.partials.main.rm.dayCapPrpfit.dayIsLarge
	                    });
	                    return;
                	}
                }else if(parseInt(statType) == 1 && parseInt(statTimeDim) == 5){
                	if(differ > 365*24*60*60*1000){
                		App.alert({
	                        title: Msg.info,
	                        message: Msg.partials.main.rm.dayCapPrpfit.monthIsLarge
	                    });
	                    return;
                	}
                } */

                if (!param.statTime) {
                    return App.alert({
                        title: Msg.info,
                        message: Msg.chooseTime
                    });
                }
                // $.http.ajax('/rm/checkMeterIsExistsInStation', param, function (data) {
                //     if (data && data.success) {
                //         var hasMeter = data.data.hasMeter;
                //         rm.setParam('hasMeter', hasMeter);
                //         rm.initKpiTable(hasMeter);
                //     }
                // });

                rm.setParam('hasMeter', true);
                rm.initKpiTable(true);
                rm.initKpiBar();
            },

            /**
            * 初始化 选择的表格的默认
            */
            initSelectColums: function (statType, statDim) {
                var dom = $("#kpi_grid");
                var domTable = dom.find(".GridTableDiv");
                if (!domTable || domTable.length == 0 ){
                    return ;
                }
                var comlums = [];
                if (dom){
                    var x = dom[0];
                    comlums = x.p.columnFilter
                }else{
                    comlums = null;
                }
                if (statType == 1) {
                    switch (statDim) {
                        case "2":
                        rm.defaultColumCache.time2 = comlums;
                        break;
                        case "4":
                        rm.defaultColumCache.time4 = comlums;
                        break;
                        case "5":
                        rm.defaultColumCache.time5 = comlums;
                        break;
                        case "6":
                        rm.defaultColumCache.time6 = comlums;
                        break;
                    }
                } else {
                    switch (statDim){
                        case "2" :
                        rm.defaultColumCache.station2 = comlums;
                        break;
                        case "4" :
                        rm.defaultColumCache.station4 = comlums;
                        break;
                        case "5" :
                        rm.defaultColumCache.station5 = comlums;
                        break;
                        case "6" :
                        rm.defaultColumCache.station6 = comlums;
                        break;
                    }
                }
            },
            /**
             * 获取对应的值
             */
            getFilterColum: function(statType, statDim){
                if (statType == 1) {
                    switch (statDim) {
                        case "2":
                        return rm.defaultColumCache.time2 ;
                        case "4":
                        return rm.defaultColumCache.time4;
                        case "5":
                        return rm.defaultColumCache.time5;
                        case "6":
                        return rm.defaultColumCache.time6;
                    }
                } else {
                    switch (statDim){
                        case "2" :
                        return rm.defaultColumCache.station2;
                        case "4" :
                        return rm.defaultColumCache.station4;
                        case "5" :
                        return rm.defaultColumCache.station5;
                        case "6" :
                        return rm.defaultColumCache.station6;
                    }
                }
            },

            /**
             * 获取对应的dom
             */
            getPage: function (select, pDom) {
                var page = $('#rm_dayCapProfit', rm.pDom);
                return select ? page.find(select) : page;
            },
            /**
             * 是否有选中节点
             */
            isSeletNode : function(){
                var ids = rm.para.sIds;
            	// ids = main.getSearchSelect();
            	return ids && ids.length > 0;
            },
            /**
             * 获取选择的电站
             */
            getSelStation:function(){
            	// sids = main.getSearchStationCode();
                return rm.para.sIds;
            }
        };

        return rm;
    });